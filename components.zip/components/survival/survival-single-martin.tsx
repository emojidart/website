"use client"
import { useEffect, useRef, useState } from "react"

type Request = {players:string[];machine:number;call:1|2|3;nonce:number}|null
export function SurvivalSingleMartin({request,onHandled}:{request:Request;onHandled:()=>void}){
 const [enabled,setEnabled]=useState(false)
 const [message,setMessage]=useState("")
 const [busy,setBusy]=useState(false)
 const audioRef=useRef<HTMLAudioElement|null>(null)
 useEffect(()=>{setEnabled(localStorage.getItem("emd_survival_martin_enabled")==="true")},[])
 useEffect(()=>()=>{audioRef.current?.pause()},[])
 useEffect(()=>{
  if(!request)return
  if(!enabled){setMessage("Martin ist deaktiviert. Aktiviere ihn zuerst über den Schalter.");onHandled();return}
  if(request.players.length!==2||request.players.some(p=>!p)){setMessage("Ungültige Einzel-Paarung.");onHandled();return}
  let cancelled=false
  let url:string|null=null
  const run=async()=>{
   setBusy(true);setMessage("Martin bereitet die Einzel-Ansage vor …")
   try{
    const response=await fetch("http://127.0.0.1:8765/speak",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({player1:request.players[0],player2:request.players[1],machine:request.machine,call:request.call,speed:1})})
    if(!response.ok){ const detail=await response.json().catch(()=>null); throw new Error(detail?.error || `Martin HTTP ${response.status}`) }
    const audio=await response.blob()
    if(cancelled)return
    url=URL.createObjectURL(audio)
    const player=new Audio(url)
    audioRef.current=player
    await player.play()
    setMessage("Martin spricht: "+request.players.join(" gegen "))
    await new Promise<void>((resolve,reject)=>{player.onended=()=>resolve();player.onerror=()=>reject(new Error("Audiofehler"))})
    setMessage("Ansage abgeschlossen")
   }catch(error){if(!cancelled)setMessage("Einzel-Ansage fehlgeschlagen: "+(error instanceof Error ? error.message : String(error)))}
   finally{if(url)URL.revokeObjectURL(url);if(!cancelled){setBusy(false);onHandled()}}
  }
  void run()
  return()=>{cancelled=true;audioRef.current?.pause();if(url)URL.revokeObjectURL(url)}
 },[request,enabled,onHandled])
 return <div className="rounded-xl border border-orange-500/20 bg-[#15100d] px-4 py-3 flex flex-wrap items-center gap-3 justify-between"><div><p className="text-sm font-extrabold text-orange-200">🎤 EMD Martin · Einzel Roulette</p><p className="text-xs text-zinc-400 mt-1">Ansagen nur per Klick – keine automatischen Überraschungen.</p>{message&&<p role="status" className="text-xs text-zinc-200 mt-2">{message}</p>}</div><label className="text-sm font-bold flex items-center gap-2"><input type="checkbox" checked={enabled} disabled={busy} onChange={e=>{setEnabled(e.target.checked);localStorage.setItem("emd_survival_martin_enabled",String(e.target.checked))}}/>Martin {enabled?"EIN":"AUS"}</label></div>
}
