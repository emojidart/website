"use client"

import { useState, useEffect, useRef } from "react"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"
import { cn } from "@/lib/utils"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { RotateCcw, Check, Radio, Activity, Clock3, Trophy, MonitorUp } from "lucide-react"
import { supabase } from "@/lib/supabase"
import { calculateSeriesLegPoints, calculateSeriesPlacementPoints, calculateSeriesWinnerBonus, loadSeriesScoringRuntime } from "@/lib/tournament-series-scoring"
import { useRouter, useSearchParams } from "next/navigation"
import { useSpeechAnnouncer, SpeechAnnouncerSettings } from "@/components/speech-announcer"

interface Match {
  id: number
  player1: string
  player2: string
  score1: number
  score2: number
  winner?: string
  loser?: string
  machineNumber?: number
  callCount?: number
}

interface TournamentBracketProps {
  bracketSize?: 8 | 16 | 32 | 64
  tournamentType?: string
}

interface Ranking {
  player_name: string
  placement: number
  eliminated_at: string
}

const isFreilos = (playerName: string): boolean => {
  return playerName.startsWith("Freilos")
}

const DEBUG = false
const debugLog = (...args: unknown[]) => {
  if (DEBUG) {
    console.log(...args)
  }
}






const saveMatchStatesToDatabase = async (
  matches: Record<number, Match>,
  tournamentType: string,
  tournamentId: string,
  playerIdMap: Record<string, string>,
  _previousMatches?: Record<number, Match>,
) => {
  const getId = (name: string) => {
    const key = (name ?? "").toLowerCase().trim()
    if (!key || key.startsWith("freilos")) return null
    return playerIdMap[key] ?? null
  }

  const hasMeaningfulData = (match: Match) => {
    const player1 = (match.player1 ?? "").trim()
    const player2 = (match.player2 ?? "").trim()

    return (
      player1 !== "" ||
      player2 !== "" ||
      (match.score1 ?? 0) > 0 ||
      (match.score2 ?? 0) > 0 ||
      !!match.winner ||
      !!match.loser ||
      !!match.machineNumber
    )
  }

  const normalize = (value: any) => (value === undefined || value === "" ? null : value)

  try {
    // NICHT gegen previousMatches vorfiltern.
    // Die Bracket-Logik verändert Ziel-Matches teilweise per flacher Objektkopie.
    // Dadurch kann previousMatches bereits denselben neuen Spieler enthalten und
    // ein notwendiges Weiter-Schreiben würde fälschlich übersprungen.
    const relevantMatches = Object.values(matches).filter(hasMeaningfulData)

    if (relevantMatches.length === 0) return

    const { data: existingRows, error: existingError } = await supabase
      .from("dko_match_states")
      .select("match_id, player1, player2, player1_id, player2_id, score1, score2, winner, loser, machine_number")
      .eq("tournament_type", tournamentType)
      .eq("tournament_id", tournamentId)

    if (existingError) throw existingError

    const existingByMatchId = new Map<number, any>(
      (existingRows ?? []).map((row: any) => [Number(row.match_id), row]),
    )

    const changedMatches = relevantMatches.filter((match) => {
      const existing = existingByMatchId.get(match.id)
      if (!existing) return true

      return (
        normalize(existing.player1) !== normalize(match.player1) ||
        normalize(existing.player2) !== normalize(match.player2) ||
        normalize(existing.player1_id) !== normalize(getId(match.player1)) ||
        normalize(existing.player2_id) !== normalize(getId(match.player2)) ||
        Number(existing.score1 ?? 0) !== Number(match.score1 ?? 0) ||
        Number(existing.score2 ?? 0) !== Number(match.score2 ?? 0) ||
        normalize(existing.winner) !== normalize(match.winner) ||
        normalize(existing.loser) !== normalize(match.loser) ||
        normalize(existing.machine_number) !== normalize(match.machineNumber)
      )
    })

    if (changedMatches.length === 0) return

    const matchStates = changedMatches.map((match) => ({
      tournament_type: tournamentType,
      tournament_id: tournamentId,
      match_id: match.id,
      player1: match.player1,
      player2: match.player2,
      player1_id: getId(match.player1),
      player2_id: getId(match.player2),
      score1: match.score1,
      score2: match.score2,
      winner: match.winner || null,
      loser: match.loser || null,
      machine_number: match.machineNumber || null,
      updated_at: new Date().toISOString(),
    }))

    const { error } = await supabase.from("dko_match_states").upsert(matchStates, {
      onConflict: "tournament_type,tournament_id,match_id",
    })

    if (error) throw error
  } catch (error) {
    console.error("Fehler beim Speichern der Match-States:", error)
    throw error
  }
}


const loadMatchStatesFromDatabase = async (
  tournamentType: string,
  tournamentId: string,
): Promise<Record<number, Match> | null> => {
  try {
    const { data, error } = await supabase
      .from("dko_match_states")
      .select("*")
      .eq("tournament_type", tournamentType)
      .eq("tournament_id", tournamentId)
      .order("match_id", { ascending: true })

    if (error) throw error

    if (!data || data.length === 0) {
      debugLog("[v0] No saved match states found")
      return null
    }

    const matches: Record<number, Match> = {}
    data.forEach((state) => {
      matches[state.match_id] = {
        id: state.match_id,
        player1: state.player1 || "",
        player2: state.player2 || "",
        score1: state.score1 || 0,
        score2: state.score2 || 0,
        winner: state.winner || undefined,
        loser: state.loser || undefined,
        machineNumber: state.machine_number || undefined,
        callCount: state.machine_number ? 1 : undefined,
      }
    })

    debugLog("[v0] Match states loaded successfully")
    return matches
  } catch (error) {
    console.error("Fehler beim Laden der Match-States:", error)
    return null
  }
}

const deleteMatchStatesFromDatabase = async (tournamentType: string, tournamentId: string) => {
  try {
    const { error } = await supabase
      .from("dko_match_states")
      .delete()
      .eq("tournament_type", tournamentType)
      .eq("tournament_id", tournamentId)

    if (error) throw error
    debugLog("[v0] Match states deleted")
  } catch (error) {
    console.error("Fehler beim Löschen der Match-States:", error)
  }
}

const deleteRankingsFromDatabase = async (tournamentType: string, tournamentId: string) => {
  try {
    const { error } = await supabase
      .from("dko_rankings")
      .delete()
      .eq("tournament_type", tournamentType)
      .eq("tournament_id", tournamentId)

    if (error) throw error
    debugLog("[v0] Rankings deleted")
  } catch (error) {
    console.error("Fehler beim Löschen der Rankings:", error)
  }
}

const deleteFreiloseFromDatabase = async (tournamentType: string, tournamentId: string) => {
  try {
    const { error } = await supabase
      .from("tournament_freilose")
      .delete()
      .eq("tournament_type", tournamentType)
      .eq("tournament_id", tournamentId)

    if (error) throw error
    debugLog("[v0] Freilose deleted")
  } catch (error) {
    console.error("Fehler beim Löschen der Freilose:", error)
  }
}

const clearTournamentRegistration = async (seriesId?: string | null, eventId?: string | null) => {
  try {
    let query = supabase.from("dko_tournament_registration").delete().neq("id", 0)
    if (seriesId) query = query.eq("series_id", seriesId)
    if (eventId) query = query.eq("event_id", eventId)
    const { error } = await query

    if (error) throw error
    debugLog("[v0] Tournament registration cleared successfully")
  } catch (error) {
    console.error("Fehler beim Löschen der Registrierung:", error)
  }
}

const distributePlayersWithFreilose = (players: string[], bracketSize: number): string[] => {
  const totalSlots = bracketSize
  const freilosCount = totalSlots - players.length

  const shuffledPlayers = [...players].sort(() => Math.random() - 0.5)

  // Freilose erstellen
  const freilose: string[] = Array.from({ length: freilosCount }, (_, i) => `Freilos ${i + 1}`)

  const result: string[] = []

  // 1. IMMER zuerst Spieler + Freilos paaren
  while (freilose.length > 0 && shuffledPlayers.length > 0) {
    result.push(shuffledPlayers.pop()!, freilose.pop()!)
  }

  // 2. Restliche Spieler normal paaren
  while (shuffledPlayers.length >= 2) {
    result.push(shuffledPlayers.pop()!, shuffledPlayers.pop()!)
  }

  // 3. Sicherheitscheck (sollte NIE passieren)
  if (freilose.length > 0) {
    console.error("FEHLER: Übrig gebliebene Freilose → LOGIK PROBLEM")
  }

  return result
}

const saveFreiloseToDatabase = async (freilose: string[], tournamentType: string, tournamentId: string) => {
  try {
    const freilosData = freilose.map((name, index) => ({
      tournament_type: tournamentType,
      tournament_id: tournamentId,
      freilos_name: name,
      position: index,
    }))

    const { error } = await supabase.from("tournament_freilose").upsert(freilosData, {
      onConflict: "tournament_type,tournament_id,position",
    })

    if (error) throw error
    debugLog("[v0] Freilose saved successfully")
  } catch (error) {
    console.error("Fehler beim Speichern der Freilose:", error)
  }
}

const loadFreiloseFromDatabase = async (tournamentType: string, tournamentId: string): Promise<string[]> => {
  try {
    const { data, error } = await supabase
      .from("tournament_freilose")
      .select("freilos_name, position")
      .eq("tournament_type", tournamentType)
      .eq("tournament_id", tournamentId)
      .order("position", { ascending: true })

    if (error) throw error

    return data ? data.map((f) => f.freilos_name) : []
  } catch (error) {
    console.error("Fehler beim Laden der Freilose:", error)
    return []
  }
}

const removePlayerFromRankings = async (playerName: string, tournamentType: string, tournamentId: string) => {
  try {
    debugLog(`[v0] Removing ${playerName} from rankings due to match reset`)

    const { error } = await supabase
      .from("dko_rankings")
      .delete()
      .eq("tournament_type", tournamentType)
      .eq("tournament_id", tournamentId)
      .eq("player_name", playerName)

    if (error) {
      console.error("[v0] Error removing player from rankings:", error)
      throw error
    }

    debugLog(`[v0] Successfully removed ${playerName} from rankings`)
  } catch (error) {
    console.error("Fehler beim Entfernen aus Rankings:", error)
  }
}

const getPlacementForEliminationMatch = (matchId: number, bracketSize: number): number => {
  if (bracketSize === 16) {
    if (matchId >= 9 && matchId <= 12) return 13
    if (matchId >= 17 && matchId <= 20) return 9
    if (matchId === 21 || matchId === 22) return 7
    if (matchId === 25 || matchId === 26) return 5
    if (matchId === 27) return 4
    if (matchId === 29) return 3
    if (matchId === 30 || matchId === 31) return 2
  }

  if (bracketSize === 8) {
    if (matchId >= 8 && matchId <= 9) return 7
    if (matchId >= 10 && matchId <= 11) return 5
    if (matchId === 12) return 4
    if (matchId === 13) return 3
    if (matchId === 14 || matchId === 15) return 2
  }

  console.warn(`[v0] Unknown elimination match ${matchId}, using fallback placement`)
  return bracketSize
}

const trackPlayerElimination = async (
  allMatches: Record<number, Match>,
  eliminatedPlayer: string,
  tournamentType: string,
  tournamentId: string,
  tournamentName: string,
  totalPlayers: number,
) => {
  debugLog(`[v0] ========== TRACKING ELIMINATION ==========`)
  debugLog(`[v0] Player: ${eliminatedPlayer}`)
  debugLog(`[v0] Tournament ID: ${tournamentId}`)
  debugLog(`[v0] Tournament Name: ${tournamentName}`)

  if (isFreilos(eliminatedPlayer)) {
    debugLog(`[v0] ✗ Skipping ranking for Freilos: ${eliminatedPlayer} (Freilos are not ranked)`)
    return
  }

  const { data: existingPlayerRanking, error: checkError } = await supabase
    .from("dko_rankings")
    .select("id, placement")
    .eq("tournament_type", tournamentType)
    .eq("tournament_id", tournamentId)
    .eq("player_name", eliminatedPlayer)
    .maybeSingle()

  if (checkError) {
    console.error("[v0] Error checking for existing ranking:", checkError)
  }

  if (existingPlayerRanking) {
    debugLog(
      `[v0] ✗ Player ${eliminatedPlayer} already has ranking in THIS tournament (placement ${existingPlayerRanking.placement}), skipping duplicate call`,
    )
    return
  }

  const lossMatches = Object.values(allMatches).filter((m) => m.loser === eliminatedPlayer && m.winner)
  const losses = lossMatches.length

  debugLog(`[v0] Player ${eliminatedPlayer} loss history:`)
  lossMatches.forEach((m) => {
    debugLog(`[v0]   - Lost Match ${m.id}: ${m.player1} vs ${m.player2}, Winner: ${m.winner}`)
  })
  debugLog(`[v0] Total losses: ${losses}`)

  if (losses === 2) {
    debugLog(`[v0] ✓ Player ${eliminatedPlayer} is ELIMINATED with 2 losses! Saving to database...`)
    try {
      const eliminationMatch = lossMatches[lossMatches.length - 1]
      const placement = getPlacementForEliminationMatch(eliminationMatch.id, totalPlayers)

      debugLog(`[v0] Elimination match: ${eliminationMatch.id}`)
      debugLog(`[v0] Calculated placement for ${eliminatedPlayer}: ${placement} (based on elimination round)`)

      if (isFreilos(eliminatedPlayer)) {
        console.error(`[v0] ✗ CRITICAL ERROR: Attempted to save Freilos ${eliminatedPlayer} to rankings! Aborting.`)
        return
      }

      const rankingData = {
        tournament_type: tournamentType,
        tournament_id: tournamentId,
        tournament_name: tournamentName,
        player_name: eliminatedPlayer,
        placement: placement,
        eliminated_at: new Date().toISOString(),
      }

      debugLog("[v0] Attempting to insert ranking data:", rankingData)

      const { data: insertData, error: insertError } = await supabase.from("dko_rankings").insert(rankingData).select()

      if (insertError) {
        if (insertError.code === "23505") {
          debugLog(
            `[v0] ℹ️ Player ${eliminatedPlayer} already exists in rankings (caught by database constraint), skipping`,
          )
          return
        }
        console.error("[v0] ✗ Error inserting ranking:", insertError)
        throw insertError
      }

      debugLog(`[v0] ✓ Successfully saved! Player ${eliminatedPlayer} - Placement: ${placement}`, insertData)
    } catch (error) {
      if (error && typeof error === "object" && "code" in error && error.code === "23505") {
        debugLog(`[v0] ℹ️ Player ${eliminatedPlayer} already ranked (duplicate prevented by database)`)
        return
      }
      console.error("[v0] Fehler beim Speichern der Platzierung:", error)
    }
  } else if (losses > 2) {
    debugLog(
      `[v0] ⚠️ WARNING: Player ${eliminatedPlayer} has ${losses} losses (more than 2)! This shouldn't happen in double elimination!`,
    )
  } else {
    debugLog(`[v0] Player ${eliminatedPlayer} only has ${losses} loss(es), not eliminated yet`)
  }
  debugLog(`[v0] ========================================`)
}

const saveFinalRankings = async (
  winner: string,
  runnerUp: string,
  tournamentType: string,
  tournamentId: string,
  tournamentName: string,
) => {
  try {
    debugLog(`[v0] Saving final rankings for tournament "${tournamentName}": 1st: ${winner}, 2nd: ${runnerUp}`)

    const { error: winnerError } = await supabase.from("dko_rankings").insert({
      tournament_type: tournamentType,
      tournament_id: tournamentId,
      tournament_name: tournamentName,
      player_name: winner,
      placement: 1,
      eliminated_at: new Date().toISOString(),
    })

    if (winnerError && winnerError.code !== "23505") {
      console.error("[v0] Error saving winner:", winnerError)
    }

    const { error: runnerUpError } = await supabase.from("dko_rankings").insert({
      tournament_type: tournamentType,
      tournament_id: tournamentId,
      tournament_name: tournamentName,
      player_name: runnerUp,
      placement: 2,
      eliminated_at: new Date().toISOString(),
    })

    if (runnerUpError && runnerUpError.code !== "23505") {
      console.error("[v0] Error saving runner-up:", runnerUpError)
    }

    debugLog(`[v0] Final rankings saved successfully!`)
  } catch (error) {
    console.error("Fehler beim Speichern der finalen Platzierungen:", error)
  }
}


const rebuildRankingsFromMatches = async ({
  tournamentId,
  tournamentType,
  tournamentName,
  bracketSize,
  matches,
}: {
  tournamentId: string
  tournamentType: string
  tournamentName: string
  bracketSize: number
  matches: Record<number, Match>
}) => {
  if (!tournamentId) {
    alert("Keine Turnier-ID gefunden!")
    return false
  }

  const cleanName = (name?: string | null) => String(name || "").trim()

  const isRealPlayer = (name?: string | null) => {
    const n = cleanName(name)
    return n !== "" && !isFreilos(n)
  }

  const realPlayers = new Set<string>()

  Object.values(matches).forEach((match) => {
    if (isRealPlayer(match.player1)) realPlayers.add(cleanName(match.player1))
    if (isRealPlayer(match.player2)) realPlayers.add(cleanName(match.player2))
  })

  if (realPlayers.size === 0) {
    alert("Keine echten Spieler im Turnier gefunden!")
    return false
  }

  const finalMatchId =
    bracketSize === 32
      ? matches[63]?.winner
        ? 63
        : 62
      : bracketSize === 16
        ? matches[31]?.winner
          ? 31
          : 30
        : matches[15]?.winner
          ? 15
          : 14

  const finalMatch = matches[finalMatchId]

  if (!finalMatch?.winner || !finalMatch?.loser) {
    alert("Finale ist noch nicht fertig. Rangliste kann nicht vollständig neu berechnet werden.")
    return false
  }

  const rebuiltRankings: {
    tournament_type: string
    tournament_id: string
    tournament_name: string
    player_name: string
    placement: number
    eliminated_at: string
  }[] = []

  realPlayers.forEach((playerName) => {
    const lostMatches = Object.values(matches)
      .filter((match) => match.winner && match.loser === playerName)
      .sort((a, b) => a.id - b.id)

    if (playerName === finalMatch.winner) {
      rebuiltRankings.push({
        tournament_type: tournamentType,
        tournament_id: tournamentId,
        tournament_name: tournamentName,
        player_name: playerName,
        placement: 1,
        eliminated_at: new Date().toISOString(),
      })
      return
    }

    if (playerName === finalMatch.loser) {
      rebuiltRankings.push({
        tournament_type: tournamentType,
        tournament_id: tournamentId,
        tournament_name: tournamentName,
        player_name: playerName,
        placement: 2,
        eliminated_at: new Date().toISOString(),
      })
      return
    }

    if (lostMatches.length >= 2) {
      const eliminationMatch = lostMatches[lostMatches.length - 1]
      const placement = getPlacementForEliminationMatch(eliminationMatch.id, bracketSize)

      rebuiltRankings.push({
        tournament_type: tournamentType,
        tournament_id: tournamentId,
        tournament_name: tournamentName,
        player_name: playerName,
        placement,
        eliminated_at: new Date().toISOString(),
      })
    }
  })

  const missingPlayers = Array.from(realPlayers).filter(
    (playerName) => !rebuiltRankings.some((r) => r.player_name === playerName),
  )

  if (missingPlayers.length > 0) {
    alert("Rangliste konnte nicht vollständig berechnet werden. Diese Spieler fehlen noch: " + missingPlayers.join(", "))
    return false
  }

  const { error: deleteError } = await supabase
    .from("dko_rankings")
    .delete()
    .eq("tournament_type", tournamentType)
    .eq("tournament_id", tournamentId)

  if (deleteError) {
    console.error("Fehler beim Löschen der alten Rankings:", deleteError)
    alert("Alte Rangliste konnte nicht gelöscht werden.")
    return false
  }

  const { error: insertError } = await supabase.from("dko_rankings").insert(rebuiltRankings)

  if (insertError) {
    console.error("Fehler beim Neuaufbau der Rankings:", insertError)
    alert("Neue Rangliste konnte nicht gespeichert werden.")
    return false
  }

  console.log("[DKO] Rangliste komplett neu berechnet:", rebuiltRankings)
  return true
}

const markTournamentAsCompleted = async (tournamentId: string) => {
  try {
    debugLog(`[v0] Marking tournament ${tournamentId} as completed`)

    const { error } = await supabase
      .from("tournaments_status")
      .update({ status: "completed", updated_at: new Date().toISOString() })
      .eq("tournament_id", tournamentId)

    if (error) throw error

    debugLog(`[v0] Tournament marked as completed successfully`)
  } catch (error) {
    console.error("Fehler beim Markieren des Turniers als abgeschlossen:", error)
  }
}

const markTournamentAsCancelled = async (tournamentId: string) => {
  try {
    debugLog(`[v0] Marking tournament ${tournamentId} as cancelled`)

    const { error } = await supabase
      .from("tournaments_status")
      .update({ status: "cancelled", updated_at: new Date().toISOString() })
      .eq("tournament_id", tournamentId)

    if (error) throw error

    debugLog(`[v0] Tournament marked as cancelled successfully`)
  } catch (error) {
    console.error("Fehler beim Markieren des Turniers als abgebrochen:", error)
  }
}

export default function TournamentBracket({ bracketSize = 8, tournamentType = "8er_dko" }: TournamentBracketProps) {
  const initializingRef = useRef(false)
  const autoResolveRanRef = useRef(false)

  const isRemoteUpdateRef = useRef(false)
  const [tournamentId, setTournamentId] = useState<string>("")
  const [tournamentName, setTournamentName] = useState<string>("")
  const [totalMachines, setTotalMachines] = useState<number>(10)
  const [machineDialogOpen, setMachineDialogOpen] = useState(false)
  const [selectedMatchId, setSelectedMatchId] = useState<number | null>(null)
  const [loading, setLoading] = useState(true)
  const [cancelDialogOpen, setCancelDialogOpen] = useState(false)
  const [rankingsDialogOpen, setRankingsDialogOpen] = useState(false)
  const [rankings, setRankings] = useState<Ranking[]>([])
  const [loadingRankings, setLoadingRankings] = useState(false)
  const [savingToSeries, setSavingToSeries] = useState(false)
  const [savingToSummerSpecial, setSavingToSummerSpecial] = useState(false)
  const [successDialogOpen, setSuccessDialogOpen] = useState(false)
  const [speechEnabled, setSpeechEnabled] = useState(false)
  const [profilePictures, setProfilePictures] = useState<Record<string, string>>({})
  const [playerIdMap, setPlayerIdMap] = useState<Record<string, string>>({})

  const { announce } = useSpeechAnnouncer({ enabled: speechEnabled })
  const router = useRouter()
  const searchParams = useSearchParams()
  const seriesId = searchParams.get("seriesId")
  const eventId = searchParams.get("eventId")
  const centralEventId = searchParams.get("centralEventId")


  // Playername -> spieldatenbank.id (für player1_id / player2_id in dko_match_states)
  useEffect(() => {
    const fetchPlayerIds = async () => {
      try {
        const { data, error } = await supabase.from("spieldatenbank").select("id, name")

        if (error) {
          console.error("Error fetching player ids:", error)
          return
        }

        const idMap: Record<string, string> = {}
        ;(data ?? []).forEach((p: any) => {
          if (p?.name && p?.id) idMap[String(p.name).toLowerCase().trim()] = String(p.id)
        })

        setPlayerIdMap(idMap)
        debugLog("[v0] Player IDs loaded:", Object.keys(idMap).length)
      } catch (err) {
        console.error("Error fetching player ids:", err)
      }
    }

    fetchPlayerIds()
  }, [])

  const [matches, setMatches] = useState<Record<number, Match>>(() => {
    const initialMatches: Record<number, Match> = {
      1: { id: 1, player1: "", player2: "", score1: 0, score2: 0 },
      2: { id: 2, player1: "", player2: "", score1: 0, score2: 0 },
      3: { id: 3, player1: "", player2: "", score1: 0, score2: 0 },
      4: { id: 4, player1: "", player2: "", score1: 0, score2: 0 },
      5: { id: 5, player1: "", player2: "", score1: 0, score2: 0 },
      6: { id: 6, player1: "", player2: "", score1: 0, score2: 0 },
      7: { id: 7, player1: "", player2: "", score1: 0, score2: 0 },
      8: { id: 8, player1: "", player2: "", score1: 0, score2: 0 },
      9: { id: 9, player1: "", player2: "", score1: 0, score2: 0 },
      10: { id: 10, player1: "", player2: "", score1: 0, score2: 0 },
      11: { id: 11, player1: "", player2: "", score1: 0, score2: 0 },
      12: { id: 12, player1: "", player2: "", score1: 0, score2: 0 },
      13: { id: 13, player1: "", player2: "", score1: 0, score2: 0 },
      14: { id: 14, player1: "", player2: "", score1: 0, score2: 0 },
      15: { id: 15, player1: "", player2: "", score1: 0, score2: 0 },
    }
    return initialMatches
  })
  
  
  
useEffect(() => {
  if (!tournamentId) return
  if (loading) return

  if (isRemoteUpdateRef.current) {
    isRemoteUpdateRef.current = false
    return
  }

  const timeoutId = setTimeout(() => {
    saveMatchStatesToDatabase(matches, tournamentType, tournamentId, playerIdMap)
  }, 300)

  return () => clearTimeout(timeoutId)
}, [matches])
  
  
  

useEffect(() => {
  if (loading || !tournamentId) return

  const channel = supabase
    .channel(`dko_match_states_${tournamentType}_${tournamentId}`)
    .on(
      "postgres_changes",
      {
        event: "*",
        schema: "public",
        table: "dko_match_states",
        filter: `tournament_id=eq.${tournamentId}`,
      },
      (payload: any) => {
        const record = payload?.new
        if (!record) return
        if (record.tournament_type && record.tournament_type !== tournamentType) return

        let progressedMatches: Record<number, Match> | null = null
        let didProgress = false

        setMatches((prev) => {
          const next = { ...prev }
          const prevMatch = next[record.match_id] || {
            id: record.match_id,
            player1: "",
            player2: "",
            score1: 0,
            score2: 0,
            callCount: 1,
          }

          const wasFinished = Boolean(prevMatch.winner)
          const isFinishedNow = Boolean(record.winner)

          const nextMatch = {
            ...prevMatch,
            id: record.match_id,
            player1: record.player1 || "",
            player2: record.player2 || "",
            score1: typeof record.score1 === "number" ? record.score1 : prevMatch.score1,
            score2: typeof record.score2 === "number" ? record.score2 : prevMatch.score2,
            winner: record.winner || undefined,
            loser: record.loser || undefined,
            machineNumber: record.machine_number || undefined,
            callCount: record.machine_number ? (prevMatch.callCount || 1) : undefined,
          }

          const isSame =
            prevMatch.player1 === nextMatch.player1 &&
            prevMatch.player2 === nextMatch.player2 &&
            prevMatch.score1 === nextMatch.score1 &&
            prevMatch.score2 === nextMatch.score2 &&
            prevMatch.winner === nextMatch.winner &&
            prevMatch.loser === nextMatch.loser &&
            prevMatch.machineNumber === nextMatch.machineNumber &&
            prevMatch.callCount === nextMatch.callCount

          if (isSame) {
            return prev
          }

          next[record.match_id] = nextMatch

          // Wichtig: Wenn Ergebnis aus dem LIVE-Center kommt, muss der Spieler hier
          // sofort in das nächste Match weitergeschrieben werden.
          if (!wasFinished && isFinishedNow && record.winner && record.loser) {
            applyCompletedMatch(next, record.match_id, record.winner, record.loser, {
              score1: typeof record.score1 === "number" ? record.score1 : nextMatch.score1,
              score2: typeof record.score2 === "number" ? record.score2 : nextMatch.score2,
            })

            didProgress = true
            progressedMatches = next
          }

          isRemoteUpdateRef.current = true
          return next
        })

        if (didProgress && progressedMatches) {
          saveMatchStatesToDatabase(progressedMatches, tournamentType, tournamentId, playerIdMap)
        }
      },
    )
    .subscribe()

  return () => {
    supabase.removeChannel(channel)
  }
}, [loading, tournamentId, tournamentType, tournamentName, bracketSize, playerIdMap])
  
  
  
  



useEffect(() => {
    if (loading || !tournamentId || autoResolveRanRef.current) return

    autoResolveRanRef.current = true

    const timer = setTimeout(() => {
      setMatches((prev) => {
        const newMatches = { ...prev }
        let hasChanges = false

        Object.values(newMatches).forEach((match: Match) => {
          if (match.winner || !match.player1 || !match.player2) return

          const isP1Freilos = isFreilos(match.player1)
          const isP2Freilos = isFreilos(match.player2)

          if (!isP1Freilos && !isP2Freilos) return

          const realPlayer = isP1Freilos ? match.player2 : match.player1
          const freilosPlayer = isP1Freilos ? match.player1 : match.player2

          debugLog(`[v0] Auto-resolving Freilos match ${match.id}: ${realPlayer} beats ${freilosPlayer}`)

          applyCompletedMatch(newMatches, match.id, realPlayer, freilosPlayer, {
            score1: isP1Freilos ? 0 : 2,
            score2: isP2Freilos ? 0 : 2,
          })

          hasChanges = true
        })

        autoResolveRanRef.current = false
        return hasChanges ? newMatches : prev
      })
    }, 100)

    return () => clearTimeout(timer)
}, [matches, loading, tournamentType, tournamentId])

  const getAvailableMachines = (): number[] => {
    const usedMachines = Object.values(matches)
      .filter((m) => m.machineNumber !== undefined && !m.winner)
      .map((m) => m.machineNumber!)

    return Array.from({ length: totalMachines }, (_, i) => i + 1).filter((num) => !usedMachines.includes(num))
  }


  const applyCompletedMatch = (
    allMatches: Record<number, Match>,
    matchId: number,
    winner: string,
    loser: string,
    extras?: Partial<Match>,
  ) => {
    const currentMatch = allMatches[matchId]
    if (!currentMatch) return allMatches

    allMatches[matchId] = {
      ...currentMatch,
      ...extras,
      winner,
      loser,
      machineNumber: undefined,
      callCount: undefined,
    }

    if (matchId === 14) {
      if (winner === allMatches[14].player1) {
        saveFinalRankings(winner, loser, tournamentType, tournamentId, tournamentName)
      } else {
        allMatches[15].player1 = allMatches[14].player1
        allMatches[15].player2 = allMatches[14].player2
      }
    } else if (matchId === 15) {
      saveFinalRankings(winner, loser, tournamentType, tournamentId, tournamentName)
    } else {
      progressPlayers(allMatches, matchId, winner, loser)
      trackPlayerElimination(allMatches, loser, tournamentType, tournamentId, tournamentName, bracketSize)
    }

    return allMatches
  }

  const fetchRankings = async () => {
    setLoadingRankings(true)
    try {
      const { data, error } = await supabase
        .from("dko_rankings")
        .select("player_name, placement, eliminated_at")
        .eq("tournament_type", tournamentType)
        .eq("tournament_id", tournamentId)
        .order("placement", { ascending: true })

      if (error) throw error

      setRankings(data || [])
      setRankingsDialogOpen(true)
    } catch (error) {
      console.error("Fehler beim Laden der Rangliste:", error)
      alert("Fehler beim Laden der Rangliste")
    } finally {
      setLoadingRankings(false)
    }
  }

  const saveToTournamentSeries = async () => {
    const winner = matches[15]?.winner || matches[14]?.winner

    if (!winner) {
      alert("Kein Gewinner gefunden!")
      return
    }

    const { data: existingHistory } = await supabase
      .from("tournament_series_history")
      .select("id")
      .eq("tournament_id", tournamentId)
      .maybeSingle()

    if (existingHistory) {
      alert("Dieses Turnier wurde bereits zur Serie hinzugefügt!")
      return
    }

    setSavingToSeries(true)

    try {
      const rankingsRebuiltForSeries = await rebuildRankingsFromMatches({
        tournamentId,
        tournamentType,
        tournamentName,
        bracketSize,
        matches,
      })

      if (!rankingsRebuiltForSeries) {
        setSavingToSeries(false)
        return
      }

      const { data: rankings, error: rankingsError } = await supabase
        .from("dko_rankings")
        .select("player_name, placement")
        .eq("tournament_type", tournamentType)
        .eq("tournament_id", tournamentId)
        .order("placement", { ascending: true })

      if (rankingsError) throw rankingsError

      if (!rankings || rankings.length === 0) {
        alert("Keine Rangliste gefunden! Bitte stelle sicher, dass das Turnier vollständig ist.")
        setSavingToSeries(false)
        return
      }

      const placementCounts: Record<number, number> = {}
      rankings.forEach((r) => {
        placementCounts[r.placement] = (placementCounts[r.placement] || 0) + 1
      })

      const tiersBelow: Record<number, number> = {}
      const sortedPlacements = Object.keys(placementCounts)
        .map(Number)
        .sort((a, b) => a - b)

      sortedPlacements.forEach((placement, index) => {
        tiersBelow[placement] = sortedPlacements.length - index - 1
      })

      debugLog("[v0] Placement counts:", placementCounts)
      debugLog("[v0] Tiers below each placement:", tiersBelow)

      const { data: matchStates, error: matchError } = await supabase
        .from("dko_match_states")
        .select("match_id, player1, player2, score1, score2, winner, updated_at")
        .eq("tournament_type", tournamentType)
        .eq("tournament_id", tournamentId)
        .order("match_id", { ascending: true })

      if (matchError) throw matchError

      const playerMatchHistory: Record<string, Array<{ matchId: number; result: "W" | "L"; timestamp: string }>> = {}

      matchStates?.forEach((match) => {
        if (!match.winner) return

        if (match.player1 && !isFreilos(match.player1)) {
          if (!playerMatchHistory[match.player1]) {
            playerMatchHistory[match.player1] = []
          }
          playerMatchHistory[match.player1].push({
            matchId: match.match_id,
            result: match.winner === match.player1 ? "W" : "L",
            timestamp: match.updated_at || new Date().toISOString(),
          })
        }

        if (match.player2 && !isFreilos(match.player2)) {
          if (!playerMatchHistory[match.player2]) {
            playerMatchHistory[match.player2] = []
          }
          playerMatchHistory[match.player2].push({
            matchId: match.match_id,
            result: match.winner === match.player2 ? "W" : "L",
            timestamp: match.updated_at || new Date().toISOString(),
          })
        }
      })

      Object.keys(playerMatchHistory).forEach((playerName) => {
        playerMatchHistory[playerName].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())
      })

      debugLog("[v0] Player match history:", playerMatchHistory)

      const bracketResetOccurred = matches[15]?.winner !== undefined
      debugLog("[v0] Bracket reset occurred:", bracketResetOccurred)

      const seriesRuntime = await loadSeriesScoringRuntime(seriesId)

      const playerStats: Record<
        string,
        {
          placement: number
          placement_points: number
          legs_points: number
          bonus_points: number
          legs_won: number
          legs_lost: number
          matches_played: number
          matches_won: number
          matches_lost: number
        }
      > = {}

      rankings.forEach((ranking) => {
        const playerName = ranking.player_name
        const placement = ranking.placement
        const placementPoints = calculateSeriesPlacementPoints(seriesRuntime, placement, tiersBelow[placement], 10 + tiersBelow[placement] * 2)
        const bonus = seriesRuntime ? 0 : placement === 1 && !bracketResetOccurred ? 5 : 0

        playerStats[playerName] = {
          placement: placement,
          placement_points: placementPoints,
          legs_points: 0,
          bonus_points: bonus,
          legs_won: 0,
          legs_lost: 0,
          matches_played: 0,
          matches_won: 0,
          matches_lost: 0,
        }
      })

      matchStates?.forEach((match) => {
        if (match.player1 && !isFreilos(match.player1)) {
          if (!playerStats[match.player1]) {
            playerStats[match.player1] = {
              placement: 0,
              placement_points: 0,
              legs_points: 0,
              bonus_points: 0,
              legs_won: 0,
              legs_lost: 0,
              matches_played: 0,
              matches_won: 0,
              matches_lost: 0,
            }
          }

          const score1 = match.score1 || 0
          const score2 = match.score2 || 0

          playerStats[match.player1].legs_won += score1
          playerStats[match.player1].legs_lost += score2
          playerStats[match.player1].legs_points += score1

          if (match.winner) {
            playerStats[match.player1].matches_played += 1
            if (match.winner === match.player1) {
              playerStats[match.player1].matches_won += 1
            } else {
              playerStats[match.player1].matches_lost += 1
            }
          }
        }

        if (match.player2 && !isFreilos(match.player2)) {
          if (!playerStats[match.player2]) {
            playerStats[match.player2] = {
              placement: 0,
              placement_points: 0,
              legs_points: 0,
              bonus_points: 0,
              legs_won: 0,
              legs_lost: 0,
              matches_played: 0,
              matches_won: 0,
              matches_lost: 0,
            }
          }

          const score1 = match.score1 || 0
          const score2 = match.score2 || 0

          playerStats[match.player2].legs_won += score2
          playerStats[match.player2].legs_lost += score1
          playerStats[match.player2].legs_points += score2

          if (match.winner) {
            playerStats[match.player2].matches_played += 1
            if (match.winner === match.player2) {
              playerStats[match.player2].matches_won += 1
            } else {
              playerStats[match.player2].matches_lost += 1
            }
          }
        }
      })

      Object.values(playerStats).forEach((stats) => {
        stats.legs_points = calculateSeriesLegPoints(seriesRuntime, stats.legs_won, stats.legs_points)
        stats.bonus_points = calculateSeriesWinnerBonus(seriesRuntime, stats.placement, stats.matches_lost, stats.bonus_points)
      })

      debugLog("[v0] Calculated player statistics:", playerStats)

      const tournamentEntries = Object.entries(playerStats).map(([playerName, stats]) => {
        const totalPoints = stats.placement_points + stats.legs_points + stats.bonus_points

        let form = ""
        if (stats.placement === 1) form = "W"
        else if (stats.placement <= 3) form = "D"
        else form = "L"

        const matchHistory = playerMatchHistory[playerName] || []
        const chronologicalForm = matchHistory.map((m) => m.result).join(",")

        debugLog(
          `[v0] ${playerName}: Platz ${stats.placement} | ` +
            `${stats.placement_points}P (Platzierung) + ${stats.legs_points}P (Legs) + ${stats.bonus_points}P (Bonus) = ${totalPoints}P | ` +
            `Legs: ${stats.legs_won}W-${stats.legs_lost}L | Matches: ${stats.matches_won}W-${stats.matches_lost}L | ` +
            `Form: ${chronologicalForm}`,
        )

        return {
          player_name: playerName,
          tournament_id: tournamentId,
          tournament_name: tournamentName,
          tournament_type: tournamentType,
          series_id: seriesId || null,
          event_id: eventId || null,
          tournament_date: new Date().toISOString(),
          placement: stats.placement,
          placement_points: stats.placement_points,
          legs_points: stats.legs_points,
          bonus_points: stats.bonus_points,
          total_points: totalPoints,
          legs_won: stats.legs_won,
          legs_lost: stats.legs_lost,
          matches_played: stats.matches_played,
          matches_won: stats.matches_won,
          matches_lost: stats.matches_lost,
          form: chronologicalForm,
        }
      })

      let existingSeriesRowsDelete = supabase
        .from("tournament_series_standings")
        .delete()
        .eq("tournament_id", tournamentId)
      if (seriesId) existingSeriesRowsDelete = existingSeriesRowsDelete.eq("series_id", seriesId)
      const { error: existingRowsError } = await existingSeriesRowsDelete
      if (existingRowsError) throw existingRowsError

      const { error: insertError } = await supabase.from("tournament_series_standings").insert(tournamentEntries)

      if (insertError) {
        console.error("[v0] Error inserting tournament entries:", insertError)
        throw insertError
      }

      debugLog(`[v0] Successfully inserted ${tournamentEntries.length} tournament entries`)

      let existingHistoryDelete = supabase
        .from("tournament_series_history")
        .delete()
        .eq("tournament_id", tournamentId)
      if (seriesId) existingHistoryDelete = existingHistoryDelete.eq("series_id", seriesId)
      const { error: existingHistoryError } = await existingHistoryDelete
      if (existingHistoryError) throw existingHistoryError

      const { error: historyError } = await supabase.from("tournament_series_history").insert({
        tournament_id: tournamentId,
        tournament_name: tournamentName,
        tournament_type: tournamentType,
        series_id: seriesId || null,
        event_id: eventId || null,
        added_at: new Date().toISOString(),
      })

      if (historyError) throw historyError

      await markTournamentAsCompleted(tournamentId)

      await deleteFreiloseFromDatabase(tournamentType, tournamentId)

      await clearTournamentRegistration(seriesId, eventId)

      setSuccessDialogOpen(false)
      router.push("/admin/einzelturnier")
    } catch (error) {
      console.error("Fehler beim Speichern zur Turnierserie:", error)
      alert("Fehler beim Speichern zur Turnierserie. Bitte versuche es erneut.")
    } finally {
      setSavingToSeries(false)
    }
  }


  const saveToSummerSpecial = async () => {
    const winner = matches[15]?.winner || matches[14]?.winner

    if (!winner) {
      alert("Kein Gewinner gefunden!")
      return
    }

    setSavingToSummerSpecial(true)

    try {
      const { data: existingRows, error: existingError } = await supabase
        .from("summer_special_standings")
        .select("id")
        .eq("tournament_id", tournamentId)
        .limit(1)

      if (existingError) throw existingError

      if (existingRows && existingRows.length > 0) {
        alert("Dieses Turnier wurde bereits zum Summer Special hinzugefügt!")
        return
      }

      const rankingsRebuilt = await rebuildRankingsFromMatches({
        tournamentId,
        tournamentType,
        tournamentName,
        bracketSize,
        matches,
      })

      if (!rankingsRebuilt) {
        setSavingToSummerSpecial(false)
        return
      }

      const { data: rankings, error: rankingsError } = await supabase
        .from("dko_rankings")
        .select("player_name, placement")
        .eq("tournament_type", tournamentType)
        .eq("tournament_id", tournamentId)
        .order("placement", { ascending: true })

      if (rankingsError) throw rankingsError

      if (!rankings || rankings.length === 0) {
        alert("Keine Rangliste gefunden! Bitte stelle sicher, dass das Turnier vollständig ist.")
        return
      }

      const placementCounts: Record<number, number> = {}
      rankings.forEach((r) => {
        placementCounts[r.placement] = (placementCounts[r.placement] || 0) + 1
      })

      const tiersBelow: Record<number, number> = {}
      const sortedPlacements = Object.keys(placementCounts).map(Number).sort((a, b) => a - b)

      sortedPlacements.forEach((placement, index) => {
        tiersBelow[placement] = sortedPlacements.length - index - 1
      })

      const { data: matchStates, error: matchError } = await supabase
        .from("dko_match_states")
        .select("match_id, player1, player2, score1, score2, winner, updated_at")
        .eq("tournament_type", tournamentType)
        .eq("tournament_id", tournamentId)
        .order("match_id", { ascending: true })

      if (matchError) throw matchError

      const bracketResetOccurred = matches[15]?.winner !== undefined
      const playerStats: Record<string, any> = {}

      rankings.forEach((ranking) => {
        const placementPoints = 10 + tiersBelow[ranking.placement] * 2
        const winnerSideBonus = ranking.placement === 1 && !bracketResetOccurred

        playerStats[ranking.player_name] = {
          placement: ranking.placement,
          placement_points: placementPoints,
          bonus_points: 0,
          winner_side_bonus: winnerSideBonus,
          legs_won: 0,
          legs_lost: 0,
          matches_played: 0,
          matches_won: 0,
          matches_lost: 0,
          match_history: [],
        }
      })

      matchStates?.forEach((match) => {
        if (match.player1 && !isFreilos(match.player1) && playerStats[match.player1]) {
          playerStats[match.player1].legs_won += match.score1 || 0
          playerStats[match.player1].legs_lost += match.score2 || 0

          if (match.winner) {
            playerStats[match.player1].matches_played += 1
            const result = match.winner === match.player1 ? "W" : "L"
            if (result === "W") playerStats[match.player1].matches_won += 1
            else playerStats[match.player1].matches_lost += 1

            playerStats[match.player1].match_history.push({
              match_id: match.match_id,
              result,
              timestamp: match.updated_at || new Date().toISOString(),
            })
          }
        }

        if (match.player2 && !isFreilos(match.player2) && playerStats[match.player2]) {
          playerStats[match.player2].legs_won += match.score2 || 0
          playerStats[match.player2].legs_lost += match.score1 || 0

          if (match.winner) {
            playerStats[match.player2].matches_played += 1
            const result = match.winner === match.player2 ? "W" : "L"
            if (result === "W") playerStats[match.player2].matches_won += 1
            else playerStats[match.player2].matches_lost += 1

            playerStats[match.player2].match_history.push({
              match_id: match.match_id,
              result,
              timestamp: match.updated_at || new Date().toISOString(),
            })
          }
        }
      })

      const summerRows = Object.entries(playerStats).map(([playerName, stats]: any) => {
        stats.match_history.sort((a: any, b: any) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())
        const form = stats.match_history.map((h: any) => h.result).join(",")

        return {
          player_name: playerName,
          tournament_id: tournamentId,
          tournament_name: tournamentName,
          tournament_type: tournamentType,
          tournament_date: new Date().toISOString(),
          placement: stats.placement,
          placement_points: stats.placement_points,
          bonus_points: stats.bonus_points,
          winner_side_bonus: stats.winner_side_bonus,
          legs_won: stats.legs_won,
          legs_lost: stats.legs_lost,
          matches_played: stats.matches_played,
          matches_won: stats.matches_won,
          matches_lost: stats.matches_lost,
          form,
        }
      })

      const { error: insertError } = await supabase.from("summer_special_standings").insert(summerRows)

      if (insertError) throw insertError

      await markTournamentAsCompleted(tournamentId)
      await deleteFreiloseFromDatabase(tournamentType, tournamentId)
      await clearTournamentRegistration(seriesId, eventId)

      router.push("/admin/einzelturnier")
    } catch (error) {
      console.error("Fehler beim Speichern zum Summer Special:", error)
      alert("Fehler beim Speichern zum Summer Special.")
    } finally {
      setSavingToSummerSpecial(false)
    }
  }

  const startMatch = (matchId: number) => {
    const match = matches[matchId]
    if (!match.player1 || !match.player2) {
      alert("Beide Spieler müssen verfügbar sein!")
      return
    }

    const isP1Freilos = isFreilos(match.player1)
    const isP2Freilos = isFreilos(match.player2)

    if (isP1Freilos && isP2Freilos) {
      debugLog(`[v0] Auto-resolving Freilos vs Freilos match ${matchId}: ${match.player1} vs ${match.player2}`)
      setMatches((prev) => {
        const newMatches = { ...prev }
        return applyCompletedMatch(newMatches, matchId, match.player1, match.player2, {
          score1: 2,
          score2: 0,
        })
      })
      return
    }

    if (isP1Freilos || isP2Freilos) {
      const realPlayer = isP1Freilos ? match.player2 : match.player1
      const freilosPlayer = isP1Freilos ? match.player1 : match.player2

      debugLog(`[v0] Auto-resolving Freilos match ${matchId}: ${realPlayer} beats ${freilosPlayer}`)
      setMatches((prev) => {
        const newMatches = { ...prev }
        return applyCompletedMatch(newMatches, matchId, realPlayer, freilosPlayer, {
          score1: isP1Freilos ? 0 : 2,
          score2: isP2Freilos ? 0 : 2,
        })
      })
      return
    }

    if (match.machineNumber) {
      alert(`Dieses Spiel läuft bereits auf Automat ${match.machineNumber}`)
      return
    }
    setSelectedMatchId(matchId)
    setMachineDialogOpen(true)
  }
  
  
  

 const assignMachine = async (machineNumber: number) => {
  if (selectedMatchId === null) return
  if (!tournamentId) return

  const currentMatchId = selectedMatchId
  const match = matches[currentMatchId]

  if (!match || !match.player1 || !match.player2 || match.winner) {
    return
  }

  if (match.machineNumber) {
    alert(`Dieses Spiel läuft bereits auf Automat ${match.machineNumber}`)
    return
  }

  const updatedMatch = {
    ...match,
    machineNumber,
    callCount: 1,
  }

  try {
    const getId = (name: string) => {
      const key = (name ?? "").toLowerCase().trim()
      if (!key || key.startsWith("freilos")) return null
      return playerIdMap[key] ?? null
    }

    const payload = {
      tournament_type: tournamentType,
      tournament_id: tournamentId,
      match_id: currentMatchId,
      player1: updatedMatch.player1,
      player2: updatedMatch.player2,
      player1_id: getId(updatedMatch.player1),
      player2_id: getId(updatedMatch.player2),
      score1: updatedMatch.score1,
      score2: updatedMatch.score2,
      winner: updatedMatch.winner || null,
      loser: updatedMatch.loser || null,
      machine_number: updatedMatch.machineNumber || null,
      updated_at: new Date().toISOString(),
    }

    const { error } = await supabase.from("dko_match_states").upsert(payload, {
      onConflict: "tournament_type,tournament_id,match_id",
    })

    if (error) {
      console.error("[v0] Error starting match immediately:", error)
      alert("Spiel konnte nicht gestartet werden. Bitte erneut versuchen.")
      return
    }

    isRemoteUpdateRef.current = true

    setMatches((prev) => ({
      ...prev,
      [currentMatchId]: {
        ...prev[currentMatchId],
        machineNumber,
        callCount: 1,
      },
    }))

    if (speechEnabled) {
      announce(match.player1, match.player2, machineNumber, 1)
    }

    setMachineDialogOpen(false)
    setSelectedMatchId(null)
  } catch (err) {
    console.error("[v0] Fehler beim direkten Starten des Spiels:", err)
    alert("Spiel konnte nicht gestartet werden. Bitte erneut versuchen.")
  }
}
  
  
  
  

  const repeatCall = (matchId: number) => {
    const match = matches[matchId]
    if (!match.machineNumber || !match.player1 || !match.player2) return

    const currentCall = match.callCount || 1
    const nextCall = Math.min(currentCall + 1, 3)

    setMatches((prev) => ({
      ...prev,
      [matchId]: {
        ...prev[matchId],
        callCount: nextCall,
      },
    }))

    announce(match.player1, match.player2, match.machineNumber, nextCall)
  }

const updateScore = (matchId: number, player: 1 | 2, score: number) => {
  setMatches((prev) => ({
    ...prev,
    [matchId]: {
      ...prev[matchId],
      [player === 1 ? "score1" : "score2"]: score,
    },
  }))
}









const confirmMatch = async (matchId: number) => {
  if (!tournamentId) return

  const currentMatch = matches[matchId]
  if (!currentMatch) return

  const match = { ...currentMatch }

  if (match.score1 > match.score2) {
    match.winner = match.player1
    match.loser = match.player2
  } else if (match.score2 > match.score1) {
    match.winner = match.player2
    match.loser = match.player1
  } else {
    alert("Unentschieden ist nicht erlaubt!")
    return
  }

  match.machineNumber = undefined
  match.callCount = undefined

  const newMatches = { ...matches }
  newMatches[matchId] = match

  applyCompletedMatch(newMatches, matchId, match.winner!, match.loser!)

  try {
    await saveMatchStatesToDatabase(newMatches, tournamentType, tournamentId, playerIdMap, matches)

    isRemoteUpdateRef.current = true
    setMatches(newMatches)
  } catch (error) {
    console.error("Fehler beim direkten Bestätigen des Ergebnisses:", error)
    alert("Ergebnis konnte nicht gespeichert werden. Bitte erneut versuchen.")
  }
}





  const progressPlayers = (allMatches: Record<number, Match>, matchId: number, winner: string, loser: string) => {
    debugLog(`[v0] ========== PROGRESSING PLAYERS ==========`)
    debugLog(`[v0] Match ${matchId} completed: Winner: ${winner}, Loser: ${loser}`)

    const progressionMap: Record<
      number,
      { winner: { matchId: number; position: 1 | 2 } | null; loser: { matchId: number; position: 1 | 2 } | null }
    > = {
      1: { winner: { matchId: 5, position: 1 }, loser: { matchId: 8, position: 1 } },
      2: { winner: { matchId: 5, position: 2 }, loser: { matchId: 8, position: 2 } },
      3: { winner: { matchId: 6, position: 1 }, loser: { matchId: 9, position: 1 } },
      4: { winner: { matchId: 6, position: 2 }, loser: { matchId: 9, position: 2 } },
      5: { winner: { matchId: 7, position: 1 }, loser: { matchId: 11, position: 2 } },
      6: { winner: { matchId: 7, position: 2 }, loser: { matchId: 10, position: 2 } },
      7: { winner: { matchId: 14, position: 1 }, loser: { matchId: 13, position: 2 } },
      8: { winner: { matchId: 10, position: 1 }, loser: null },
      9: { winner: { matchId: 11, position: 1 }, loser: null },
      10: { winner: { matchId: 12, position: 1 }, loser: null },
      11: { winner: { matchId: 12, position: 2 }, loser: null },
      12: { winner: { matchId: 13, position: 1 }, loser: null },
      13: { winner: { matchId: 14, position: 2 }, loser: null },
      14: { winner: null, loser: null },
      15: { winner: null, loser: null },
    }

    const progression = progressionMap[matchId]
    if (!progression) {
      debugLog(`[v0] ⚠️ No progression defined for match ${matchId}`)
      return
    }

    if (progression.winner) {
	if (!allMatches[progression.winner.matchId]) {
  allMatches[progression.winner.matchId] = {
    id: progression.winner.matchId,
    player1: undefined,
    player2: undefined,
    winner: undefined,
    loser: undefined,
    score1: 0,
    score2: 0,
  }
}
      const { matchId: targetMatch, position } = progression.winner
      debugLog(`[v0] ✓ Winner ${winner} progresses to Match ${targetMatch} position ${position}`)

      const targetMatchBefore = { ...allMatches[targetMatch] }

      if (position === 1) {
        allMatches[targetMatch].player1 = winner
      } else {
        allMatches[targetMatch].player2 = winner
      }

      debugLog(
        `[v0]   Match ${targetMatch} before: P1="${targetMatchBefore.player1}" P2="${targetMatchBefore.player2}"`,
      )
      debugLog(
        `[v0]   Match ${targetMatch} after:  P1="${allMatches[targetMatch].player1}" P2="${allMatches[targetMatch].player2}"`,
      )

      if (allMatches[targetMatch].player1 && allMatches[targetMatch].player2 && !allMatches[targetMatch].winner) {
        debugLog(`[v0]   ✓ Match ${targetMatch} now has both players, checking for optimization...`)
        optimizeMatchInRound(allMatches, targetMatch)
        autoResolveFreilosMatch(allMatches, targetMatch)
      }
    } else {
      debugLog(`[v0] ✓ Winner ${winner} has no further progression (reached final or waiting)`)
    }

    if (progression.loser) {
	if (!allMatches[progression.loser.matchId]) {
  allMatches[progression.loser.matchId] = {
    id: progression.loser.matchId,
    player1: undefined,
    player2: undefined,
    winner: undefined,
    loser: undefined,
    score1: 0,
    score2: 0,
  }
}
	
      const { matchId: targetMatch, position } = progression.loser
      debugLog(`[v0] ↓ Loser ${loser} drops to Match ${targetMatch} position ${position} (1st loss)`)

      const targetMatchBefore = { ...allMatches[targetMatch] }

      if (position === 1) {
        allMatches[targetMatch].player1 = loser
      } else {
        allMatches[targetMatch].player2 = loser
      }

      debugLog(
        `[v0]   Match ${targetMatch} before: P1="${targetMatchBefore.player1}" P2="${targetMatchBefore.player2}"`,
      )
      debugLog(
        `[v0]   Match ${targetMatch} after:  P1="${allMatches[targetMatch].player1}" P2="${allMatches[targetMatch].player2}"`,
      )

      if (allMatches[targetMatch].player1 && allMatches[targetMatch].player2 && !allMatches[targetMatch].winner) {
        debugLog(`[v0]   ✓ Match ${targetMatch} now has both players, checking for optimization...`)
        optimizeMatchInRound(allMatches, targetMatch)
        autoResolveFreilosMatch(allMatches, targetMatch)
      }
    } else {
      debugLog(`[v0] ✗ Loser ${loser} is ELIMINATED (2nd loss, no further progression)`)
    }
    debugLog(`[v0] ==========================================`)
  }

  const optimizeMatchInRound = (allMatches: Record<number, Match>, matchId: number) => {
    const match = allMatches[matchId]

    if (match.winner) return

    const isP1Freilos = isFreilos(match.player1)
    const isP2Freilos = isFreilos(match.player2)

    if (isP1Freilos && isP2Freilos) {
      const nearbyMatches = findNearbyMatches(matchId)

      for (const nearbyId of nearbyMatches) {
        const nearbyMatch = allMatches[nearbyId]

        if (!nearbyMatch.player1 || !nearbyMatch.player2 || nearbyMatch.winner) continue

        const isNearbyP1Freilos = isFreilos(nearbyMatch.player1)
        const isNearbyP2Freilos = isFreilos(nearbyMatch.player2)

        if (!isNearbyP1Freilos && !isNearbyP2Freilos) {
          const temp = match.player2
          match.player2 = nearbyMatch.player2
          nearbyMatch.player2 = temp
          debugLog(
            `[v0] Optimized: Swapped ${nearbyMatch.player2} from Match ${nearbyId} with ${match.player2} from Match ${matchId}`,
          )
          return
        }

        if (!isNearbyP1Freilos && isNearbyP2Freilos) {
          const temp = match.player1
          match.player1 = nearbyMatch.player2
          nearbyMatch.player2 = temp
          debugLog(`[v0] Optimized: Swapped Freilos from Match ${nearbyId} with Freilos from Match ${matchId}`)
          return
        }

        if (isNearbyP1Freilos && !isNearbyP2Freilos) {
          const temp = match.player1
          match.player1 = nearbyMatch.player1
          nearbyMatch.player1 = temp
          debugLog(`[v0] Optimized: Swapped Freilos from Match ${nearbyId} with Freilos from Match ${matchId}`)
          return
        }
      }
    } else if (!isP1Freilos && !isP2Freilos) {
      const nearbyMatches = findNearbyMatches(matchId)

      for (const nearbyId of nearbyMatches) {
        const nearbyMatch = allMatches[nearbyId]

        if (!nearbyMatch.player1 || !nearbyMatch.player2 || nearbyMatch.winner) continue

        const isNearbyP1Freilos = isFreilos(nearbyMatch.player1)
        const isNearbyP2Freilos = isFreilos(nearbyMatch.player2)

        if (isNearbyP1Freilos && isNearbyP2Freilos) {
          const temp = match.player2
          match.player2 = nearbyMatch.player2
          nearbyMatch.player2 = temp
          debugLog(
            `[v0] Optimized: Swapped ${match.player2} from Match ${matchId} with ${nearbyMatch.player2} from Match ${nearbyId}`,
          )
          return
        }
      }
    }
  }

  const findNearbyMatches = (matchId: number): number[] => {
    const rounds: Record<string, number[]> = {
      round1: [1, 2, 3, 4],
      loser1: [8, 9],
      round2: [5, 6],
      loser2: [10, 11],
      loser3: [12],
      semi: [7],
      loser4: [13],
      final: [14],
      reset: [15],
    }

    for (const [roundName, matches] of Object.entries(rounds)) {
      if (matches.includes(matchId)) {
        return matches.filter((id) => id !== matchId)
      }
    }

    return []
  }

  const handleCancelClick = () => {
    setCancelDialogOpen(true)
  }

  const handleConfirmCancel = async () => {
    setCancelDialogOpen(false)
    await markTournamentAsCancelled(tournamentId)
    await deleteMatchStatesFromDatabase(tournamentType, tournamentId)
    await deleteRankingsFromDatabase(tournamentType, tournamentId)
    await deleteFreiloseFromDatabase(tournamentType, tournamentId)
    // Bei Serien-Abbruch bleiben die Voranmeldungen erhalten, damit derselbe Spieltag sauber neu gestartet werden kann.
    if (!seriesId && !eventId) {
      await clearTournamentRegistration(seriesId, eventId)
    }
    if (centralEventId) {
      const { error: centralEventError } = await supabase
        .from("central_tournament_events")
        .update({ status: "ready", updated_at: new Date().toISOString() })
        .eq("id", centralEventId)
      if (centralEventError) {
        console.error("Fehler beim Zurücksetzen des Zentral-Turniers:", centralEventError)
      }
    }
    try {
      window.sessionStorage.setItem("emd-admin-current-view", "tournament-center")
    } catch {}
    router.push(seriesId && eventId ? "/admin/turnier_spieltage_starten" : "/admin")
  }

  const resetMatch = async (matchId: number) => {
    const match = matches[matchId]

    if (matchId === 14 || matchId === 15) {
      debugLog(`[v0] Resetting finale Match ${matchId}, removing both players from rankings...`)

      if (match.player1) {
        await removePlayerFromRankings(match.player1, tournamentType, tournamentId)
      }
      if (match.player2) {
        await removePlayerFromRankings(match.player2, tournamentType, tournamentId)
      }
    } else {
      const oldLoser = match.loser

      if (oldLoser) {
        const lossMatches = Object.values(matches).filter((m) => m.loser === oldLoser && m.winner)
        const losses = lossMatches.length

        debugLog(`[v0] Resetting Match ${matchId}: ${oldLoser} had ${losses} losses before reset`)

        if (losses === 2) {
          debugLog(`[v0] ${oldLoser} was eliminated, removing from rankings...`)
          await removePlayerFromRankings(oldLoser, tournamentType, tournamentId)
        }
      }
    }

    setMatches((prev) => {
      const newMatches = { ...prev }
      const match = newMatches[matchId]

      const oldWinner = match.winner
      const oldLoser = match.loser

      newMatches[matchId] = {
        ...match,
        score1: 0,
        score2: 0,
        winner: undefined,
        loser: undefined,
        machineNumber: undefined,
        callCount: undefined,
      }

      if (oldWinner || oldLoser) {
        clearSubsequentMatches(newMatches, matchId, oldWinner, oldLoser)
        // Also purge the affected players from any later matches (cascade reset)
        purgePlayerFromFutureMatches(newMatches, matchId, oldWinner)
        purgePlayerFromFutureMatches(newMatches, matchId, oldLoser)
      }

      return newMatches
    })
  }

  const clearSubsequentMatches = (
    allMatches: Record<number, Match>,
    matchId: number,
    winner?: string,
    loser?: string,
  ) => {
    if (matchId === 1 || matchId === 2) {
      if (allMatches[5]?.player1 === winner) allMatches[5].player1 = ""
      if (allMatches[5]?.player2 === winner) allMatches[5].player2 = ""
    } else if (matchId === 3 || matchId === 4) {
      if (allMatches[6]?.player1 === winner) allMatches[6].player1 = ""
      if (allMatches[6]?.player2 === winner) allMatches[6].player2 = ""
    } else if (matchId === 5 || matchId === 6) {
      if (allMatches[7]?.player1 === winner) allMatches[7].player1 = ""
      if (allMatches[7]?.player2 === winner) allMatches[7].player2 = ""
    } else if (matchId === 7) {
      if (allMatches[14]?.player1 === winner) allMatches[14].player1 = ""
    } else if (matchId === 14 && winner === allMatches[14].player1) {
      if (allMatches[15]?.player1 === winner) allMatches[15].player1 = ""
      if (allMatches[15]?.player2 === winner) allMatches[15].player2 = ""
    }

    if (matchId === 1 || matchId === 2) {
      if (allMatches[8]?.player1 === loser) allMatches[8].player1 = ""
      if (allMatches[8]?.player2 === loser) allMatches[8].player2 = ""
    } else if (matchId === 3 || matchId === 4) {
      if (allMatches[9]?.player1 === loser) allMatches[9].player1 = ""
      if (allMatches[9]?.player2 === loser) allMatches[9].player2 = ""
    } else if (matchId === 5 || matchId === 6) {
      if (allMatches[11]?.player1 === loser) allMatches[11].player1 = ""
      if (allMatches[11]?.player2 === loser) allMatches[11].player2 = ""
    } else if (matchId === 8 || matchId === 9) {
      if (allMatches[10]?.player1 === loser) allMatches[10].player1 = ""
      if (allMatches[10]?.player2 === loser) allMatches[10].player2 = ""
    } else if (matchId === 10 || matchId === 11) {
      if (allMatches[12]?.player1 === loser) allMatches[12].player1 = ""
      if (allMatches[12]?.player2 === loser) allMatches[12].player2 = ""
    } else if (matchId === 12) {
      if (allMatches[13]?.player1 === loser) allMatches[13].player1 = ""
      if (allMatches[13]?.player2 === loser) allMatches[13].player2 = ""
    } else if (matchId === 7) {
      if (allMatches[13]?.player1 === loser) allMatches[13].player1 = ""
    } else if (matchId === 13) {
      if (allMatches[14]?.player2 === loser) allMatches[14].player2 = ""
    } else if (matchId === 14 && loser === allMatches[14].player1) {
      if (allMatches[15]?.player1 === loser) allMatches[15].player1 = ""
      if (allMatches[15]?.player2 === loser) allMatches[15].player2 = ""
    } else if (matchId === 14 && loser === allMatches[14].player2) {
      if (allMatches[15]?.player1 === loser) allMatches[15].player1 = ""
      if (allMatches[15]?.player2 === loser) allMatches[15].player2 = ""
    }
  }

  
  // When a match is reset, we must also remove the affected players from ALL later matches.
  // Otherwise the database can keep "stale" players in lower rounds (because they had already progressed further).
  const purgePlayerFromFutureMatches = (allMatches: Record<number, Match>, fromMatchId: number, player?: string) => {
    if (!player) return
    if (isFreilos(player)) return

    Object.values(allMatches).forEach((m) => {
      if (!m) return
      // only touch matches AFTER the reset match
      if (m.id <= fromMatchId) return

      let changed = false

      if (m.player1 === player) {
        m.player1 = ""
        m.score1 = 0
        changed = true
      }
      if (m.player2 === player) {
        m.player2 = ""
        m.score2 = 0
        changed = true
      }

      if (m.winner === player) {
        m.winner = undefined
        changed = true
      }
      if (m.loser === player) {
        m.loser = undefined
        changed = true
      }

      if (changed) {
        // If we removed somebody, also clear machine assignment so it doesn't show as "live"
        m.machineNumber = undefined
        m.callCount = undefined
      }
    })
  }
  
  
  

const autoResolveFreilosMatch = (allMatches: Record<number, Match>, matchId: number) => {
  const match = allMatches[matchId]
  if (!match || match.winner || !match.player1 || !match.player2) return

  const isP1Freilos = isFreilos(match.player1)
  const isP2Freilos = isFreilos(match.player2)

  if (!isP1Freilos && !isP2Freilos) return
  if (isP1Freilos && isP2Freilos) return

  const realPlayer = isP1Freilos ? match.player2 : match.player1
  const freilosPlayer = isP1Freilos ? match.player1 : match.player2

  debugLog(`[v0] Auto-resolving Freilos match ${matchId}: ${realPlayer} beats ${freilosPlayer}`)

  applyCompletedMatch(allMatches, matchId, realPlayer, freilosPlayer, {
    score1: isP1Freilos ? 0 : 2,
    score2: isP2Freilos ? 0 : 2,
    machineNumber: undefined,
    callCount: undefined,
  })
}




  useEffect(() => {
    const fetchRegisteredPlayers = async () => {
      if (initializingRef.current) {
        debugLog("[v0] Already initializing, skipping duplicate call")
        return
      }

      initializingRef.current = true

      try {
        const urlTournamentId = searchParams.get("tournamentId")
        const urlTournamentName = searchParams.get("tournamentName")
        let currentTournamentId: string

        if (urlTournamentId) {
          currentTournamentId = urlTournamentId
          debugLog("[v0] Using existing tournament ID from URL:", currentTournamentId)
        } else {
          currentTournamentId = crypto.randomUUID()
          debugLog("[v0] Generated new tournament ID:", currentTournamentId)

          const newUrl = new URL(window.location.href)
          newUrl.searchParams.set("tournamentId", currentTournamentId)
          if (urlTournamentName) {
            newUrl.searchParams.set("tournamentName", urlTournamentName)
          }
          newUrl.searchParams.delete("shuffle")
          window.history.replaceState({}, "", newUrl.toString())
        }

        setTournamentId(currentTournamentId)

        if (urlTournamentName) {
          const decodedName = decodeURIComponent(urlTournamentName)
          setTournamentName(decodedName)
          debugLog("[v0] Tournament name from URL:", decodedName)
        } else {
          setTournamentName("Unbenanntes Turnier")
          debugLog("[v0] No tournament name provided, using default")
        }

        const savedMatches = await loadMatchStatesFromDatabase(tournamentType, currentTournamentId)

        if (savedMatches) {
          debugLog("[v0] ✓ Loaded saved tournament state - tournament will continue from where it left off")
          setMatches((prev) => ({ ...prev, ...savedMatches }))
          setLoading(false)
          return
        }

        debugLog("[v0] No saved state found - initializing new tournament")

        const { error: statusError } = await supabase.from("tournaments_status").insert({
          tournament_id: currentTournamentId,
          tournament_type: tournamentType,
          tournament_name: urlTournamentName ? decodeURIComponent(urlTournamentName) : "Unbenanntes Turnier",
          status: "active",
          central_event_id: centralEventId || null,
          series_id: seriesId || null,
          series_event_id: eventId || null,
        })

        if (statusError && statusError.code !== "23505") {
          console.error("[v0] Error creating tournament status:", statusError)
        }

        let registrationQuery = supabase
          .from("dko_tournament_registration")
          .select("player_name")
          .order("registered_at", { ascending: true })

        if (eventId) registrationQuery = registrationQuery.eq("event_id", eventId)
        else if (seriesId) registrationQuery = registrationQuery.eq("series_id", seriesId)
        else registrationQuery = registrationQuery.is("event_id", null).is("series_id", null)

        const { data, error } = await registrationQuery

        if (error) throw error

        if (data && data.length > 0) {
          let playerNames = data.map((p) => p.player_name)

          const existingFreilose = await loadFreiloseFromDatabase(tournamentType, currentTournamentId)

          if (existingFreilose.length === 0) {
            debugLog("[v0] No existing Freilose found, creating new ones")
            playerNames = distributePlayersWithFreilose(playerNames, bracketSize)

            const freilose = playerNames.filter((name) => isFreilos(name))
            if (freilose.length > 0) {
              debugLog("[v0] Saving", freilose.length, "Freilose to database")
              await saveFreiloseToDatabase(freilose, tournamentType, currentTournamentId)
            }
          } else {
            debugLog("[v0] Using existing Freilose from database:", existingFreilose)
            const freilosCount = bracketSize - playerNames.length
            if (freilosCount > 0) {
              playerNames = [...playerNames, ...existingFreilose.slice(0, freilosCount)]
            }
          }

          setMatches((prev) => {
            const newMatches = { ...prev }

            const firstRoundMatches = bracketSize / 2
            for (let i = 0; i < firstRoundMatches; i++) {
              const matchId = i + 1
              const player1Index = i * 2
              const player2Index = i * 2 + 1

              newMatches[matchId] = {
                ...newMatches[matchId],
                player1: playerNames[player1Index] || "",
                player2: playerNames[player2Index] || "",
              }
            }

            return newMatches
          })
        }
      } catch (error) {
        console.error("Fehler beim Laden der registrierten Spieler:", error)
      } finally {
        setLoading(false)
        initializingRef.current = false
      }
    }

    fetchRegisteredPlayers()
  }, [searchParams, bracketSize, tournamentType])

  const availableMachines = getAvailableMachines()

  const allMatches = Object.values(matches)
  const activeLiveMatches = allMatches
    .filter((match) => match.player1 && match.player2 && !match.winner && match.machineNumber)
    .sort((a, b) => (a.machineNumber || 0) - (b.machineNumber || 0))
  const readyMatches = allMatches.filter((match) => match.player1 && match.player2 && !match.winner && !match.machineNumber)
  const completedMatches = allMatches.filter((match) => Boolean(match.winner))
  const liveMachineNumbers = activeLiveMatches
    .map((match) => match.machineNumber)
    .filter((value): value is number => Boolean(value))
  const totalMatchCount = 15
  const completedCount = completedMatches.length
  const remainingCount = Math.max(totalMatchCount - completedCount, 0)
  const liveCompletion = Math.round((completedCount / totalMatchCount) * 100)
  const winnerName = matches[15]?.winner || (matches[14]?.winner === matches[14]?.player1 ? matches[14]?.winner : undefined)

  const openBeamer = () => {
    if (!tournamentId) return

    const params = new URLSearchParams({
      tournamentId,
      tournamentName,
      tournamentType,
    })

    window.open(
      `/8erdko/beamer?${params.toString()}`,
      "dko-beamer",
      "popup=yes,width=1600,height=900",
    )
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-[#050608] flex items-center justify-center text-white">
        <div className="rounded-[24px] border border-white/10 bg-[#0b0e13]/95 px-7 py-6 text-sm font-bold text-white/55 shadow-[0_28px_90px_-58px_rgba(0,0,0,.98)] backdrop-blur-xl">Lade Spieler...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#050608] text-white">
      <div className="mx-auto w-full max-w-[var(--emd-content-max)] space-y-6 px-3 pb-10 pt-4 sm:px-5 lg:px-7 xl:px-8">
        <div className="flex flex-col gap-3 rounded-[26px] border border-white/[0.08] bg-[linear-gradient(135deg,rgba(17,20,27,.96),rgba(8,10,14,.92))] px-4 py-4 text-white shadow-[0_24px_70px_-48px_rgba(0,0,0,.98)] backdrop-blur-xl sm:flex-row sm:items-center sm:justify-between sm:px-5">
          <div className="min-w-0">
            <div className="flex items-center gap-2 text-[11px] font-black uppercase tracking-[0.18em] text-white/40">
              <Trophy className="h-3.5 w-3.5 text-orange-400" />
              Double Knockout
            </div>
            <div className="mt-0.5 flex min-w-0 flex-wrap items-baseline gap-x-2 gap-y-1">
              <h1 className="truncate text-xl font-black tracking-tight text-white sm:text-2xl">{tournamentName}</h1>
              <span className="rounded-full border border-white/10 bg-white/[0.05] px-2.5 py-1 text-xs font-black text-white/55">{bracketSize}er DKO</span>
            </div>
          </div>
          <div className="flex gap-2 items-center flex-wrap sm:justify-end">
            <SpeechAnnouncerSettings enabled={speechEnabled} onToggle={setSpeechEnabled} />
            <Button
              onClick={openBeamer}
              variant="outline"
              disabled={!tournamentId}
              className="h-9 rounded-xl border border-orange-300/20 bg-orange-500/[0.10] px-3 text-sm font-black text-orange-100 shadow-[0_10px_30px_-22px_rgba(249,115,22,.45)] transition hover:-translate-y-0.5 hover:border-orange-300/35 hover:bg-orange-500/[0.18] hover:text-white"
            >
              <MonitorUp className="mr-1.5 h-4 w-4" />
              Beamer
            </Button>
            <Button onClick={fetchRankings} variant="outline" disabled={loadingRankings || !tournamentId} className="h-9 rounded-xl border border-white/10 bg-white/[0.045] px-3 text-sm font-black text-white/70 transition hover:-translate-y-0.5 hover:border-white/20 hover:bg-white/[0.08] hover:text-white">
              {loadingRankings ? "Lädt..." : "Rangliste"}
            </Button>
            <Button onClick={handleCancelClick} variant="outline" className="h-9 rounded-xl border border-white/10 bg-white/[0.035] px-3 text-sm font-black text-white/55 transition hover:-translate-y-0.5 hover:border-rose-300/30 hover:bg-rose-500/[0.10] hover:text-rose-200">
              Abbrechen
            </Button>
          </div>
        </div>

        <Card className="overflow-hidden rounded-[28px] border border-white/[0.08] bg-[linear-gradient(145deg,rgba(14,17,22,.94),rgba(7,9,13,.92))] text-white shadow-[0_30px_100px_-62px_rgba(0,0,0,.98)] backdrop-blur-xl">
          <div className="space-y-5 p-4 sm:p-5 lg:p-6">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
              <div className="space-y-2">
                <div className="inline-flex items-center gap-2 rounded-full border border-orange-300/15 bg-orange-500/[0.07] px-3 py-1 text-[11px] font-black uppercase tracking-[0.18em] text-orange-200">
                  <Radio className="h-3.5 w-3.5" />
                  LIVE Center
                </div>
                <div>
                  <h2 className="text-xl font-black tracking-tight text-white sm:text-2xl">Turnierübersicht</h2>
                  <p className="text-sm text-white/50 md:text-base">
                    Live-Spiele, freie Automaten und die nächsten Matches auf einen Blick.
                  </p>
                </div>
              </div>

              <div className="min-w-[240px] rounded-2xl border border-white/[0.08] bg-white/[0.035] p-4 shadow-inner">
                <div className="flex items-center justify-between text-sm text-white/50">
                  <span>Turnier-Fortschritt</span>
                  <span className="font-black text-white">{liveCompletion}%</span>
                </div>
                <div className="mt-3 h-2.5 overflow-hidden rounded-full bg-white/[0.07]">
                  <div
                    className="h-full rounded-full bg-[linear-gradient(90deg,#f97316,#fb923c)] shadow-[0_0_18px_rgba(249,115,22,.28)] transition-all duration-500"
                    style={{ width: `${liveCompletion}%` }}
                  />
                </div>
                <div className="mt-3 grid grid-cols-2 gap-2 text-xs text-white/65">
                  <div className="rounded-xl border border-white/[0.08] bg-[#080b10] px-3 py-2 text-white">
                    <div className="text-[11px] uppercase tracking-[0.16em] text-white/35">Fertig</div>
                    <div className="mt-1 font-semibold">{completedCount} von {totalMatchCount} Matches</div>
                  </div>
                  <div className="rounded-xl border border-white/[0.08] bg-[#080b10] px-3 py-2 text-white text-right">
                    <div className="text-[11px] uppercase tracking-[0.16em] text-white/35">
                      {winnerName ? "Sieger" : "Offen"}
                    </div>
                    <div className="mt-1 font-semibold">{winnerName ? winnerName : `${remainingCount} Matches`}</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
              <div className="rounded-2xl border border-white/[0.09] bg-[linear-gradient(145deg,rgba(17,20,26,.88),rgba(9,12,17,.82))] p-4 shadow-[0_18px_46px_-34px_rgba(0,0,0,.96)] transition hover:-translate-y-0.5 hover:border-orange-300/[0.16] hover:bg-[linear-gradient(145deg,rgba(22,25,32,.92),rgba(11,14,20,.88))]">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-white/70">LIVE Matches</span>
                  <Activity className="h-4 w-4 text-rose-300" />
                </div>
                <div className="mt-2 text-3xl font-black text-white">{activeLiveMatches.length}</div>
                <p className="mt-1 text-xs text-white/35">Aktuell auf Automaten gestartet</p>
              </div>

              <div className="rounded-2xl border border-white/[0.09] bg-[linear-gradient(145deg,rgba(17,20,26,.88),rgba(9,12,17,.82))] p-4 shadow-[0_18px_46px_-34px_rgba(0,0,0,.96)] transition hover:-translate-y-0.5 hover:border-orange-300/[0.16] hover:bg-[linear-gradient(145deg,rgba(22,25,32,.92),rgba(11,14,20,.88))]">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-white/75">Bereit</span>
                  <Clock3 className="h-4 w-4 text-sky-300" />
                </div>
                <div className="mt-2 text-3xl font-black text-white">{readyMatches.length}</div>
                <p className="mt-1 text-xs text-white/35">Sofort startbare Matches</p>
              </div>

              <div className="rounded-2xl border border-white/[0.09] bg-[linear-gradient(145deg,rgba(17,20,26,.88),rgba(9,12,17,.82))] p-4 shadow-[0_18px_46px_-34px_rgba(0,0,0,.96)] transition hover:-translate-y-0.5 hover:border-orange-300/[0.16] hover:bg-[linear-gradient(145deg,rgba(22,25,32,.92),rgba(11,14,20,.88))]">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-white/70">Frei</span>
                  <Radio className="h-4 w-4 text-white/45" />
                </div>
                <div className="mt-2 text-3xl font-black text-white">{availableMachines.length}</div>
                <p className="mt-1 text-xs text-white/35">Verfügbare Automaten</p>
              </div>

              <div className="rounded-2xl border border-white/[0.09] bg-[linear-gradient(145deg,rgba(17,20,26,.88),rgba(9,12,17,.82))] p-4 shadow-[0_18px_46px_-34px_rgba(0,0,0,.96)] transition hover:-translate-y-0.5 hover:border-orange-300/[0.16] hover:bg-[linear-gradient(145deg,rgba(22,25,32,.92),rgba(11,14,20,.88))]">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-white/70">Abgeschlossen</span>
                  <Trophy className="h-4 w-4 text-emerald-300" />
                </div>
                <div className="mt-2 text-3xl font-black text-white">{completedMatches.length}</div>
                <p className="mt-1 text-xs text-white/35">Bereits bestätigte Matches</p>
              </div>
            </div>

            <div className="grid gap-4 xl:grid-cols-[1.15fr_0.85fr]">
              <div className="rounded-[24px] border border-white/[0.08] bg-[#090c11]/95 p-4 shadow-[0_22px_60px_-42px_rgba(0,0,0,.98)]">
                <div className="flex items-center justify-between gap-3">
                  <h3 className="font-semibold text-lg">Gerade LIVE</h3>
                  <span className="rounded-full border border-rose-300/20 bg-rose-500/[0.08] px-2.5 py-1 text-xs font-black text-rose-200">
                    {liveMachineNumbers.length > 0 ? `Automaten ${liveMachineNumbers.join(", ")}` : "Noch kein Spiel gestartet"}
                  </span>
                </div>

                <div className="mt-4 space-y-3">
                  {activeLiveMatches.length === 0 ? (
                    <div className="rounded-[18px] border border-dashed border-white/[0.10] bg-[#070a0f] px-4 py-6 text-sm text-white/45">
                      Noch kein LIVE-Match aktiv. Starte ein Match und es erscheint sofort hier oben.
                    </div>
                  ) : (
                    activeLiveMatches.map((match) => {
                      const canConfirmLive = match.score1 !== match.score2 && (match.score1 > 0 || match.score2 > 0)
                      const nextCall = Math.min((match.callCount || 1) + 1, 3)

                      return (
                        <div
                          key={match.id}
                          className="rounded-[20px] border border-emerald-300/20 bg-[linear-gradient(135deg,rgba(16,185,129,.09),rgba(8,11,16,.96)_42%)] px-4 py-4 shadow-[0_18px_45px_-32px_rgba(16,185,129,.32)] ring-1 ring-emerald-300/[0.05]"
                        >
                          <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
                            <div>
                              <div className="flex items-center gap-2 text-xs uppercase tracking-[0.18em] text-white/45"><span>Match {match.id}</span><span className="rounded-full bg-emerald-600 px-2 py-0.5 text-[10px] font-black tracking-[0.14em] text-white">LIVE</span></div>
                              <div className="mt-1 text-base font-semibold">
                                {match.player1} <span className="text-white/30">vs.</span> {match.player2}
                              </div>
                              <div className="mt-2">
                                <span className="rounded-full border border-emerald-200 bg-white px-3 py-1 text-xs font-bold text-emerald-700">
                                  Automat {match.machineNumber}
                                </span>
                              </div>
                            </div>

                            <div className="grid grid-cols-2 gap-3 md:w-[190px]">
                              <div className="rounded-xl border border-slate-200 bg-white p-3">
                                <div className="truncate text-xs text-white/45">{match.player1}</div>
                                <Input
                                  type="text"
                                  inputMode="numeric"
                                  maxLength={2}
                                  value={match.score1 > 0 ? String(match.score1) : ""}
                                  onChange={(e) => updateScore(match.id, 1, Number(e.target.value.replace(/\D/g, "").slice(0, 2)) || 0)}
                                  className="mt-2 h-10 w-14 border-slate-200 bg-slate-50 px-0 text-center text-base font-bold text-white"
                                />
                              </div>
                              <div className="rounded-xl border border-slate-200 bg-white p-3">
                                <div className="truncate text-xs text-white/45">{match.player2}</div>
                                <Input
                                  type="text"
                                  inputMode="numeric"
                                  maxLength={2}
                                  value={match.score2 > 0 ? String(match.score2) : ""}
                                  onChange={(e) => updateScore(match.id, 2, Number(e.target.value.replace(/\D/g, "").slice(0, 2)) || 0)}
                                  className="mt-2 h-10 w-14 border-slate-200 bg-slate-50 px-0 text-center text-base font-bold text-white"
                                />
                              </div>
                            </div>
                          </div>

                          <div className="mt-3 flex flex-wrap items-center gap-2">
                            <span className="rounded-full border border-white/[0.08] bg-white/[0.035] px-3 py-1 text-xs font-bold text-white/55">
                              Stand {match.score1}:{match.score2}
                            </span>
                            {match.callCount && match.callCount < 3 && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => repeatCall(match.id)}
                                className="border-white/10 bg-white/[0.045] text-white/70 hover:border-orange-300/20 hover:bg-orange-500/[0.08] hover:text-white"
                              >
                                {nextCall}. Aufruf
                              </Button>
                            )}
                            <Button
                              size="sm"
                              onClick={() => confirmMatch(match.id)}
                              disabled={!canConfirmLive}
                              className="border border-orange-300/25 bg-orange-500 text-white shadow-[0_12px_28px_-18px_rgba(249,115,22,.55)] hover:bg-orange-400 disabled:border-white/[0.08] disabled:bg-white/[0.045] disabled:text-white/30 disabled:shadow-none"
                            >
                              <Check className="mr-1 h-4 w-4" />
                              Ergebnis bestätigen
                            </Button>
                          </div>
                        </div>
                      )
                    })
                  )}
                </div>
              </div>

              <div className="rounded-2xl border border-white/[0.09] bg-[linear-gradient(145deg,rgba(17,20,26,.88),rgba(9,12,17,.82))] p-4 shadow-[0_18px_46px_-34px_rgba(0,0,0,.96)] transition hover:-translate-y-0.5 hover:border-orange-300/[0.16] hover:bg-[linear-gradient(145deg,rgba(22,25,32,.92),rgba(11,14,20,.88))]">
                <div className="flex items-center justify-between gap-3">
                  <h3 className="font-semibold text-lg">Als Nächstes dran</h3>
                  <span className="text-xs text-white/45">Top {Math.min(readyMatches.length, 4)}</span>
                </div>

                <div className="mt-4 space-y-3">
                  {readyMatches.length === 0 ? (
                    <div className="rounded-[18px] border border-dashed border-white/[0.10] bg-[#070a0f] px-4 py-6 text-sm text-white/45">
                      Aktuell wartet kein startbereites Match.
                    </div>
                  ) : (
                    readyMatches.slice(0, 4).map((match) => {
                      const hasFreilos = isFreilos(match.player1) || isFreilos(match.player2)

                      return (
                        <div key={match.id} className="rounded-[18px] border border-white/[0.08] bg-[#080b10] px-4 py-3 text-white shadow-[0_14px_36px_-28px_rgba(0,0,0,.95)] transition hover:border-white/[0.14] hover:bg-[#0b0f15]">
                          <div className="flex items-center justify-between gap-3">
                            <span className="text-sm font-semibold">Match {match.id}</span>
                            <span className="rounded-full border border-emerald-300/20 bg-emerald-500/[0.10] px-2.5 py-1 text-xs font-black text-emerald-200">
                              {hasFreilos ? "auto" : "bereit"}
                            </span>
                          </div>
                          <div className="mt-2 text-sm text-white/65">
                            {match.player1} <span className="text-white/30">vs.</span> {match.player2}
                          </div>
                          <div className="mt-3 flex flex-wrap items-center gap-2">
                            <Button
                              size="sm"
                              onClick={() => startMatch(match.id)}
                              className="border border-orange-300/20 bg-orange-500/[0.12] text-orange-100 hover:bg-orange-500/[0.22] hover:text-white"
                            >
                              {hasFreilos ? "Auto starten" : "Spiel starten"}
                            </Button>
                          </div>
                        </div>
                      )
                    })
                  )}
                </div>
              </div>
            </div>
          </div>
        </Card>

        <div className="columns-1 xl:columns-2 [column-gap:1.25rem]">
          <div className="mb-5 break-inside-avoid space-y-3">
            <h2 className="flex items-center justify-between rounded-2xl border border-white/[0.08] bg-[linear-gradient(135deg,rgba(255,255,255,.045),rgba(255,255,255,.02))] px-4 py-3 text-base font-black text-white shadow-[0_16px_40px_-32px_rgba(0,0,0,.95)]">Runde 1</h2>
            {[1, 2, 3, 4].map((i) => (
              <MatchCard
                key={i}
                match={matches[i]}
                onScoreUpdate={updateScore}
                onConfirm={confirmMatch}
                onStartMatch={startMatch}
                onReset={resetMatch}
                onRepeatCall={repeatCall}
                profilePictures={profilePictures}
              />
            ))}
          </div>

          <div className="mb-5 break-inside-avoid space-y-3">
            <h2 className="flex items-center justify-between rounded-2xl border border-rose-300/15 bg-rose-500/[0.055] px-4 py-3 text-base font-black text-rose-200 shadow-[0_16px_40px_-32px_rgba(0,0,0,.95)]">Verlierer-Runde 1</h2>
            {[8, 9].map((i) => (
              <MatchCard
                key={i}
                match={matches[i]}
                onScoreUpdate={updateScore}
                onConfirm={confirmMatch}
                onStartMatch={startMatch}
                onReset={resetMatch}
                onRepeatCall={repeatCall}
                isLoser
                profilePictures={profilePictures}
              />
            ))}
          </div>

          <div className="mb-5 break-inside-avoid space-y-3">
            <h2 className="flex items-center justify-between rounded-2xl border border-sky-300/15 bg-sky-500/[0.055] px-4 py-3 text-base font-black text-sky-200 shadow-[0_16px_40px_-32px_rgba(0,0,0,.95)]">Runde 2</h2>
            {[5, 6].map((i) => (
              <MatchCard
                key={i}
                match={matches[i]}
                onScoreUpdate={updateScore}
                onConfirm={confirmMatch}
                onStartMatch={startMatch}
                onReset={resetMatch}
                onRepeatCall={repeatCall}
                profilePictures={profilePictures}
              />
            ))}
          </div>

          <div className="mb-5 break-inside-avoid space-y-3">
            <h2 className="flex items-center justify-between rounded-2xl border border-rose-300/15 bg-rose-500/[0.055] px-4 py-3 text-base font-black text-rose-200 shadow-[0_16px_40px_-32px_rgba(0,0,0,.95)]">Verlierer-Runde 2</h2>
            {[10, 11].map((i) => (
              <MatchCard
                key={i}
                match={matches[i]}
                onScoreUpdate={updateScore}
                onConfirm={confirmMatch}
                onStartMatch={startMatch}
                onReset={resetMatch}
                onRepeatCall={repeatCall}
                isLoser
                profilePictures={profilePictures}
              />
            ))}
          </div>

          <div className="mb-5 break-inside-avoid space-y-3">
            <h2 className="flex items-center justify-between rounded-2xl border border-rose-300/15 bg-rose-500/[0.055] px-4 py-3 text-base font-black text-rose-200 shadow-[0_16px_40px_-32px_rgba(0,0,0,.95)]">Verlierer-Runde 3</h2>
            <MatchCard
              match={matches[12]}
              onScoreUpdate={updateScore}
              onConfirm={confirmMatch}
              onStartMatch={startMatch}
              onReset={resetMatch}
              onRepeatCall={repeatCall}
              isLoser
              profilePictures={profilePictures}
            />
          </div>

          <div className="mb-5 break-inside-avoid space-y-3">
            <h2 className="flex items-center justify-between rounded-2xl border border-sky-300/15 bg-sky-500/[0.055] px-4 py-3 text-base font-black text-sky-200 shadow-[0_16px_40px_-32px_rgba(0,0,0,.95)]">Halbfinale</h2>
            <MatchCard
              match={matches[7]}
              onScoreUpdate={updateScore}
              onConfirm={confirmMatch}
              onStartMatch={startMatch}
              onReset={resetMatch}
              onRepeatCall={repeatCall}
              profilePictures={profilePictures}
            />
          </div>

          <div className="mb-5 break-inside-avoid space-y-3">
            <h2 className="flex items-center justify-between rounded-2xl border border-rose-300/15 bg-rose-500/[0.055] px-4 py-3 text-base font-black text-rose-200 shadow-[0_16px_40px_-32px_rgba(0,0,0,.95)]">Verlierer-Runde 4</h2>
            <MatchCard
              match={matches[13]}
              onScoreUpdate={updateScore}
              onConfirm={confirmMatch}
              onStartMatch={startMatch}
              onReset={resetMatch}
              onRepeatCall={repeatCall}
              isLoser
              profilePictures={profilePictures}
            />
          </div>

          <div className="space-y-3">
            <h2 className="flex items-center justify-between rounded-2xl border border-sky-300/15 bg-sky-500/[0.055] px-4 py-3 text-base font-black text-sky-200 shadow-[0_16px_40px_-32px_rgba(0,0,0,.95)]">Großes Finale</h2>
            <p className="text-sm text-muted-foreground">Sieger Gewinnerseite vs. Sieger Verliererseite</p>
            <MatchCard
              match={matches[14]}
              onScoreUpdate={updateScore}
              onConfirm={confirmMatch}
              onStartMatch={startMatch}
              onReset={resetMatch}
              onRepeatCall={repeatCall}
              isGrandFinal
              profilePictures={profilePictures}
            />
          </div>

          {(matches[15]?.player1 ||
            matches[15]?.player2 ||
            (matches[14]?.winner === matches[14]?.player2 && matches[14]?.winner)) &&
            !matches[15]?.winner && (
              <div className="space-y-3">
                <h2 className="flex items-center justify-between rounded-xl border border-violet-200 bg-violet-50/70 px-4 py-3 text-base font-black text-violet-900 shadow-sm">Bracket Reset</h2>
                <p className="text-sm text-muted-foreground">
                  Der Spieler von der Verliererseite hat gewonnen! Beide Spieler haben jetzt je 1 Niederlage.
                </p>
                <MatchCard
                  match={matches[15]}
                  onScoreUpdate={updateScore}
                  onConfirm={confirmMatch}
                  onStartMatch={startMatch}
                  onReset={resetMatch}
                  onRepeatCall={repeatCall}
                  isGrandFinal
                  profilePictures={profilePictures}
                />
              </div>
            )}

          {(matches[15]?.winner || (matches[14]?.winner === matches[14]?.player1 && matches[14]?.player1)) && (
            <Card className="xl:col-span-2 overflow-hidden rounded-[28px] border border-orange-300/20 bg-[linear-gradient(135deg,rgba(249,115,22,.10),rgba(10,13,18,.96)_36%,rgba(6,8,12,.98))] p-6 text-white shadow-[0_30px_90px_-52px_rgba(249,115,22,.28)]">
              <h3 className="text-2xl font-bold text-center">🏆 Turniersieger</h3>
              <p className="text-3xl font-bold text-center mt-4">{matches[15]?.winner || matches[14]?.winner}</p>


              <div className="mt-5 rounded-xl border border-white/20 bg-white/10 px-4 py-3 text-center">
                <p className="text-sm font-semibold">
                  {seriesId
                    ? "Dieses Turnier ist einer Turnierserie zugeordnet. Beim Abschluss werden Ergebnis und Serienwertung automatisch gespeichert."
                    : "Beim Abschluss wird das Turnier beendet. Es wird keine Serienwertung erstellt."}
                </p>
              </div>

              <div className="flex justify-center mt-6">
                <Button
                  onClick={async () => {
                    if (seriesId) {
                      await saveToTournamentSeries()
                      return
                    }

                    await markTournamentAsCompleted(tournamentId)
                    await deleteFreiloseFromDatabase(tournamentType, tournamentId)
                    await clearTournamentRegistration(seriesId, eventId)
                    router.push("/admin/einzelturnier")
                  }}
                  disabled={Boolean(seriesId) && savingToSeries}
                  size="lg"
                  className="font-semibold bg-green-600 text-white hover:bg-green-700 min-w-[260px]"
                >
                  {seriesId
                    ? savingToSeries
                      ? "Speichere & schließe ab..."
                      : "Turnier abschließen & speichern"
                    : "Turnier abschließen"}
                </Button>
              </div>
            </Card>
          )}
        </div>
      </div>

      <Dialog open={machineDialogOpen} onOpenChange={setMachineDialogOpen}>
        <DialogContent className="rounded-[26px] border border-white/10 bg-[#0b0e13]/98 text-white shadow-[0_35px_120px_-54px_rgba(0,0,0,.98)] backdrop-blur-2xl">
          <DialogHeader>
            <DialogTitle>Automat auswählen</DialogTitle>
            <DialogDescription>Wähle einen verfügbaren Automaten für Match {selectedMatchId}</DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-4 gap-2 py-4">
            {availableMachines.length === 0 ? (
              <p className="col-span-4 text-center text-muted-foreground">Keine Automaten verfügbar</p>
            ) : (
              availableMachines.map((num) => (
                <Button key={num} onClick={() => assignMachine(num)} variant="outline" className="h-16 text-lg">
                  {num}
                </Button>
              ))
            )}
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={cancelDialogOpen} onOpenChange={setCancelDialogOpen}>
        <DialogContent className="rounded-[26px] border border-white/10 bg-[#0b0e13]/98 text-white shadow-[0_35px_120px_-54px_rgba(0,0,0,.98)] backdrop-blur-2xl">
          <DialogHeader>
            <DialogTitle>Turnier abbrechen?</DialogTitle>
            <DialogDescription>
              Möchtest du wirklich zur Registrierung zurückkehren? Das aktuelle Turnier wird nicht gespeichert.
            </DialogDescription>
          </DialogHeader>
          <div className="flex gap-3 justify-end mt-4">
            <Button variant="outline" onClick={() => setCancelDialogOpen(false)}>
              Nein, weiterspielen
            </Button>
            <Button variant="destructive" onClick={handleConfirmCancel}>
              Ja, abbrechen
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={rankingsDialogOpen} onOpenChange={setRankingsDialogOpen}>
        <DialogContent className="max-h-[80vh] max-w-md overflow-y-auto rounded-[26px] border border-white/10 bg-[#0b0e13]/98 text-white shadow-[0_35px_120px_-54px_rgba(0,0,0,.98)] backdrop-blur-2xl">
          <DialogHeader>
            <DialogTitle>Tabelle</DialogTitle>
            <DialogDescription>Aktuelle Platzierungen im Turnier</DialogDescription>
          </DialogHeader>
          <div className="space-y-2 py-4">
            {rankings.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">Noch keine Platzierungen vorhanden</p>
            ) : (
              rankings.map((ranking) => (
                <div
                  key={`${ranking.placement}-${ranking.player_name}`}
                  className={cn(
                    "flex items-center justify-between p-3 rounded-lg border",
                    ranking.placement === 1 && "bg-yellow-50 border-yellow-400",
                    ranking.placement === 2 && "bg-gray-100 border-gray-400",
                    ranking.placement === 3 && "bg-orange-50 border-orange-400",
                    ranking.placement > 3 && "bg-white/[0.025]",
                  )}
                >
                  <div className="flex items-center gap-3">
                    <span
                      className={cn(
                        "text-2xl font-bold w-8 text-center",
                        ranking.placement === 1 && "text-yellow-600",
                        ranking.placement === 2 && "text-gray-600",
                        ranking.placement === 3 && "text-orange-600",
                        ranking.placement > 3 && "text-muted-foreground",
                      )}
                    >
                      {ranking.placement === 1
                        ? "🥇"
                        : ranking.placement === 2
                          ? "🥈"
                          : ranking.placement === 3
                            ? "🥉"
                            : ranking.placement}
                    </span>
                    <span className="font-medium">{ranking.player_name}</span>
                  </div>
                  <span className="text-xs text-muted-foreground">Platz {ranking.placement}</span>
                </div>
              ))
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

interface MatchCardProps {
  match: Match
  onScoreUpdate: (matchId: number, player: 1 | 2, score: number) => void
  onConfirm: (matchId: number) => void
  onStartMatch: (matchId: number) => void
  onReset: (matchId: number) => void
  onRepeatCall: (matchId: number) => void
  profilePictures: Record<string, string>
  isLoser?: boolean
  isGrandFinal?: boolean
}

function MatchCard({
  match,
  onScoreUpdate,
  onConfirm,
  onStartMatch,
  onReset,
  onRepeatCall,
  profilePictures,
  isLoser,
  isGrandFinal,
}: MatchCardProps) {
  const isPlayer1Winner = match.winner === match.player1
  const isPlayer2Winner = match.winner === match.player2
  const isPlayer1Loser = match.loser === match.player1
  const isPlayer2Loser = match.loser === match.player2
  const isRunning = match.machineNumber && !match.winner
  const canConfirm =
    match.machineNumber && !match.winner && match.score1 !== match.score2 && (match.score1 > 0 || match.score2 > 0)

  const hasFreilos = isFreilos(match.player1) || isFreilos(match.player2)

  const currentCall = match.callCount || 0

  const getProfilePicture = (playerName: string): string => {
    if (!playerName || isFreilos(playerName)) return "/placeholder-user.png"
    const picture = profilePictures[playerName.toLowerCase()]
    return picture || "/placeholder-user.jpg"
  }

  return (
    <Card
      className={cn(
        "space-y-3 rounded-[22px] border border-white/[0.08] bg-[linear-gradient(145deg,rgba(14,17,22,.94),rgba(8,10,14,.92))] p-3.5 text-white shadow-[0_18px_48px_-34px_rgba(0,0,0,.98)] transition-all duration-200 hover:-translate-y-0.5 hover:border-white/[0.14] hover:shadow-[0_24px_60px_-38px_rgba(0,0,0,.98)]",
        isGrandFinal && "border-2 border-orange-300/30 shadow-[0_24px_60px_-36px_rgba(249,115,22,.38)]",
        isLoser && "border-l-4 border-l-rose-400/80",
        isRunning && "border-2 border-emerald-400/45 bg-emerald-500/[0.07] shadow-[0_20px_50px_-30px_rgba(16,185,129,.40)]",
        hasFreilos && !match.winner && "border-l-4 border-l-amber-400/80 bg-amber-500/[0.045]",
      )}
    >
      <div className="flex items-center justify-between mb-2 gap-3">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-xs font-bold text-muted-foreground">Match {match.id}</span>
          {isRunning && (
            <span className="inline-flex items-center gap-1 rounded-full border border-emerald-300/20 bg-emerald-500/[0.08] px-2 py-1 text-[11px] font-black text-emerald-200">
              <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" /> LIVE
            </span>
          )}
          {match.winner && (
            <span className="inline-flex items-center gap-1 rounded-full border border-emerald-300/20 bg-emerald-500/[0.08] px-2 py-1 text-[11px] font-black text-emerald-200">
              Fertig
            </span>
          )}
          {hasFreilos && !match.winner && (
            <span className="inline-flex items-center gap-1 rounded-full border border-amber-300/20 bg-amber-500/[0.08] px-2 py-1 text-[11px] font-black text-amber-200">
              Freilos
            </span>
          )}
        </div>
        <div className="flex items-center gap-2 flex-wrap justify-end">
          {match.machineNumber && !match.winner && (
            <span className="rounded-full border border-emerald-300/20 bg-emerald-500/[0.08] px-2.5 py-1 text-xs font-black text-emerald-200">
              🎯 Automat {match.machineNumber}
            </span>
          )}
          {isRunning && currentCall < 3 && (
            <Button size="sm" onClick={() => onRepeatCall(match.id)} variant="outline" className="h-7 text-xs">
              {currentCall === 1 ? "2. Aufruf" : "3. Aufruf"}
            </Button>
          )}
          {canConfirm && (
            <Button
              size="sm"
              onClick={() => onConfirm(match.id)}
              className="h-7 rounded-lg border border-orange-300/20 bg-orange-500/[0.12] text-xs font-black text-orange-100 hover:bg-orange-500/[0.22] hover:text-white"
            >
              <Check className="h-3 w-3 mr-1" />
              Bestätigen
            </Button>
          )}
          {match.winner && (
            <Button
              size="sm"
              variant="ghost"
              onClick={() => onReset(match.id)}
              className="h-7 w-7 rounded-lg border border-transparent p-0 text-white/35 hover:border-rose-300/20 hover:bg-rose-500/[0.08] hover:text-rose-300"
              title="Match zurücksetzen"
            >
              <RotateCcw className="h-3 w-3" />
            </Button>
          )}
          {!match.machineNumber && !match.winner && match.player1 && match.player2 && (
            <Button size="sm" onClick={() => onStartMatch(match.id)} className="h-7 rounded-lg bg-orange-500 px-2.5 text-xs font-black text-white shadow-[0_10px_24px_-18px_rgba(249,115,22,.60)] hover:bg-orange-400">
              {hasFreilos ? "Auto" : "Starten"}
            </Button>
          )}
        </div>
      </div>

      <div
        className={cn(
          "flex items-center gap-2 rounded-xl border border-white/[0.06] bg-white/[0.025] p-2.5 transition-all",
          isPlayer1Winner && "border-emerald-300/30 bg-emerald-500/[0.09] ring-1 ring-emerald-300/10",
          isPlayer1Loser && "border-rose-300/25 bg-rose-500/[0.08]",
          !isPlayer1Winner && !isPlayer1Loser && "bg-white/[0.025]",
          isFreilos(match.player1) && "border-amber-300/25 bg-amber-500/[0.08]",
        )}
      >
        <div className="flex-1 min-w-0 flex items-center gap-2">
          {match.player1 && !isFreilos(match.player1) && (
            <Avatar className="h-8 w-8 flex-shrink-0">
              <AvatarImage src={getProfilePicture(match.player1) || "/placeholder.svg"} alt={match.player1} />
              <AvatarFallback>{match.player1.charAt(0).toUpperCase()}</AvatarFallback>
            </Avatar>
          )}
          <p
            className={cn(
              "text-sm truncate",
              !match.player1 && "text-muted-foreground italic",
              isPlayer1Winner && "font-black text-emerald-200",
              isPlayer1Loser && "text-rose-300",
              isFreilos(match.player1) && "text-amber-200 italic font-semibold",
            )}
          >
            {match.player1 || "Warte auf Spieler..."}
          </p>
          {isPlayer1Winner && <span className="font-black text-emerald-300">✓</span>}
        </div>
        <Input
          type="number"
          min="0"
          max="10"
          value={match.score1}
          onChange={(e) => onScoreUpdate(match.id, 1, Number.parseInt(e.target.value) || 0)}
          className="h-9 w-16 rounded-lg border-white/10 bg-black/30 text-center font-black text-white shadow-inner focus:border-orange-300/40 focus:ring-2 focus:ring-orange-500/10"
          disabled={!match.player1 || !match.player2 || !match.machineNumber}
        />
      </div>

      <div
        className={cn(
          "flex items-center gap-2 rounded-xl border border-white/[0.06] bg-white/[0.025] p-2.5 transition-all",
          isPlayer2Winner && "border-emerald-300/30 bg-emerald-500/[0.09] ring-1 ring-emerald-300/10",
          isPlayer2Loser && "border-rose-300/25 bg-rose-500/[0.08]",
          !isPlayer2Winner && !isPlayer2Loser && "bg-white/[0.025]",
          isFreilos(match.player2) && "border-amber-300/25 bg-amber-500/[0.08]",
        )}
      >
        <div className="flex-1 min-w-0 flex items-center gap-2">
          {match.player2 && !isFreilos(match.player2) && (
            <Avatar className="h-8 w-8 flex-shrink-0">
              <AvatarImage src={getProfilePicture(match.player2) || "/placeholder.svg"} alt={match.player2} />
              <AvatarFallback>{match.player2.charAt(0).toUpperCase()}</AvatarFallback>
            </Avatar>
          )}
          <p
            className={cn(
              "text-sm truncate",
              !match.player2 && "text-muted-foreground italic",
              isPlayer2Winner && "font-black text-emerald-200",
              isPlayer2Loser && "text-rose-300",
              isFreilos(match.player2) && "text-amber-200 italic font-semibold",
            )}
          >
            {match.player2 || "Warte auf Spieler..."}
          </p>
          {isPlayer2Winner && <span className="font-black text-emerald-300">✓</span>}
        </div>
        <Input
          type="number"
          min="0"
          max="10"
          value={match.score2}
          onChange={(e) => onScoreUpdate(match.id, 2, Number.parseInt(e.target.value) || 0)}
          className="h-9 w-16 rounded-lg border-white/10 bg-black/30 text-center font-black text-white shadow-inner focus:border-orange-300/40 focus:ring-2 focus:ring-orange-500/10"
          disabled={!match.player1 || !match.player2 || !match.machineNumber}
        />
      </div>
    </Card>
  )
}
