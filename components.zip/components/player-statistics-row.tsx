"use client"

import { useState } from "react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ChevronDown, ChevronUp, User, Calculator } from "lucide-react"
import { PlayerPointsModal } from "./player-points-modal"

interface PlayerStatisticsRowProps {
  player: any
  index: number
  allStats: any[]
}

export function PlayerStatisticsRow({ player, index, allStats }: PlayerStatisticsRowProps) {
  const [showDetails, setShowDetails] = useState(false)
  const [showPointsModal, setShowPointsModal] = useState(false)

  // Calculate detailed stats for this specific player
  const playerDetailedStats = allStats
    .filter((stat) => stat.player_id === player.player_id)
    .reduce((acc, stat) => {
      return {
        throws_15: (acc.throws_15 || 0) + (stat.throws_15 || 0),
        throws_16: (acc.throws_16 || 0) + (stat.throws_16 || 0),
        throws_17: (acc.throws_17 || 0) + (stat.throws_17 || 0),
        throws_18: (acc.throws_18 || 0) + (stat.throws_18 || 0),
        throws_19: (acc.throws_19 || 0) + (stat.throws_19 || 0),
        throws_shanghai: (acc.throws_shanghai || 0) + (stat.throws_shanghai || 0),
        throws_95_plus: (acc.throws_95_plus || 0) + (stat.throws_95_plus || 0),
        throws_bull: (acc.throws_bull || 0) + (stat.throws_bull || 0),
        throws_171: (acc.throws_171 || 0) + (stat.throws_171 || 0),
      }
    }, {})

  const pointsBreakdown = {
    legWinPoints: player.total_wins * 3,
    throw180Points: player.throws_180 * 25,
    throw171Points: player.throws_171 * 25,
    highTonnePoints: player.throws_high_tonne * 18,
    tonnePoints: player.throws_tonne * 15,
    throw95PlusPoints: player.throws_95_plus * 12,
    shanghaiPoints: player.throws_shanghai * 10,
    bullPoints: player.throws_bull * 8,
    throw20Points: player.throws_20 * 6,
    throw19Points: (playerDetailedStats.throws_19 || 0) * 5,
    throw18Points: (playerDetailedStats.throws_18 || 0) * 4,
    throw17Points: (playerDetailedStats.throws_17 || 0) * 3,
    throw16Points: (playerDetailedStats.throws_16 || 0) * 2,
    throw15Points: (playerDetailedStats.throws_15 || 0) * 1,
    totalPoints: player.total_points || 0,
  }

  return (
    <>
      <tr
        className={`border-b hover:bg-gray-50 transition-colors ${index < 3 ? "bg-gradient-to-r from-amber-50 to-yellow-50" : ""}`}
      >
        <td className="p-2 sm:p-4">
          <div
            className={`w-6 h-6 sm:w-8 sm:h-8 ${index < 3 ? "bg-amber-100" : "bg-blue-100"} rounded-full flex items-center justify-center`}
          >
            <span className={`font-bold ${index < 3 ? "text-amber-600" : "text-blue-600"} text-xs sm:text-sm`}>
              {index + 1}
            </span>
          </div>
        </td>
        <td className="p-2 sm:p-4">
          <div className="group relative">
            <a
              href={`/liga/spieler/${player.player_id}`}
              className="font-semibold text-gray-900 text-sm sm:text-lg hover:text-blue-600 transition-all duration-200 cursor-pointer inline-flex items-center gap-3 group-hover:underline"
            >
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full overflow-hidden bg-gray-100 flex-shrink-0">
                {player.photo_url ? (
                  <img
                    src={player.photo_url || "/placeholder.svg"}
                    alt={player.name}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      e.currentTarget.style.display = "none"
                      e.currentTarget.nextElementSibling.style.display = "flex"
                    }}
                  />
                ) : null}
                <div
                  className={`w-full h-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center ${player.photo_url ? "hidden" : "flex"}`}
                >
                  <User className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
                </div>
              </div>
              <div className="flex items-center gap-2">
                {player.name}
                <svg
                  className="w-3 h-3 text-gray-400 group-hover:text-blue-600 transition-colors opacity-60 group-hover:opacity-100"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
                  />
                </svg>
              </div>
            </a>
            <div className="absolute bottom-full left-0 mb-2 px-2 py-1 bg-gray-800 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap z-10">
              Klicken für detaillierte Statistiken
            </div>
          </div>
        </td>
        <td className="text-center p-2 sm:p-4">
          <div className="flex flex-col items-center gap-1">
            <Badge className="bg-amber-100 text-amber-800 font-bold text-xs">
              {player.total_points?.toFixed(1) || "0.0"}
            </Badge>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowPointsModal(true)}
              className="h-5 w-5 p-0 hover:bg-amber-100"
              title="Punktedetails anzeigen"
            >
              <Calculator className="h-3 w-3 text-amber-600" />
            </Button>
          </div>
        </td>
        <td className="text-center p-2 sm:p-4 font-medium text-xs sm:text-sm">{player.total_legs}</td>
        <td className="text-center p-2 sm:p-4">
          <Badge className="bg-green-100 text-green-800 font-bold text-xs">{player.total_wins}</Badge>
        </td>
        <td className="text-center p-2 sm:p-4">
          <Badge variant="outline" className="font-bold text-xs">
            {player.win_percentage.toFixed(1)}%
          </Badge>
        </td>
        <td className="text-center p-2 sm:p-4">
          <Badge className="bg-red-100 text-red-800 font-bold text-xs">{player.throws_180}</Badge>
        </td>
        <td className="text-center p-2 sm:p-4">
          <Badge className="bg-purple-100 text-purple-800 font-bold text-xs">{player.throws_171}</Badge>
        </td>
        <td className="text-center p-2 sm:p-4">
          <Badge className="bg-orange-100 text-orange-800 font-bold text-xs">{player.throws_high_tonne}</Badge>
        </td>
        <td className="text-center p-2 sm:p-4">
          <Badge className="bg-green-100 text-green-800 font-bold text-xs">{player.throws_tonne}</Badge>
        </td>
        <td className="text-center p-2 sm:p-4">
          <Badge className="bg-teal-100 text-teal-800 font-bold text-xs">{player.throws_95_plus}</Badge>
        </td>
        <td className="text-center p-2 sm:p-4">
          <Badge className="bg-indigo-100 text-indigo-800 font-bold text-xs">{player.throws_shanghai}</Badge>
        </td>
        <td className="text-center p-2 sm:p-4">
          <Badge className="bg-pink-100 text-pink-800 font-bold text-xs">{player.throws_bull}</Badge>
        </td>
        <td className="text-center p-2 sm:p-4">
          <Button variant="outline" size="sm" onClick={() => setShowDetails(!showDetails)} className="text-xs">
            {showDetails ? (
              <>
                <ChevronUp className="h-3 w-3 mr-1" />
                Weniger
              </>
            ) : (
              <>
                <ChevronDown className="h-3 w-3 mr-1" />
                Mehr anzeigen
              </>
            )}
          </Button>
        </td>
      </tr>
      {showDetails && (
        <tr className="bg-gray-50">
          <td colSpan={14} className="p-4">
            <div className="bg-white rounded-lg p-4 shadow-sm">
              <h4 className="font-semibold text-gray-900 mb-3">Detaillierte Statistiken für {player.name}</h4>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
                <div className="text-center p-2 bg-yellow-50 rounded">
                  <div className="text-lg font-bold text-yellow-600">{player.throws_20 || 0}</div>
                  <div className="text-xs text-gray-600">20er</div>
                </div>
                <div className="text-center p-2 bg-yellow-50 rounded">
                  <div className="text-lg font-bold text-yellow-600">{playerDetailedStats.throws_19 || 0}</div>
                  <div className="text-xs text-gray-600">19er</div>
                </div>
                <div className="text-center p-2 bg-yellow-50 rounded">
                  <div className="text-lg font-bold text-yellow-600">{playerDetailedStats.throws_18 || 0}</div>
                  <div className="text-xs text-gray-600">18er</div>
                </div>
                <div className="text-center p-2 bg-yellow-50 rounded">
                  <div className="text-lg font-bold text-yellow-600">{playerDetailedStats.throws_17 || 0}</div>
                  <div className="text-xs text-gray-600">17er</div>
                </div>
                <div className="text-center p-2 bg-yellow-50 rounded">
                  <div className="text-lg font-bold text-yellow-600">{playerDetailedStats.throws_16 || 0}</div>
                  <div className="text-xs text-gray-600">16er</div>
                </div>
                <div className="text-center p-2 bg-yellow-50 rounded">
                  <div className="text-lg font-bold text-yellow-600">{playerDetailedStats.throws_15 || 0}</div>
                  <div className="text-xs text-gray-600">15er</div>
                </div>
              </div>
            </div>
          </td>
        </tr>
      )}
      <PlayerPointsModal
        isOpen={showPointsModal}
        onClose={() => setShowPointsModal(false)}
        player={player}
        pointsBreakdown={pointsBreakdown}
      />
    </>
  )
}
