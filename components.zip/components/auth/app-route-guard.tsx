"use client"

import type React from "react"
import { useEffect, useState } from "react"
import { usePathname, useRouter } from "next/navigation"

import { supabase } from "@/lib/supabase"
import { useAuth } from "@/hooks/use-auth"
import {
  GUEST_HOME_ROUTE,
  GUEST_LOGIN_ROUTE,
  MEMBER_HOME_ROUTE,
  MEMBER_LOGIN_ROUTE,
  MEMBER_MEMBERSHIP_ROUTE,
  isForbiddenForGuestsPath,
  isGuestPath,
  isProtectedMemberPath,
  isPublicPath,
} from "@/lib/access-control"

type UserAccessProfile = {
  player_id: string | null
  is_guest: boolean | null
  is_admin: boolean | null
  is_blocked: boolean | null
  blocked_reason: string | null
}

function isPublicDachEventsPath(pathname: string) {
  if (pathname === "/dach-veranstaltungen") return true

  const parts = pathname.split("/").filter(Boolean)

  // Öffentliche Detailseite: /dach-veranstaltungen/[id]
  return (
    parts.length === 2 &&
    parts[0] === "dach-veranstaltungen" &&
    !["neu", "meine", "nachrichten"].includes(parts[1])
  )
}

function isDachEventsManagementPath(pathname: string) {
  return (
    pathname === "/dach-veranstaltungen/neu" ||
    pathname === "/dach-veranstaltungen/meine" ||
    /^\/dach-veranstaltungen\/[^/]+\/bearbeiten$/.test(pathname)
  )
}

function isPublicDartMarketplacePath(pathname: string) {
  if (pathname === "/dartboerse") return true

  const parts = pathname.split("/").filter(Boolean)

  // Öffentliche Detailseite: /dartboerse/[id]
  return (
    parts.length === 2 &&
    parts[0] === "dartboerse" &&
    !["neu", "meine", "nachrichten"].includes(parts[1])
  )
}

function isDartMarketplaceManagementPath(pathname: string) {
  return (
    pathname === "/dartboerse/neu" ||
    pathname === "/dartboerse/meine" ||
    pathname === "/dartboerse/nachrichten" ||
    /^\/dartboerse\/nachrichten\/[^/]+$/.test(pathname) ||
    /^\/dartboerse\/[^/]+\/bearbeiten$/.test(pathname)
  )
}

function isTerminalPath(pathname: string) {
  return pathname === "/terminal" || pathname.startsWith("/terminal/")
}

function isMessengerPath(pathname: string) {
  return pathname === "/chat-app" || pathname.startsWith("/chat-app/")
}

function LoadingScreen() {
  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[#050608] px-4 text-white">
      <div
        className="pointer-events-none absolute inset-0 bg-cover bg-[66%_50%] bg-no-repeat opacity-[0.22]"
        style={{ backgroundImage: "url('/terminal/hero-startscreen.png')" }}
      />
      <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(180deg,rgba(3,5,8,.80),rgba(3,5,9,.96))]" />
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_18%_20%,rgba(249,115,22,.16),transparent_28%),radial-gradient(circle_at_82%_72%,rgba(14,165,233,.10),transparent_30%)]" />

      <div className="relative flex flex-col items-center gap-4 rounded-[24px] border border-white/[0.08] bg-black/30 px-6 py-5 text-center shadow-[0_24px_70px_-48px_rgba(0,0,0,.95)] backdrop-blur-2xl">
        <div className="relative flex h-12 w-12 items-center justify-center">
          <div className="absolute inset-0 rounded-full bg-orange-500/15 blur-xl" />
          <div className="relative h-9 w-9 animate-spin rounded-full border-[3px] border-white/10 border-t-orange-400 border-r-orange-300/60" />
        </div>
        <div>
          <div className="text-sm font-black text-white/85">Zugriff wird geprüft...</div>
          <div className="mt-1 text-xs font-semibold text-white/35">Einen Moment bitte</div>
        </div>
      </div>
    </div>
  )
}

export function AppRouteGuard({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const router = useRouter()
  const { session, loading: authLoading } = useAuth()

  const [checking, setChecking] = useState(true)

  useEffect(() => {
    let mounted = true

    const checkAccess = async () => {
      try {
        setChecking(true)

        // Club Terminal is a separate public kiosk area.
        // Club Terminal and EMD Messenger are standalone areas and bypass this global guard.
        // The normal site keeps all existing auth/access checks unchanged.
        if (isTerminalPath(pathname) || isMessengerPath(pathname)) {
          if (mounted) setChecking(false)
          return
        }

        // Login-Seiten besitzen ihren eigenen Auth-/Ladezustand.
        // Der globale Guard darf hier keinen zweiten Vollbild-Loader
        // dazwischenschalten und keine laufende Login-Prüfung übermalen.
        if (pathname === MEMBER_LOGIN_ROUTE || pathname === GUEST_LOGIN_ROUTE) {
          if (mounted) setChecking(false)
          return
        }

        if (authLoading) return

        const pathIsPublic =
          isPublicPath(pathname) ||
          isPublicDachEventsPath(pathname) ||
          isPublicDartMarketplacePath(pathname)

        const pathIsGuest = isGuestPath(pathname)
        const pathIsDachManagement = isDachEventsManagementPath(pathname)
        const pathIsDartMarketplaceManagement =
          isDartMarketplaceManagementPath(pathname)
        const pathIsSharedManagement =
          pathIsDachManagement || pathIsDartMarketplaceManagement
        const pathIsMemberProtected = isProtectedMemberPath(pathname)
        const pathIsMembershipPayment = pathname === MEMBER_MEMBERSHIP_ROUTE

        // useAuth kann direkt nach Login/Navigation für einen sehr kurzen Moment
        // noch keine Session im React-State haben, obwohl Supabase sie bereits
        // gespeichert hat. Deshalb vor einer Umleitung einmal die echte
        // Browser-Session abfragen.
        let effectiveUser = session?.user ?? null

        if (!effectiveUser) {
          const {
            data: { session: freshSession },
            error: freshSessionError,
          } = await supabase.auth.getSession()

          if (freshSessionError) {
            console.warn("[AppRouteGuard] Session konnte nicht erneut gelesen werden:", freshSessionError)
          }

          effectiveUser = freshSession?.user ?? null
        }

        if (!effectiveUser) {
          if (pathIsMemberProtected || pathIsMembershipPayment) {
            router.replace(MEMBER_LOGIN_ROUTE)
            return
          }

          if (
            (pathIsGuest || pathIsSharedManagement) &&
            pathname !== GUEST_LOGIN_ROUTE
          ) {
            router.replace(GUEST_LOGIN_ROUTE)
            return
          }

          if (mounted) setChecking(false)
          return
        }

        const { data: profile, error } = await supabase
          .from("user_profiles")
          .select("player_id,is_guest,is_admin,is_blocked,blocked_reason")
          .eq("user_id", effectiveUser.id)
          .maybeSingle()

        if (!mounted) return

        if (error) {
          console.error(
            "[AppRouteGuard] Profil konnte nicht geprüft werden:",
            error,
          )
          setChecking(false)
          return
        }

        const userProfile = profile as UserAccessProfile | null

        if (!userProfile) {
          setChecking(false)
          return
        }

        if (userProfile.is_blocked) {
          await supabase.auth.signOut()

          if (userProfile.is_guest) {
            router.replace(GUEST_LOGIN_ROUTE)
            return
          }

          router.replace(MEMBER_LOGIN_ROUTE)
          return
        }

        if (userProfile.is_guest) {
          // DACH-Veranstaltungen und Dartbörse sind ausdrücklich auch für
          // freigeschaltete Gastzugänge erlaubt.
          if (
            isForbiddenForGuestsPath(pathname) &&
            !pathIsPublic &&
            !pathIsSharedManagement
          ) {
            router.replace(GUEST_HOME_ROUTE)
            return
          }

          if (!pathIsPublic && !pathIsGuest && !pathIsSharedManagement) {
            router.replace(GUEST_HOME_ROUTE)
            return
          }

          setChecking(false)
          return
        }

        // Mitglieds-/Modulberechtigungen werden nicht global erzwungen.
        // Der Route Guard entscheidet nur zwischen Gast, Mitglied, gesperrt
        // und nicht angemeldet. Modulspezifische Freigaben bleiben in den
        // jeweiligen Membership-Gates/Hooks.

        // Mitglieder dürfen ebenfalls alle Dartbörsen- und
        // DACH-Veranstaltungsseiten verwenden. /member-membership ist bewusst
        // auch für bereits aufgenommene Gäste erreichbar und darf bei normalen
        // Mitgliedern deshalb nicht auf die Startseite umgeleitet werden.
        if (
          !userProfile.is_guest &&
          pathIsGuest &&
          !pathIsSharedManagement &&
          !pathIsMembershipPayment
        ) {
          router.replace(MEMBER_HOME_ROUTE)
          return
        }

        setChecking(false)
      } catch (err) {
        console.error("[AppRouteGuard] Fehler:", err)
        if (mounted) setChecking(false)
      }
    }

    void checkAccess()

    return () => {
      mounted = false
    }
  }, [authLoading, session?.user?.id, pathname, router])

  // Never show the global access-check screen inside Club Terminal or EMD Messenger.
  // All other routes still use the original LoadingScreen and guard behavior.
  if (
    isTerminalPath(pathname) ||
    isMessengerPath(pathname) ||
    pathname === MEMBER_LOGIN_ROUTE ||
    pathname === GUEST_LOGIN_ROUTE
  ) {
    return <>{children}</>
  }

  if (checking || authLoading) {
    return <LoadingScreen />
  }

  return <>{children}</>
}
