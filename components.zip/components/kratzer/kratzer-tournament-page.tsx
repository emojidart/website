"use client"

import { RegistrationTab } from "@/components/kratzer/registration-tab"
import { BoardComponent } from "@/components/kratzer/board-component"
import { KratzerMartinStatus, useKratzerMartin } from "@/components/kratzer/kratzer-martin-announcer"
import { RankingsTable } from "@/components/kratzer/rankings-table"
import { NewRoundModal } from "@/components/kratzer/modals/new-round-modal"
import { ConfirmationModal } from "@/components/kratzer/modals/confirmation-modal"
import { WinnerModal } from "@/components/kratzer/modals/winner-modal"
import { LeagueStatusModal } from "@/components/kratzer/modals/league-status-modal"
import { PauseModal } from "@/components/kratzer/modals/pause-modal"
import { PrizeMoneyModal } from "@/components/kratzer/modals/prize-money-modal"
import { RecoveryBanner } from "@/components/kratzer/recovery-banner"
import { TournamentControlsCard } from "@/components/kratzer/tournament-controls-card"
import { TournamentStatsCard } from "@/components/kratzer/tournament-stats-card"
import { TournamentTabs } from "@/components/kratzer/tournament-tabs"
import { SectionCard } from "@/components/kratzer/section-card"

import { useKratzerAuth } from "@/hooks/kratzer/use-kratzer-auth"
import { useKratzerRegistration } from "@/hooks/kratzer/use-kratzer-registration"
import { useKratzerRecovery } from "@/hooks/kratzer/use-kratzer-recovery"

import { useState, useEffect, useCallback, useRef } from "react"
import { useSearchParams } from "next/navigation"

import { supabase } from "@/lib/supabase"
import type { KratzerPlayer, Board, TournamentSettings, TournamentState, GameMode } from "@/types/tournament"
import {
  formatTime,
  shuffleArray,
  getDefaultLives,
  createBoard,
} from "@/utils/tournament-utils"
import {
  createKratzerTournament,
  updateKratzerTournamentPlayersData,
  saveKratzerTournamentRound,
  updateKratzerTournamentStatus,
  addTournamentResult,
} from "@/actions/tournament"

import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardTitle } from "@/components/ui/card"

import { useToast } from "@/hooks/use-toast"
import { Trophy, Monitor, Play, Loader2 } from "lucide-react"
import { publishKratzerBeamerEvent, publishKratzerBeamerSnapshot } from "@/components/kratzer/beamer/beamer-sync"

const defaultTournamentSettings: TournamentSettings = {
  boardCount: 5,
  maxGroupSize: 5,
  suddenDeathEnabled: false,
  suddenDeathTime: 15,
  speechEnabled: false,
  diceModeEnabled: false,
}

interface PrizeMoneySettings {
  entryFee: number
  placesToPay: number
  percentages: number[]
}

type TournamentAccessType = "" | "public" | "club_internal" | "club_external"

const defaultPrizeMoneySettings: PrizeMoneySettings = {
  entryFee: 10,
  placesToPay: 4,
  percentages: [50, 30, 15, 5],
}

export function KratzerTournamentPage() {
  const { toast } = useToast()
  const { announceGroup, prefetchGroup, announcementBusy, announcementDisplay } = useKratzerMartin()
  const searchParams = useSearchParams()
  const centralEventId = searchParams.get("centralEventId")
  const [centralRegistrations, setCentralRegistrations] = useState<any[]>([])
  const [centralLoading, setCentralLoading] = useState(Boolean(centralEventId))
  const [centralAccessType, setCentralAccessType] = useState<TournamentAccessType>("")

  const { currentUser, setCurrentUser, loading, setLoading } = useKratzerAuth()

  const [tournamentState, setTournamentState] = useState<TournamentState>({
    currentRound: 0,
    tournamentId: null,
    tournamentFinished: false,
    winner: null,
    boards: [],
    players: [],
    settings: defaultTournamentSettings,
  })

  const [isTournamentRunning, setIsTournamentRunning] = useState(false)

  // Nur wenn Martin aktiviert ist: den ersten Gruppenaufruf nach der Auslosung
  // im Hintergrund vorbereiten. Keine Auswirkung auf Turnier-/Ergebnislogik.
  const prefetchSignatureRef = useRef("")
  useEffect(() => {
    if (!isTournamentRunning || !tournamentState.settings.speechEnabled) return
    const boards = tournamentState.boards.filter(board => board.players.length > 0)
    const signature = `${tournamentState.tournamentId}:${tournamentState.currentRound}:${boards.map(b => `${b.id}-${b.players.map(p => p.id).join("-")}`).join("|")}`
    if (!boards.length || signature === prefetchSignatureRef.current) return
    prefetchSignatureRef.current = signature
    let cancelled = false
    // Wenige Gruppen nacheinander, statt Martins TTS mit 5 parallelen Jobs zu blockieren.
    void (async () => {
      for (const board of boards) {
        if (cancelled) break
        await prefetchGroup(board)
      }
    })()
    return () => { cancelled = true }
  }, [isTournamentRunning, tournamentState.tournamentId, tournamentState.currentRound, tournamentState.boards, tournamentState.settings.speechEnabled, prefetchGroup])


  const [isNewRoundModalOpen, setIsNewRoundModalOpen] = useState(false)
  const [isConfirmationModalOpen, setIsConfirmationModalOpen] = useState(false)
  const [confirmationModalConfig, setConfirmationModalConfig] = useState({
    title: "",
    message: "",
    onConfirm: () => {},
  })
  const [isWinnerModalOpen, setIsWinnerModalOpen] = useState(false)
  const [isLeagueStatusModalOpen, setIsLeagueStatusModalOpen] = useState(false)
  const [isPauseModalOpen, setIsPauseModalOpen] = useState(false)
  const [isPrizeMoneyModalOpen, setIsPrizeMoneyModalOpen] = useState(false)

  const [activeTab, setActiveTab] = useState<"register" | "tournament">(centralEventId ? "tournament" : "register")

  useEffect(() => {
    if (centralEventId && isTournamentRunning) setActiveTab("tournament")
  }, [centralEventId, isTournamentRunning])
  const [tournamentAccessType, setTournamentAccessType] = useState<TournamentAccessType>("")

  const timers = useRef<Record<number, NodeJS.Timeout>>({})
  const prizeMoneySettings = useRef<PrizeMoneySettings>(defaultPrizeMoneySettings)
  const leagueStatusLivesMap = useRef<Record<string, number>>({})
  const pauseMinutesRef = useRef<HTMLInputElement>(null)
  const initializedUserIdRef = useRef<string | null>(null)

  const showToast = useCallback(
    (variant: "success" | "error" | "info" | "warning", description: string) => {
      toast({ variant, description })
    },
    [toast],
  )

  useEffect(() => {
    publishKratzerBeamerSnapshot(tournamentState, isTournamentRunning)
  }, [tournamentState, isTournamentRunning])

  const openBeamerWindow = useCallback(() => {
    const beamerWindow = window.open(
      "/kratzer-tournament/beamer",
      "emd-kratzer-beamer",
      "popup=yes,width=1600,height=900,resizable=yes,scrollbars=no",
    )

    if (!beamerWindow) {
      showToast("warning", "Beamerfenster konnte nicht geöffnet werden. Bitte Pop-ups für diese Seite erlauben.")
      return
    }

    beamerWindow.focus()
    window.setTimeout(() => publishKratzerBeamerSnapshot(tournamentState, isTournamentRunning), 250)
  }, [showToast, tournamentState, isTournamentRunning])

  const {
    registeredPlayers,
    selectedPlayersForRegistration,
    setSelectedPlayersForRegistration,
    isRegisteringPlayers,
    loadRegisteredPlayersState,
    handleRegisterPlayers,
    handleClearRegisteredPlayers,
    handleUpdatePlayerPaidStatus,
    handleMarkAllPlayersPaid,
    registrationAccessType,
  } = useKratzerRegistration({
    tournamentAccessType,
    showToast,
    setLoading,
    setConfirmationModalConfig,
    setIsConfirmationModalOpen,
  })

  // Zentraler Event: ausschließlich Teilnehmer mit exakt dieser event_id verwenden.
  useEffect(() => {
    if (!centralEventId || !currentUser?.id) return
    let cancelled = false
    const loadCentral = async () => {
      setCentralLoading(true)
      try {
        const [eventResult, registrationsResult] = await Promise.all([
          supabase.from("central_tournament_events").select("id,access_type,status").eq("id", centralEventId).single(),
          supabase.from("central_tournament_registrations").select("player_id,player_name_snapshot,paid,status").eq("event_id", centralEventId),
        ])
        if (eventResult.error) throw eventResult.error
        if (registrationsResult.error) throw registrationsResult.error
        const active = (registrationsResult.data || []).filter((r: any) => !["cancelled", "canceled", "withdrawn", "abgemeldet", "deleted"].includes(String(r.status || "").toLowerCase()))
        const ids = active.map((r: any) => r.player_id).filter(Boolean)
        const playersResult = ids.length ? await supabase.from("spieldatenbank").select("id,name,ligastatus").in("id", ids) : { data: [], error: null }
        if (playersResult.error) throw playersResult.error
        const byId = new Map((playersResult.data || []).map((x: any) => [String(x.id), x]))
        if (!cancelled) {
          setCentralRegistrations(active.map((r: any) => {
            const player: any = byId.get(String(r.player_id))
            return { id: r.player_id, name: player?.name || r.player_name_snapshot, ligastatus: player?.ligastatus || "N/A", paid: !!r.paid }
          }).filter((r: any) => r.id && r.name))
          const type = String(eventResult.data?.access_type || "public") as TournamentAccessType
          setCentralAccessType(type)
          setTournamentAccessType(type)
          setActiveTab("tournament")
        }
      } catch (error) {
        console.error("Central Kratzer registration loading failed", error)
        showToast("error", "Zentrale Anmeldungen konnten nicht geladen werden. Start gesperrt.")
      } finally { if (!cancelled) setCentralLoading(false) }
    }
    void loadCentral()
    return () => { cancelled = true }
  }, [centralEventId, currentUser?.id])

  const effectiveRegisteredPlayers = centralEventId ? centralRegistrations : registeredPlayers
  const effectiveAccessType = centralEventId ? centralAccessType : tournamentAccessType

  useEffect(() => {
    if (!centralEventId && !tournamentAccessType && registrationAccessType) {
      setTournamentAccessType(registrationAccessType)
    }
  }, [registrationAccessType, tournamentAccessType, centralEventId])

  const handleLogout = useCallback(async () => {
    setLoading(true)
    const { error } = await supabase.auth.signOut()

    if (error) {
      showToast("error", `Abmeldung fehlgeschlagen: ${error.message}`)
    } else {
      showToast("info", "Erfolgreich abgemeldet.")
      initializedUserIdRef.current = null
      setCurrentUser(null)
      setTournamentState((prev) => ({
        ...prev,
        currentRound: 0,
        tournamentId: null,
        tournamentFinished: false,
        winner: null,
        boards: [],
        players: [],
      }))
      setIsTournamentRunning(false)
      setTournamentAccessType("")
    }

    setLoading(false)
  }, [showToast, setCurrentUser, setLoading])

  const resetTournamentState = useCallback(() => {
    Object.values(timers.current).forEach(clearInterval)
    timers.current = {}

    setTournamentState({
      currentRound: 0,
      tournamentId: null,
      tournamentFinished: false,
      winner: null,
      boards: [],
      players: [],
      settings: defaultTournamentSettings,
    })

    setIsTournamentRunning(false)
  }, [])

  const finishTournament = useCallback(
    async (winnerPlayer: KratzerPlayer) => {
      setTournamentState((prev) => ({
        ...prev,
        tournamentFinished: true,
        winner: winnerPlayer,
      }))
      setIsWinnerModalOpen(true)
      setIsTournamentRunning(false)

      Object.values(timers.current).forEach(clearInterval)
      timers.current = {}

      if (tournamentState.tournamentId) {
        await updateKratzerTournamentStatus(
          tournamentState.tournamentId,
          "finished",
          winnerPlayer.id,
          winnerPlayer.name,
          tournamentState.currentRound,
        )

        const sortedPlayers = [...tournamentState.players].sort((a, b) => {
          if (a.isEliminated && !b.isEliminated) return 1
          if (!a.isEliminated && b.isEliminated) return -1
          return b.lives - a.lives
        })

        const resultsData = sortedPlayers.map((player, index) => ({
          rank: index + 1,
          name: player.name,
          ligastatus: player.ligastatus,
          lives: player.lives,
          isEliminated: player.isEliminated,
          eliminationRound: player.eliminationRound,
          eliminationTime: player.eliminationTime,
        }))

        await addTournamentResult(
          tournamentState.tournamentId,
          winnerPlayer.id,
          winnerPlayer.name,
          tournamentState.currentRound,
          resultsData,
        )

        if (centralEventId) {
          const { error: centralEventError } = await supabase
            .from("central_tournament_events")
            .update({ status: "completed", updated_at: new Date().toISOString() })
            .eq("id", centralEventId)
          if (centralEventError) console.error("Zentraler Turnierstatus konnte nicht abgeschlossen werden:", centralEventError)
        }
      }

      showToast("success", `${winnerPlayer.name} ist der Turniersieger!`)
    },
    [tournamentState, showToast, centralEventId],
  )

  const startNewRound = useCallback(async () => {
    if (tournamentState.tournamentFinished) {
      showToast("warning", "Das Turnier ist bereits beendet.")
      return
    }

    const activePlayers = tournamentState.players.filter((p) => !p.isEliminated)

    if (activePlayers.length <= 1) {
      if (activePlayers.length === 1) {
        finishTournament(activePlayers[0])
      } else {
        showToast("info", "Alle Spieler sind ausgeschieden. Kein Gewinner.")
      }
      return
    }

    const currentBoardCount = tournamentState.settings.boardCount
    const currentMaxGroupSize = tournamentState.settings.maxGroupSize
    const maxCapacity = currentBoardCount * currentMaxGroupSize

    if (maxCapacity < activePlayers.length) {
      showToast(
        "error",
        `Nicht genügend Plätze für Runde ${tournamentState.currentRound + 1}! Benötigt: ${activePlayers.length}, Verfügbar: ${maxCapacity}. Bitte passen Sie die Einstellungen an.`,
      )
      return
    }

    setIsNewRoundModalOpen(true)
  }, [tournamentState, showToast, finishTournament])

  const handleSuddenDeathTimeout = useCallback(
    async (boardId: number, boardPlayers: KratzerPlayer[]) => {
      showToast("warning", `Sudden Death: Zeit abgelaufen für Board ${boardId}!`)

      const updatedPlayers = tournamentState.players.map((p) => {
        const playerOnBoard = boardPlayers.find((bp) => bp.id === p.id)

        if (playerOnBoard) {
          const newLives = p.lives - 1

          if (newLives <= 0) {
            return {
              ...p,
              lives: 0,
              isEliminated: true,
              eliminationRound: tournamentState.currentRound,
              eliminationTime: new Date().toISOString(),
            }
          }

          return { ...p, lives: newLives }
        }

        return p
      })

      setTournamentState((prev) => ({
        ...prev,
        players: updatedPlayers,
        boards: prev.boards.filter((b) => b.id !== boardId),
      }))

      if (tournamentState.tournamentId) {
        await updateKratzerTournamentPlayersData(tournamentState.tournamentId, updatedPlayers)
      }

      const remainingPlayers = updatedPlayers.filter((p) => !p.isEliminated)

      if (remainingPlayers.length === 1 && !tournamentState.tournamentFinished) {
        finishTournament(remainingPlayers[0])
      } else if (tournamentState.boards.filter((b) => b.id !== boardId).every((b) => b.players.length === 0)) {
        showToast("info", "Alle Spiele beendet. Starte nächste Runde...")
        startNewRound()
      }
    },
    [tournamentState, showToast, finishTournament, startNewRound],
  )

  const finishGame = useCallback(
    async (boardId: number, selectedPlayerNames: string[]) => {
      const board = tournamentState.boards.find((b) => b.id === boardId)
      if (!board) return

      clearInterval(timers.current[boardId])
      delete timers.current[boardId]

      const updatedPlayers = tournamentState.players.map((p) => {
        const isSelected = selectedPlayerNames.includes(p.name)

        if (isSelected) {
          const newLives = p.lives - 1

          if (newLives <= 0) {
            return {
              ...p,
              lives: 0,
              isEliminated: true,
              eliminationRound: tournamentState.currentRound,
              eliminationTime: new Date().toISOString(),
            }
          }

          return { ...p, lives: newLives }
        }

        return p
      })

      setTournamentState((prev) => ({
        ...prev,
        players: updatedPlayers,
        boards: prev.boards.filter((b) => b.id !== boardId),
      }))

      if (tournamentState.tournamentId) {
        await updateKratzerTournamentPlayersData(tournamentState.tournamentId, updatedPlayers)
      }

      const remainingPlayersOverall = updatedPlayers.filter((p) => !p.isEliminated)

      if (remainingPlayersOverall.length === 1) {
        finishTournament(remainingPlayersOverall[0])
        return
      }

      const allBoardsFinished = tournamentState.boards
        .filter((b) => b.id !== boardId)
        .every((b) => b.players.length === 0)

      if (allBoardsFinished) {
        showToast("info", "Alle Spiele der Runde beendet. Starte nächste Runde...")
        startNewRound()
      } else {
        showToast("success", `Spiel auf Board ${boardId} beendet.`)
      }
    },
    [tournamentState, showToast, startNewRound, finishTournament],
  )

  const editPlayerLives = useCallback(
    async (playerId: string, newLives: number) => {
      setLoading(true)

      const updatedPlayers = tournamentState.players.map((p) => {
        if (p.id === playerId) {
          const wasEliminated = p.isEliminated
          const isNowEliminated = newLives === 0

          return {
            ...p,
            lives: newLives,
            isEliminated: isNowEliminated,
            eliminationRound:
              !wasEliminated && isNowEliminated
                ? tournamentState.currentRound
                : wasEliminated && !isNowEliminated
                  ? null
                  : p.eliminationRound,
            eliminationTime:
              !wasEliminated && isNowEliminated
                ? new Date().toISOString()
                : wasEliminated && !isNowEliminated
                  ? null
                  : p.eliminationTime,
          }
        }

        return p
      })

      setTournamentState((prev) => ({ ...prev, players: updatedPlayers }))

      if (tournamentState.tournamentId) {
        await updateKratzerTournamentPlayersData(tournamentState.tournamentId, updatedPlayers)
      }

      const remainingPlayers = updatedPlayers.filter((p) => !p.isEliminated)

      if (remainingPlayers.length === 1 && !tournamentState.tournamentFinished) {
        finishTournament(remainingPlayers[0])
      }

      showToast("success", "Spielerleben aktualisiert.")
      setLoading(false)
    },
    [tournamentState, showToast, finishTournament, setLoading],
  )

  const togglePlayerElimination = useCallback(
    async (playerId: string) => {
      setLoading(true)

      const updatedPlayers = tournamentState.players.map((p) => {
        if (p.id === playerId) {
          const newEliminationStatus = !p.isEliminated

          return {
            ...p,
            isEliminated: newEliminationStatus,
            eliminationRound: newEliminationStatus ? tournamentState.currentRound : null,
            eliminationTime: newEliminationStatus ? new Date().toISOString() : null,
            lives: !newEliminationStatus && p.lives === 0 ? 1 : p.lives,
          }
        }

        return p
      })

      setTournamentState((prev) => ({ ...prev, players: updatedPlayers }))

      try {
        const playerToUpdate = updatedPlayers.find((p) => p.id === playerId)

        if (playerToUpdate) {
          const { error } = await supabase
            .from("kratzer_tournament_players")
            .update({
              lives: playerToUpdate.lives,
              is_eliminated: playerToUpdate.isEliminated,
              elimination_round: playerToUpdate.eliminationRound,
              elimination_time: playerToUpdate.eliminationTime,
            })
            .eq("player_id", playerId)

          if (error) throw error

          showToast("success", "Spielerstatus erfolgreich geändert!")
        }
      } catch (err: any) {
        showToast("error", `Fehler beim Ändern des Spielerstatus: ${err.message}`)
        console.error("Error toggling player elimination:", err)
      } finally {
        setLoading(false)
      }
    },
    [tournamentState.players, tournamentState.currentRound, showToast, setLoading],
  )

  const cancelGame = useCallback(
    async (boardId: number) => {
      setConfirmationModalConfig({
        title: "Spiel abbrechen",
        message: "Möchten Sie dieses Spiel wirklich abbrechen?",
        onConfirm: async () => {
          clearInterval(timers.current[boardId])
          delete timers.current[boardId]

          setTournamentState((prev) => ({
            ...prev,
            boards: prev.boards.filter((b) => b.id !== boardId),
          }))

          if (tournamentState.boards.filter((b) => b.id !== boardId).every((b) => b.players.length === 0)) {
            showToast("info", "Alle Spiele beendet. Starte nächste Runde...")
            startNewRound()
          } else {
            showToast("info", `Spiel auf Board ${boardId} abgebrochen.`)
          }
        },
      })

      setIsConfirmationModalOpen(true)
    },
    [tournamentState.boards, showToast, startNewRound],
  )

  const startBoardTimer = useCallback(
    (boardId: number, initialStartTime: number | null = null) => {
      const board = tournamentState.boards.find((b) => b.id === boardId)
      if (!board) return

      const startTime = initialStartTime || Date.now()
      const suddenDeathEnabledForGame = tournamentState.settings.suddenDeathEnabled
      const suddenDeathMinutesForGame = tournamentState.settings.suddenDeathTime

      setTournamentState((prev) => ({
        ...prev,
        boards: prev.boards.map((b) => (b.id === boardId ? { ...b, startTime } : b)),
      }))

      if (timers.current[boardId]) clearInterval(timers.current[boardId])

      timers.current[boardId] = setInterval(() => {
        const elapsedTime = Date.now() - startTime
        const timeLimit = suddenDeathMinutesForGame * 60 * 1000

        const boardElement = document.querySelector(`[data-board-id="${boardId}"]`)
        const timerElement = boardElement?.querySelector(".board-timer")

        if (timerElement) {
          timerElement.textContent = formatTime(elapsedTime)

          if (suddenDeathEnabledForGame) {
            const remainingTime = timeLimit - elapsedTime

            timerElement.classList.remove("warning", "critical")

            if (remainingTime <= 60000) timerElement.classList.add("critical")
            else if (remainingTime <= 180000) timerElement.classList.add("warning")

            if (elapsedTime >= timeLimit) {
              clearInterval(timers.current[boardId])
              delete timers.current[boardId]

              handleSuddenDeathTimeout(boardId, board.players)
            }
          }
        }
      }, 1000)
    },
    [tournamentState.boards, tournamentState.settings, handleSuddenDeathTimeout],
  )

  const {
    activeTournamentExists,
    recoveryTournamentData,
    checkForActiveTournament,
    restoreTournament,
    startNewTournamentFromRecovery,
  } = useKratzerRecovery({
    currentUser,
    centralEventId,
    showToast,
    setLoading,
    resetTournamentState,
    setTournamentState,
    startBoardTimer,
    setIsTournamentRunning,
  })

  useEffect(() => {
    const userId = currentUser?.id
    if (!userId) {
      initializedUserIdRef.current = null
      return
    }

    // Erst ausführen, nachdem useKratzerRecovery initialisiert wurde.
    if (initializedUserIdRef.current === userId) return
    initializedUserIdRef.current = userId

    void Promise.all([
      checkForActiveTournament(),
      ...(centralEventId ? [] : [loadRegisteredPlayersState()]),
    ])
  }, [currentUser?.id, centralEventId, checkForActiveTournament, loadRegisteredPlayersState])

  const startTournament = useCallback(async () => {
    if (isTournamentRunning) {
      showToast("warning", "Turnier läuft bereits.")
      return
    }

    if (tournamentState.tournamentFinished) {
      showToast("warning", "Das Turnier ist bereits beendet. Bitte starten Sie ein neues Turnier.")
      return
    }

    if (centralLoading) { showToast("warning", "Zentrale Anmeldung wird geladen."); return }
    if (!effectiveAccessType) {
      showToast("warning", "Bitte zuerst die Turnierart auswählen.")
      setActiveTab("register")
      return
    }

    if (effectiveRegisteredPlayers.length === 0) {
      showToast("warning", "Keine Spieler registriert. Bitte registrieren Sie Spieler zuerst.")
      return
    }

    const initialPlayers: KratzerPlayer[] = effectiveRegisteredPlayers.map((p) => ({
      id: p.id,
      name: p.name,
      ligastatus: p.ligastatus || "N/A",
      lives: getDefaultLives(p.ligastatus || "N/A"),
      isEliminated: false,
      eliminationRound: null,
      eliminationTime: null,
    }))

    const { boardCount, maxGroupSize } = tournamentState.settings

    if (boardCount * maxGroupSize < initialPlayers.length) {
      showToast(
        "error",
        "Nicht genügend Plätze für alle Spieler. Bitte erhöhen Sie die Anzahl der Automaten oder die maximale Gruppengröße.",
      )
      return
    }

    setLoading(true)

    try {
      const { success, message, data } = await createKratzerTournament(
        tournamentState.settings,
        initialPlayers,
        effectiveAccessType,
        currentUser.id,
        centralEventId,
      )

      if (!success || !data?.tournamentId) throw new Error(message)

      setTournamentState((prev) => ({
        ...prev,
        tournamentId: data.tournamentId,
        players: initialPlayers,
      }))

      setIsTournamentRunning(true)
      if (centralEventId) {
        const { error: centralEventError } = await supabase
          .from("central_tournament_events")
          .update({ status: "started", selected_mode: "kratzer", updated_at: new Date().toISOString() })
          .eq("id", centralEventId)
        if (centralEventError) throw centralEventError
      }
      showToast("success", "Turnier erfolgreich gestartet!")
      setIsNewRoundModalOpen(true)
    } catch (error: any) {
      console.error("Error starting tournament:", error.message)
      showToast("error", `Fehler beim Starten des Turniers: ${error.message}`)
    } finally {
      setLoading(false)
    }
  }, [
    currentUser,
    effectiveRegisteredPlayers,
    centralLoading,
    isTournamentRunning,
    tournamentState.tournamentFinished,
    tournamentState.settings,
    effectiveAccessType,
    showToast,
    setLoading,
    centralEventId,
  ])

  const executeNewRound = useCallback(async (gameMode?: GameMode) => {
    setIsNewRoundModalOpen(false)
    setLoading(true)

    const nextRoundNumber = tournamentState.currentRound + 1
    const { boardCount, maxGroupSize, speechEnabled } = tournamentState.settings
    const activePlayers = shuffleArray(tournamentState.players.filter((p) => !p.isEliminated))

    const newBoards: Board[] = []
    for (let i = 1; i <= boardCount; i++) {
      const board = createBoard(i)
      board.gameMode = gameMode ?? null
      newBoards.push(board)
    }

    let playerIndex = 0
    while (playerIndex < activePlayers.length) {
      for (const board of newBoards) {
        if (playerIndex >= activePlayers.length) break
        if (board.players.length < maxGroupSize) {
          board.players.push(activePlayers[playerIndex])
          playerIndex++
        }
      }
    }

    const boardsToSave = newBoards.filter((b) => b.players.length > 0)

    try {
      if (tournamentState.tournamentId) {
        const { success, message } = await saveKratzerTournamentRound(
          tournamentState.tournamentId,
          nextRoundNumber,
          boardsToSave,
        )

        if (!success) throw new Error(message)
      }

      setTournamentState((prev) => ({
        ...prev,
        currentRound: nextRoundNumber,
        boards: boardsToSave,
      }))

      showToast(
        "success",
        gameMode
          ? `Runde ${nextRoundNumber} gestartet – Modus: ${gameMode}`
          : `Runde ${nextRoundNumber} gestartet!`,
      )

    } catch (error: any) {
      console.error("Error executing new round:", error.message)
      showToast("error", `Fehler beim Starten der Runde: ${error.message}`)
    } finally {
      setLoading(false)
    }
  }, [tournamentState, showToast, setLoading])

  const completeTournament = useCallback(async () => {
    if (!tournamentState.tournamentId) return

    showToast("info", "Turnier wird abgeschlossen und Daten finalisiert...")
    await updateKratzerTournamentStatus(tournamentState.tournamentId, "finished")
    if (centralEventId) {
      const { error: centralEventError } = await supabase
        .from("central_tournament_events")
        .update({ status: "completed", updated_at: new Date().toISOString() })
        .eq("id", centralEventId)
      if (centralEventError) throw centralEventError
    }
    showToast("success", "Turnier erfolgreich abgeschlossen.")
    if (centralEventId) {
      try { window.sessionStorage.setItem("emd-admin-current-view", "tournament-center") } catch {}
    }
    window.location.href = "/admin"
  }, [tournamentState.tournamentId, showToast, centralEventId])

  const confirmCancelTournament = useCallback(() => {
    setConfirmationModalConfig({
      title: "Turnier abbrechen",
      message: "Sind Sie sicher, dass Sie das gesamte Turnier abbrechen möchten? Alle Daten gehen verloren.",
      onConfirm: async () => {
        if (tournamentState.tournamentId) {
          await updateKratzerTournamentStatus(tournamentState.tournamentId, "cancelled")
          if (centralEventId) {
            const { error: centralEventError } = await supabase
              .from("central_tournament_events")
              .update({ status: "cancelled", updated_at: new Date().toISOString() })
              .eq("id", centralEventId)
            if (centralEventError) throw centralEventError
          }
          showToast("info", "Turnier abgebrochen.")
        }

        resetTournamentState()
        showToast("info", "Turnier abgebrochen.")
        if (centralEventId) {
      try { window.sessionStorage.setItem("emd-admin-current-view", "tournament-center") } catch {}
    }
    window.location.href = "/admin"
      },
    })

    setIsConfirmationModalOpen(true)
  }, [tournamentState.tournamentId, showToast, resetTournamentState, centralEventId])

  const handleSettingsChange = useCallback((key: keyof TournamentSettings, value: any) => {
    if (key === "suddenDeathTime" && (!Number.isFinite(value) || value < 1 || value > 60)) return
    if (!isTournamentRunning || !tournamentState.tournamentId || !["speechEnabled", "suddenDeathEnabled", "suddenDeathTime"].includes(key)) {
      setTournamentState((prev) => ({ ...prev, settings: { ...prev.settings, [key]: value } }))
      return
    }

    const dbColumn = key === "speechEnabled" ? "speech_enabled" : key === "suddenDeathEnabled" ? "sudden_death_enabled" : "sudden_death_time"
    const tournamentId = tournamentState.tournamentId
    // First save, then update UI: a failed save must never appear successful.
    void (async () => {
      const { error } = await supabase
        .from("kratzer_tournaments")
        .update({ [dbColumn]: value })
        .eq("id", tournamentId)
        .eq("status", "running")
      if (error) {
        showToast("error", `Einstellung konnte nicht gespeichert werden: ${error.message}`)
        return
      }
      setTournamentState((prev) => ({ ...prev, settings: { ...prev.settings, [key]: value } }))
      showToast("success", key === "speechEnabled" ? "Martin-Sprachausgabe gespeichert." : "Sudden Death gespeichert – gilt für neu gestartete Spiele.")
    })()
  }, [isTournamentRunning, tournamentState.tournamentId, showToast])

  const togglePause = useCallback(() => {
    setIsPauseModalOpen(true)
  }, [])

  const startPauseTimer = useCallback(
    (minutes: number) => {
      setIsPauseModalOpen(false)
      showToast("info", `Pause für ${minutes} Minuten gestartet.`)
      publishKratzerBeamerEvent({
        type: "pause-start",
        minutes,
        until: Date.now() + minutes * 60 * 1000,
      })

      setTimeout(() => {
        showToast("info", "Pause beendet!")
        publishKratzerBeamerEvent({ type: "pause-end" })
      }, minutes * 60 * 1000)
    },
    [showToast],
  )

  const showLeagueStatusModal = useCallback(() => {
    setIsLeagueStatusModalOpen(true)
  }, [])

  const saveLeagueStatusLives = useCallback(
    async (updatedLivesMap: Record<string, number>) => {
      setIsLeagueStatusModalOpen(false)
      setLoading(true)

      const updatedPlayers = tournamentState.players.map((p) => {
        if (!p.isEliminated && p.ligastatus && updatedLivesMap[p.ligastatus] !== undefined) {
          return { ...p, lives: updatedLivesMap[p.ligastatus] }
        }

        return p
      })

      setTournamentState((prev) => ({ ...prev, players: updatedPlayers }))

      if (tournamentState.tournamentId) {
        await updateKratzerTournamentPlayersData(tournamentState.tournamentId, updatedPlayers)
      }

      showToast("success", "Leben pro Ligastatus aktualisiert.")
      setLoading(false)
    },
    [tournamentState, showToast, setLoading],
  )

  const showPrizeMoneyModal = useCallback(() => {
    setIsPrizeMoneyModalOpen(true)
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100 p-4">
        <Loader2 className="h-16 w-16 animate-spin text-primary-dark" />
        <p className="mt-4 text-gray-700 text-lg font-semibold">Lade Turnierdaten...</p>
      </div>
    )
  }

  if (!currentUser) {
    return (
      <div className="min-h-screen flex flex-col bg-gray-100">
        <KratzerMartinStatus display={announcementDisplay} />
      <Header />
        <main className="container mx-auto p-4 flex flex-col items-center justify-center flex-grow">
          <Card className="w-full max-w-md p-6 shadow-lg">
            <CardTitle className="text-2xl font-bold text-center mb-6">Zugriff erforderlich</CardTitle>
            <CardContent className="text-center">
              <p className="mb-4 text-gray-700">Bitte melden Sie sich an, um auf das Kratzer-Turnier zuzugreifen.</p>
              <Button onClick={() => (window.location.href = "/spielerdatenbank")} className="w-full">
                Zur Anmeldung
              </Button>
            </CardContent>
          </Card>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#f4f6f8] text-slate-950">
      <KratzerMartinStatus display={announcementDisplay} />
      <Header />


      <main className="mx-auto w-full max-w-[1920px] px-3 py-5 sm:px-5 lg:px-8 xl:px-10 2xl:px-12">
        {!centralEventId && activeTournamentExists && recoveryTournamentData && (
          <RecoveryBanner
            recoveryTournamentData={recoveryTournamentData}
            onRestore={restoreTournament}
            onStartNew={startNewTournamentFromRecovery}
          />
        )}

        {!centralEventId && <TournamentTabs activeTab={activeTab} setActiveTab={setActiveTab} />}
        

        {activeTab === "register" ? (
          <RegistrationTab
            currentUser={currentUser}
            tournamentAccessType={tournamentAccessType}
            setTournamentAccessType={setTournamentAccessType}
            registeredPlayers={effectiveRegisteredPlayers}
            selectedPlayersForRegistration={selectedPlayersForRegistration}
            setSelectedPlayersForRegistration={setSelectedPlayersForRegistration}
            handleRegisterPlayers={handleRegisterPlayers}
            handleClearRegisteredPlayers={handleClearRegisteredPlayers}
            handleUpdatePlayerPaidStatus={handleUpdatePlayerPaidStatus}
            handleMarkAllPlayersPaid={handleMarkAllPlayersPaid}
            isRegisteringPlayers={isRegisteringPlayers}
            loading={loading}
          />
        ) : (
          <>
            <TournamentControlsCard
              settings={tournamentState.settings}
              isTournamentRunning={isTournamentRunning}
              tournamentFinished={tournamentState.tournamentFinished}
              loading={loading}
              activeTournamentExists={activeTournamentExists}
              currentRound={tournamentState.currentRound}
              registeredPlayersCount={effectiveRegisteredPlayers.length}
              onSettingsChange={handleSettingsChange}
              onStartTournament={startTournament}
              onStartNewRound={startNewRound}
              onShowLeagueStatus={showLeagueStatusModal}
              onShowPrizeMoney={showPrizeMoneyModal}
              onTogglePause={togglePause}
              onFinishTournament={() =>
                finishTournament(
                  tournamentState.winner || tournamentState.players.filter((p) => !p.isEliminated)[0],
                )
              }
              onCancelTournament={confirmCancelTournament}
              onOpenBeamer={openBeamerWindow}
            />

            <TournamentStatsCard
              players={tournamentState.players}
              currentRound={tournamentState.currentRound}
              tournamentFinished={tournamentState.tournamentFinished}
              winner={tournamentState.winner}
            />

            <SectionCard
              title={
                tournamentState.boards[0]?.gameMode
                  ? `Aktuelle Runde · ${tournamentState.boards[0].gameMode}`
                  : "Aktuelle Runde"
              }
              icon={<Monitor className="h-6 w-6 text-orange-600" />}
            >
              {tournamentState.boards.length === 0 ? (
                <div className="rounded-[24px] border border-dashed border-slate-200 bg-slate-50/70 px-6 py-14 text-center">
                  <p className="text-lg font-black text-slate-900">Noch keine aktive Runde</p>
                  <p className="mt-2 text-sm font-medium text-slate-500">Starte die nächste Runde, sobald alle Einstellungen passen.</p>
                  <Button onClick={startNewRound} className="mt-6 h-11 rounded-xl bg-orange-600 px-5 font-black text-white hover:bg-orange-700">
                    <Play className="h-4 w-4 mr-2" />
                    Neue Runde starten
                  </Button>
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4">
                  {tournamentState.boards.map((board) => (
                    <BoardComponent
                      key={board.id}
                      board={board}
                      suddenDeathEnabled={tournamentState.settings.suddenDeathEnabled}
                      suddenDeathTime={tournamentState.settings.suddenDeathTime}
                      speechEnabled={tournamentState.settings.speechEnabled}
                      onStartGame={startBoardTimer}
                      onFinishGame={finishGame}
                      onCancelGame={cancelGame}
                      onMakeCall={() => {}}
                      onAnnounceGroup={announceGroup}
                      announcementBusy={announcementBusy}
                      currentRound={tournamentState.currentRound}
                    />
                  ))}
                </div>
              )}
            </SectionCard>

            <SectionCard
              title="Rangliste"
              icon={<Trophy className="h-6 w-6 text-orange-600" />}
            >
              <RankingsTable
                players={tournamentState.players}
                currentRound={tournamentState.currentRound}
                onEditPlayerLives={editPlayerLives}
                onTogglePlayerElimination={togglePlayerElimination}
                loading={loading}
              />
            </SectionCard>
          </>
        )}
      </main>

      <NewRoundModal
        open={isNewRoundModalOpen}
        onOpenChange={setIsNewRoundModalOpen}
        currentRound={tournamentState.currentRound}
        settings={tournamentState.settings}
        players={tournamentState.players}
        onSettingsChange={handleSettingsChange}
        onExecuteRound={executeNewRound}
      />

      <ConfirmationModal
        open={isConfirmationModalOpen}
        onOpenChange={setIsConfirmationModalOpen}
        title={confirmationModalConfig.title}
        message={confirmationModalConfig.message}
        onConfirm={confirmationModalConfig.onConfirm}
      />

      <WinnerModal
        open={isWinnerModalOpen}
        onOpenChange={setIsWinnerModalOpen}
        winner={tournamentState.winner}
        currentRound={tournamentState.currentRound}
        onComplete={completeTournament}
      />

      <LeagueStatusModal
        open={isLeagueStatusModalOpen}
        onOpenChange={setIsLeagueStatusModalOpen}
        players={tournamentState.players}
        leagueStatusLivesMap={leagueStatusLivesMap}
        onSave={saveLeagueStatusLives}
      />

      <PauseModal
        open={isPauseModalOpen}
        onOpenChange={setIsPauseModalOpen}
        pauseMinutesRef={pauseMinutesRef}
        onStartPause={startPauseTimer}
      />

      <PrizeMoneyModal
        open={isPrizeMoneyModalOpen}
        onOpenChange={setIsPrizeMoneyModalOpen}
        registeredPlayers={registeredPlayers}
        prizeMoneySettings={prizeMoneySettings}
      />
    </div>
  )
}