"use client"

export const dynamic = "force-dynamic"

import { Suspense, useEffect, useMemo, useState } from "react"
import { useRouter } from "next/navigation"

import { supabase } from "@/lib/supabase"
import { useAuth } from "@/hooks/use-auth"

import { Header } from "@/components/header"
import { MobileBottomNav } from "@/components/mobile-bottom-nav"

import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { cn } from "@/lib/utils"

import { Bell, Loader2, Trophy, Clock, Cpu, BellOff } from "lucide-react"

interface UserProfile {
  id: string
  user_id: string
  player_id: string
  club_players: { id: string; name: string; photo_url: string | null } | null
}

type PushPrefRow = {
  user_id: string
  tournament_push_enabled: boolean
  updated_at: string | null
}

type DkoMatchStateRow = {
  id: number
  tournament_type: string | null // (wird NICHT angezeigt)
  tournament_id: string | null
  match_id: number
  player1: string | null
  player2: string | null
  machine_number: number | null
  push_started_sent_at: string | null
  updated_at: string | null
}

function formatDateTimeCompact(input?: string | null) {
  if (!input) return "—"
  const d = new Date(input)
  if (!Number.isFinite(d.getTime())) return "—"
  const date = d.toLocaleDateString("de-DE", { day: "2-digit", month: "2-digit", year: "numeric" })
  const time = d.toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" })
  return `${date} • ${time}`
}

function TournamentPushInner() {
  const router = useRouter()
  const { session, loading: authLoading } = useAuth()

  const [loading, setLoading] = useState(true)
  const [profile, setProfile] = useState<UserProfile | null>(null)

  const [pushEnabled, setPushEnabled] = useState(true)
  const [pushPrefUpdatedAt, setPushPrefUpdatedAt] = useState<string | null>(null)
  const [savingPref, setSavingPref] = useState(false)

  const [pushRows, setPushRows] = useState<DkoMatchStateRow[]>([])
  const [loadingPushRows, setLoadingPushRows] = useState(false)

  useEffect(() => {
    if (!authLoading && !session) router.push("/member-login")
  }, [session, authLoading, router])

  useEffect(() => {
    if (!session?.user) return
    ;(async () => {
      setLoading(true)
      await fetchProfileAndPrefs()
      setLoading(false)
    })()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session?.user?.id])

  useEffect(() => {
    if (!profile?.club_players?.name) return
    ;(async () => {
      await fetchLastTournamentStarts(profile.club_players!.name)
    })()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [profile?.club_players?.name])

  async function fetchProfileAndPrefs() {
    try {
      const { data: profileData, error: profileError } = await supabase
        .from("user_profiles")
        .select(`id, user_id, player_id, club_players (id, name, photo_url)`)
        .eq("user_id", session!.user.id)
        .single()

      if (profileError) {
        console.error("fetch profile error", profileError)
        setProfile(null)
        return
      }

      setProfile(profileData as any)

      const { data: pref, error: prefError } = await supabase
        .from("push_preferences")
        .select("user_id, tournament_push_enabled, updated_at")
        .eq("user_id", session!.user.id)
        .maybeSingle()

      if (prefError) {
        console.error("fetch push_preferences error", prefError)
        setPushEnabled(true)
        setPushPrefUpdatedAt(null)
        return
      }

      if (!pref) {
        setPushEnabled(true)
        setPushPrefUpdatedAt(null)
      } else {
        setPushEnabled(Boolean((pref as any).tournament_push_enabled))
        setPushPrefUpdatedAt((pref as any).updated_at ?? null)
      }
    } catch (e) {
      console.error("fetchProfileAndPrefs error", e)
      setProfile(null)
    }
  }

  async function fetchLastTournamentStarts(playerName: string) {
    setLoadingPushRows(true)
    try {
      const { data, error } = await supabase
        .from("dko_match_states")
        .select("id, tournament_id, match_id, player1, player2, machine_number, push_started_sent_at, updated_at, tournament_type")
        .not("push_started_sent_at", "is", null)
        .or(`player1.eq.${playerName},player2.eq.${playerName}`)
        .order("push_started_sent_at", { ascending: false })
        .limit(20)

      if (error) throw error
      setPushRows(((data as any) || []) as DkoMatchStateRow[])
    } catch (e) {
      console.error("fetchLastTournamentStarts error", e)
      setPushRows([])
    } finally {
      setLoadingPushRows(false)
    }
  }

  const displayName = profile?.club_players?.name ?? "—"

  const list = useMemo(() => {
    return pushRows.map((r) => {
      const p1 = r.player1 ?? ""
      const p2 = r.player2 ?? ""
      const meIsP1 = p1 === displayName
      const opponent = meIsP1 ? p2 : p1
      return { row: r, opponent: opponent || "—" }
    })
  }, [pushRows, displayName])

  async function toggleTournamentNotifications() {
    if (!session?.user?.id) return
    if (savingPref) return

    const next = !pushEnabled
    setSavingPref(true)
    try {
      const payload: PushPrefRow = {
        user_id: session.user.id,
        tournament_push_enabled: next,
        updated_at: new Date().toISOString(),
      }

      const { error } = await supabase.from("push_preferences").upsert(payload, {
        onConflict: "user_id",
      })

      if (error) throw error

      setPushEnabled(next)
      setPushPrefUpdatedAt(payload.updated_at)
    } catch (e) {
      console.error("toggleTournamentNotifications error", e)
      alert("Konnte Einstellung nicht speichern.")
    } finally {
      setSavingPref(false)
    }
  }

  // ✅ SCHÖNE LADEANIMATION + APP HEADER (wie deine andere Datei) + kein extra padding oben
  if (authLoading || loading) {
    return (
      <main className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
        <Header
          variant="app"
          title="Turnier-Benachrichtigungen"
          subtitle="Einstellungen"
          backHref="/member-profile-app"
        />

        <div className="flex-1 flex items-center justify-center px-4 pb-20">
          <div className="animate-in fade-in zoom-in-95 duration-300">
            <div className="flex flex-col items-center gap-6 rounded-3xl bg-white shadow-2xl px-10 py-10">
              <div className="relative">
                <div className="absolute inset-0 rounded-full bg-orange-500/30 blur-2xl animate-pulse" />
                <Loader2 className="relative h-12 w-12 animate-spin text-orange-600" />
              </div>

              <div className="text-center">
                <p className="text-lg font-bold text-gray-900">Lade Einstellungen</p>
                <p className="text-sm text-gray-500 mt-1">Bitte kurz warten…</p>
              </div>
            </div>
          </div>
        </div>

        <MobileBottomNav />
      </main>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 font-sans flex flex-col overflow-x-hidden">
      {/* ✅ App Header statt normalem Header */}
      <Header
        variant="app"
        title="Turnier-Benachrichtigungen"
        subtitle="Einstellungen"
        backHref="/member-profile-app"
      />

      <main className="flex-grow mx-auto w-full px-4 sm:px-6 py-4 sm:py-6 pb-24 md:pb-8 max-w-2xl lg:max-w-screen-xl 2xl:max-w-screen-2xl overflow-x-hidden">
        <div className="mb-4">
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900 flex items-center gap-2">
            <Trophy className="h-6 w-6 text-orange-600" />
            
          </h1>

          {/* ✅ moderne Box mit ORANGE Verlauf oben */}
          <div className="mt-4 overflow-hidden rounded-2xl border bg-white shadow-sm">
            <div className="h-1.5 bg-gradient-to-r from-orange-500 via-orange-400 to-amber-300" />
            <div className="p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="text-xs text-gray-500">Spieler</div>
                  <div className="mt-0.5 text-base sm:text-lg font-semibold text-gray-900 truncate">
                    <span className="text-orange-700">{displayName}</span>
                  </div>

                  <div className="mt-2 flex flex-wrap items-center gap-2">
                    <Badge
                      className={cn(
                        "rounded-full px-3 py-1 text-xs sm:text-sm whitespace-nowrap",
                        pushEnabled
                          ? "bg-green-50 text-green-700 border border-green-200"
                          : "bg-gray-50 text-gray-700 border border-gray-200"
                      )}
                    >
                      {pushEnabled ? "Benachrichtigungen aktiv" : "Benachrichtigungen aus"}
                    </Badge>

                    {pushPrefUpdatedAt ? (
                      <span className="text-xs text-gray-500 inline-flex items-center gap-1 whitespace-nowrap">
                        <Clock className="h-3.5 w-3.5" />
                        {formatDateTimeCompact(pushPrefUpdatedAt)}
                      </span>
                    ) : null}
                  </div>
                </div>

                <div className="flex flex-col items-end gap-2 shrink-0">
                  <Switch checked={pushEnabled} onCheckedChange={() => toggleTournamentNotifications()} disabled={savingPref} />
                  <div className="text-[11px] text-gray-500 whitespace-nowrap">
                    {savingPref ? (
                      <span className="inline-flex items-center gap-1">
                        <Loader2 className="h-3.5 w-3.5 animate-spin" />
                        speichere…
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1">
                        {pushEnabled ? <Bell className="h-3.5 w-3.5" /> : <BellOff className="h-3.5 w-3.5" />}
                        Match-Start Hinweise erhalten
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <p className="mt-3 text-sm text-gray-600 leading-relaxed">
                Übersicht der letzten 20 Match-Starts mit Gegner und – sofern vorhanden – Automat.
              </p>

              <div className="mt-4 rounded-2xl border bg-gray-50 p-4 flex items-start gap-3">
                <div className="mt-0.5 rounded-xl bg-white p-2 ring-1 ring-black/5">
                  <Bell className="h-4 w-4 text-orange-600" />
                </div>
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-gray-900">Hinweis</div>
                  <div className="mt-1 text-sm text-gray-600">
                    Wenn deaktiviert, bekommst du keine Hinweise, sobald dein Match gestartet wird.
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <Card className="shadow-xl border-0 bg-white">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-xl font-bold">
              <Bell className="h-6 w-6 text-orange-600" />
              Letzte 20 Match-Starts
            </CardTitle>
          </CardHeader>

          <CardContent>
            {loadingPushRows ? (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin text-orange-600" />
                Lade Einträge…
              </div>
            ) : list.length === 0 ? (
              <div className="text-sm text-muted-foreground">
                Keine Einträge gefunden (noch kein Match gestartet oder noch kein push_started_sent_at gesetzt).
              </div>
            ) : (
              <div className="grid gap-3">
                {list.map(({ row, opponent }) => (
                  <Card
                    key={`${row.tournament_id ?? "t"}-${row.match_id}-${row.id}`}
                    className="border bg-white shadow-sm hover:shadow-md transition-shadow rounded-2xl overflow-hidden"
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-3 min-w-0">
                        <div className="min-w-0">
                          <div className="font-semibold text-base md:text-lg truncate">
                            vs <span className="text-gray-900">{opponent}</span>
                          </div>

                          <div className="mt-2 text-sm text-gray-600 inline-flex items-center gap-2 flex-wrap">
                            <span className="inline-flex items-center gap-1">
                              <Clock className="h-4 w-4 text-orange-600" />
                              {formatDateTimeCompact(row.push_started_sent_at)}
                            </span>
                            <Badge variant="outline" className="whitespace-nowrap">
                              Match {row.match_id}
                            </Badge>
                          </div>
                        </div>

                        {row.machine_number !== null && row.machine_number !== undefined ? (
                          <Badge className="shrink-0 bg-orange-100 text-orange-800 border-orange-200 whitespace-nowrap">
                            <Cpu className="h-3.5 w-3.5 mr-1" />
                            Automat {row.machine_number}
                          </Badge>
                        ) : null}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>

      <MobileBottomNav />
    </div>
  )
}

export default function MemberTournamentPushPage() {
  return (
    <Suspense fallback={null}>
      <TournamentPushInner />
    </Suspense>
  )
}