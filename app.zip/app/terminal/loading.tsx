import TerminalLoader from "./_components/TerminalLoader"

export default function Loading() {
  return <TerminalLoader label="Terminal wird vorbereitet" />
}
