"use client"

import Link from "next/link"
import { ArrowRight, CalendarDays, Swords, Trophy } from "lucide-react"

type StartseitenHeroProps = {
  leagueMatchCount: number
  todaysEventCount: number
  tournamentCount: number
}

export function StartseitenHero({ leagueMatchCount, todaysEventCount, tournamentCount }: StartseitenHeroProps) {
  const stats = [
    { label: "Ligaspiele", value: leagueMatchCount, icon: Swords, href: "/member-availability" },
    { label: "Termine heute", value: todaysEventCount, icon: CalendarDays, href: "/veranstaltungen" },
    { label: "Turniere", value: tournamentCount, icon: Trophy, href: "/turniere" },
  ]

  return (
    <section aria-labelledby="home-heading" className="mx-auto w-full max-w-[var(--emd-content-max)] px-4 pt-6 sm:px-6 lg:px-8 lg:pt-10">
      <div className="emd-home-hero overflow-hidden rounded-3xl border border-border bg-card">
        <div className="grid lg:grid-cols-[1.2fr_1fr]">
          <div className="p-6 sm:p-9 lg:p-11">
            <div className="mb-7 flex items-center gap-2.5 text-xs font-semibold tracking-[0.16em] text-primary uppercase">
              <span className="h-2 w-2 rounded-full bg-primary" aria-hidden="true" />
              Emoj&apos;s Dartverein
            </div>
            <h1 id="home-heading" className="max-w-xl text-[clamp(2.4rem,5vw,4.4rem)] font-semibold leading-[1.04] tracking-[-0.05em] text-foreground">
              Dein Verein.<br />Dein nächster <span className="text-primary">Wurf.</span>
            </h1>
            <p className="mt-5 max-w-md text-base leading-7 text-muted-foreground">
              Deine Spiele, aktuelle Turniere und alles, was deinen Verein bewegt. Schön, dass du da bist.
            </p>
            <div className="mt-7 flex flex-col gap-3 sm:flex-row">
              <Link href="/member-availability" className="inline-flex min-h-12 items-center justify-center gap-2.5 rounded-xl bg-primary px-5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90">
                <CalendarDays className="h-4 w-4" /> Meine Spiele <ArrowRight className="h-4 w-4" />
              </Link>
              <Link href="/turniere" className="inline-flex min-h-12 items-center justify-center gap-2.5 rounded-xl border border-border bg-secondary px-5 text-sm font-semibold text-foreground transition-colors hover:bg-accent">
                <Trophy className="h-4 w-4" /> Turniere entdecken
              </Link>
            </div>
          </div>
          <div className="relative hidden min-h-80 items-center justify-center border-l border-border bg-background p-10 lg:flex" aria-hidden="true">
            <div className="relative flex h-64 w-64 items-center justify-center rounded-full border border-border">
              <div className="absolute inset-7 rounded-full border-[12px] border-secondary" />
              <div className="absolute inset-14 rounded-full border border-border" />
              <div className="absolute inset-[5.25rem] rounded-full border-[10px] border-primary/30" />
              <div className="h-9 w-9 rounded-full bg-primary" />
              <span className="absolute -bottom-3 rounded-lg border border-border bg-card px-4 py-2 text-xs font-semibold tracking-[0.2em] text-muted-foreground">EMD · GEMEINSAM AM BOARD</span>
            </div>
          </div>
        </div>
        <div className="grid grid-cols-3 border-t border-border bg-background/50">
          {stats.map(({ label, value, icon: Icon, href }) => (
            <Link key={label} href={href} className="flex min-w-0 flex-col gap-2 border-r border-border p-4 last:border-r-0 transition-colors hover:bg-secondary sm:flex-row sm:items-center sm:gap-4 sm:px-8 sm:py-6">
              <Icon className="h-5 w-5 shrink-0 text-primary" />
              <div className="min-w-0">
                <div className="text-2xl font-semibold tabular-nums text-foreground sm:text-3xl">{value}</div>
                <div className="mt-1 text-xs text-muted-foreground sm:text-sm">{label}</div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
