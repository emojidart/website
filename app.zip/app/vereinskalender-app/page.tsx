"use client"

import { useState, useEffect } from "react"
import { Header } from "@/components/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  ArrowLeft,
  Calendar,
  ChevronLeft,
  ChevronRight,
  Filter,
  Target,
  Trophy,
  CalendarDays,
  Users,
  Star,
  MapPin,
  Clock,
  Home,
  Plane,
  RotateCcw,
  Cake,
  Plus,
  Sun,
} from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { supabase } from "@/lib/supabase"
import { useRouter } from "next/navigation"
import { format } from "date-fns"
import { MobileBottomNav } from "@/components/mobile-bottom-nav"

interface Match {
  type?: string
  id: string
  season_id: string
  home_team_id: string
  away_team_id: string
  match_date: string
  match_time: string
  venue: string
  home_score: number | null
  away_score: number | null
  status: string
  week_number: number
  match_format?: "team" | "individual" | "best_of_three"
  division_type?: "team_division" | "individual_division"
  home_team: {
    id: string
    name: string
    logo_url?: string
  } | null
  away_team: {
    id: string
    name: string
    logo_url?: string
  } | null
  home_opponent_team: any | null
  away_opponent_team: any | null
  home_team_type: string
  away_team_type: string
  season: {
    id: string
    name: string
    type: string
  } | null
}

interface Event {
  vacation_user_id?: string | null
  type?: string // "event" | "dko" | "birthday" | "vacation" | "holiday" | "board"
  id: string
  name: string
  event_date: string
  event_type: string
  description?: string
  start_time?: string

  location?: string | null
  entry_fee?: number | null
  max_participants?: number | null
  details?: string | null
  photo_url?: string | null

  vacation_id?: string
  start_date?: string
  end_date?: string
  note?: string | null
}

type CalendarItem = Match | Event

interface BirthdayPlayer {
  id: string
  name: string
  birthdate: string
}

interface Vacation {
  id: string
  user_id?: string | null
  user_name: string
  player_name?: string | null
  start_date: string
  end_date: string
  note?: string | null
  created_at?: string
}

interface PrivateCalendarEntry {
  id: string
  user_id: string
  title: string
  start_date: string
  end_date: string
  start_time?: string | null
  note?: string | null
  created_at?: string
}


const DKO_TIMEZONE = "Europe/Berlin"


function toDateAndTimeInTZ(iso: string, timeZone: string = DKO_TIMEZONE) {
  const d = new Date(iso)
  const dateParts = new Intl.DateTimeFormat("en-CA", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(d) // YYYY-MM-DD

  const timeParts = new Intl.DateTimeFormat("de-DE", {
    timeZone,
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).format(d) // HH:MM

  return { event_date: dateParts, start_time: timeParts }
}

function sanitizeVacationNote(note?: string | null) {
  if (!note) return ""
 
  const cleaned = note
    .replace(/🎂/g, "")
    .replace(/\bgeburtstag\b/gi, "")
    .replace(/\s{2,}/g, " ")
    .trim()
  return cleaned
}


export default function CalendarPage() {
  const router = useRouter()

  const [currentDate, setCurrentDate] = useState(new Date())
  const [selectedMatch, setSelectedMatch] = useState<Match | null>(null)
  const [currentUserId, setCurrentUserId] = useState<string | null>(null)
  const [lineupPlayers, setLineupPlayers] = useState<any[]>([])
const [isLineupDialogOpen, setIsLineupDialogOpen] = useState(false)
const [loadingLineup, setLoadingLineup] = useState(false)



 
  useEffect(() => {
    let isMounted = true
    supabase.auth.getUser().then(({ data }) => {
      if (!isMounted) return
      setCurrentUserId(data.user?.id ?? null)
    })
    return () => {
      isMounted = false
    }
  }, [])

  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null)
  const [boardAttachments, setBoardAttachments] = useState<
  { id: string; file_name: string; file_path: string; mime_type: string | null; url: string | null }[]
>([])
const [loadingBoardAttachments, setLoadingBoardAttachments] = useState(false)
  const [isMatchDialogOpen, setIsMatchDialogOpen] = useState(false)
  const [isEventDialogOpen, setIsEventDialogOpen] = useState(false)
  const [selectedLeague, setSelectedLeague] = useState("Alle Ligen")
  const [selectedTeam, setSelectedTeam] = useState("Alle Teams")
  const [selectedItemType, setSelectedItemType] = useState("Alle")
  const [viewMode, setViewMode] = useState<"month" | "list" | "browse">("month")
  const [matches, setMatches] = useState<Match[]>([])
  const [events, setEvents] = useState<Event[]>([])
  const [holidayEvents, setHolidayEvents] = useState<Event[]>([])
  const [loading, setLoading] = useState(true)
  const [leagues, setLeagues] = useState<string[]>(["Alle Ligen"])
  const [teams, setTeams] = useState<string[]>(["Alle Teams"])
  const [clubTeams, setClubTeams] = useState<ClubTeam[]>([])
  const [selectedDate, setSelectedDate] = useState<Date | null>(null)
  const [isMultiItemDialogOpen, setIsMultiItemDialogOpen] = useState(false)
  const [isMobileBottomSheetOpen, setIsMobileBottomSheetOpen] = useState(false)
  const [mobileSelectedDate, setMobileSelectedDate] = useState<Date | null>(null)
  const [selectedPlayer, setSelectedPlayer] = useState<string | null>(null)
  const [players, setPlayers] = useState<{ id: string; name: string }[]>([{ id: "0", name: "Alle Spieler" }])
  const [selectedResultType, setSelectedResultType] = useState("Alle")

  const [browseTeamQuery, setBrowseTeamQuery] = useState("")

  const [birthdayPlayers, setBirthdayPlayers] = useState<BirthdayPlayer[]>([])

  const [vacations, setVacations] = useState<Vacation[]>([])
  const [isVacationDialogOpen, setIsVacationDialogOpen] = useState(false)
  const [privateEntries, setPrivateEntries] = useState<PrivateCalendarEntry[]>([])
const [isPrivateDialogOpen, setIsPrivateDialogOpen] = useState(false)
const [privateTitle, setPrivateTitle] = useState("")
const [privateStart, setPrivateStart] = useState("")
const [privateEnd, setPrivateEnd] = useState("")
const [privateTime, setPrivateTime] = useState("")
const [privateNote, setPrivateNote] = useState("")
const [savingPrivateEntry, setSavingPrivateEntry] = useState(false)
const [editingPrivateEntryId, setEditingPrivateEntryId] = useState<string | null>(null)
const [confirmDeletePrivateEntryId, setConfirmDeletePrivateEntryId] = useState<string | null>(null)
const [isConfirmDeletePrivateOpen, setIsConfirmDeletePrivateOpen] = useState(false)
  const [isBoardDialogOpen, setIsBoardDialogOpen] = useState(false)
const [isVorstand, setIsVorstand] = useState(false)

const [boardTitle, setBoardTitle] = useState("")
const [boardDesc, setBoardDesc] = useState("")
const [boardDate, setBoardDate] = useState("")   // YYYY-MM-DD
const [boardTime, setBoardTime] = useState("")   // HH:MM
const [boardFiles, setBoardFiles] = useState<FileList | null>(null)
const [editingBoardId, setEditingBoardId] = useState<string | null>(null)
const [allClubPlayers, setAllClubPlayers] = useState<{ id: string; name: string }[]>([])
const [invitePlayerIds, setInvitePlayerIds] = useState<string[]>([])
const [inviteSearch, setInviteSearch] = useState("")

const [savingBoard, setSavingBoard] = useState(false)
  const [vacationName, setVacationName] = useState("")
  const [vacationStart, setVacationStart] = useState("")
  const [vacationEnd, setVacationEnd] = useState("")
  const [vacationNote, setVacationNote] = useState("")
  const [savingVacation, setSavingVacation] = useState(false)
  const [editingVacationId, setEditingVacationId] = useState<string | null>(null)
  const [isConfirmDeleteOpen, setIsConfirmDeleteOpen] = useState(false)
  const [confirmDeleteVacationId, setConfirmDeleteVacationId] = useState<string | null>(null)
  const [isConfirmDeleteBoardOpen, setIsConfirmDeleteBoardOpen] = useState(false)
const [confirmDeleteBoardId, setConfirmDeleteBoardId] = useState<string | null>(null)
  
  const fetchAustrianHolidays = async (year: number): Promise<Event[]> => {
  try {
    const res = await fetch(`https://date.nager.at/api/v3/PublicHolidays/${year}/AT`)
    if (!res.ok) return []

    const rows = (await res.json()) as any[]
    return (rows || []).map((h) => ({
      type: "holiday",
      id: `holiday-${year}-${h.date}-${h.localName}`,
      name: `🇦🇹 Feiertag: ${h.localName}`,
      event_date: h.date, // YYYY-MM-DD
      event_type: "Feiertag",
      description: h.name || h.localName,
      start_time: "00:00:00",
    })) as Event[]
  } catch (e) {
    console.error("Failed to fetch AT holidays:", e)
    return []
  }
}

  const fetchData = async () => {
    try {
      setLoading(true)

      
      const { data: authData } = await supabase.auth.getUser()
	  
	  // ✅ Spieler-Liste für Einladungen laden
try {
  const playersRes = await supabase
    .from("club_players")
    .select("id, name")
    .order("name", { ascending: true })

  if (!playersRes.error) {
    setAllClubPlayers((playersRes.data || []) as any)
  } else {
    console.error("Error loading club_players:", playersRes.error)
    setAllClubPlayers([])
  }
} catch (e) {
  console.error("club_players fetch failed:", e)
  setAllClubPlayers([])
}


	  if (authData?.user?.id) {
  const { data: roleRows } = await supabase
    .from("club_roles")
    .select("role")
    .eq("user_id", authData.user.id)

  const ok = (roleRows || []).some((r: any) => r.role === "Vorstand")
  setIsVorstand(ok)
} else {
  setIsVorstand(false)
}
      const uid = authData?.user?.id
      if (uid) {
        const { data: clubTeamsData, error: clubTeamsError } = await supabase
          .from("teams")
          .select("id, name, logo_url")
          .eq("user_id", uid)
          .order("name", { ascending: true })

        if (clubTeamsError) {
          console.error("Error fetching club teams:", clubTeamsError)
          setClubTeams([])
          setTeams(["Alle Teams"])
        } else {
          const ct = (clubTeamsData || []) as ClubTeam[]
          setClubTeams(ct)
          setTeams(["Alle Teams", ...ct.map((t) => t.name)])
        }
      } else {
        setClubTeams([])
        setTeams(["Alle Teams"])
      }

      const matchesResponse = await supabase
        .from("matches")
        .select(`*,
          home_team:teams!matches_home_team_id_fkey(id, name, logo_url),
          away_team:teams!matches_away_team_id_fkey(id, name, logo_url),
          home_opponent_team:opponent_teams!matches_home_opponent_team_id_fkey(id, name),
          away_opponent_team:opponent_teams!matches_away_opponent_team_id_fkey(id, name),
          season:seasons(id, name, type)
        `)
        .order("match_date", { ascending: true })

      if (matchesResponse.error) {
        console.error("Error fetching matches:", matchesResponse.error)
        return
      }

      let enrichedEvents: any[] = []
      try {
        const eventsResponse = await supabase.from("events").select("*").order("event_date", { ascending: true })

        if (eventsResponse.error) {
          console.error("Error fetching events:", eventsResponse.error)
        } else {
          const rows = (eventsResponse.data || []) as any[]
          enrichedEvents = rows.map((r) => ({
  type: "event",
  id: `event_${r.id}`,
  name: r.name || "Event",
  event_date: r.start_date || r.event_date,
  start_date: r.start_date || r.event_date,
  end_date: r.end_date || r.event_date,
  event_type: r.event_type || "Event",
  start_time: (r.event_time || "").toString().substring(0, 5) || undefined,
  description: r.details || undefined,
  details: r.details ?? null,
  location: r.location ?? null,
  entry_fee: r.entry_fee ?? null,
  max_participants: r.max_participants ?? null,
  photo_url: r.photo_url ?? null,
})) as Event[]
        }
      } catch (eventError) {
        console.error("Events table might not exist or no permissions:", eventError)
      }



try {
  const tournamentsResponse = await supabase
    .from("dko_series_events")
    .select(
      `id, title, start_at, location, is_matchday, series_id,
       series:dko_series (id, name, slug, startgeld)`
    )
    .order("start_at", { ascending: true })

  if (tournamentsResponse.error) {
    console.error("Error fetching dko series events:", tournamentsResponse.error)
  } else {
    const tournamentRows = (tournamentsResponse.data || []) as any[]
    const tournamentEvents: Event[] = tournamentRows
      .filter((r) => r?.start_at && r?.series)
      .map((r) => {
        const { event_date, start_time } = toDateAndTimeInTZ(r.start_at)

        const seriesName = r.series?.name || "Turnier"
        const titlePart = r.title ? ` – ${r.title}` : ""
        const dayLabel = r.is_matchday ? "Spieltag" : "Spielfrei"
        const startgeld = r.series?.startgeld != null ? `${r.series.startgeld} € Startgeld` : null
        const location = r.location || null

        const details = [dayLabel, startgeld, location].filter(Boolean).join(" • ")

        return {
          type: "dko",
          id: `dko_${r.id}`,
          name: `${seriesName}${titlePart}`,
          event_date,
          event_type: "Turnier",
          start_time,
          description: details || undefined,
        }
      })

    
    enrichedEvents = [...enrichedEvents, ...tournamentEvents]
  }
} catch (tournamentError) {
  console.error("dko_series_events table might not exist or no permissions:", tournamentError)
}

      const enrichedMatches = matchesResponse.data || []

      setMatches(enrichedMatches)
	  const boardRes = await supabase
  .from("board_events")
  .select("id, title, description, starts_at")
  .order("starts_at", { ascending: true })

if (!boardRes.error) {
  const boardRows = (boardRes.data || []) as any[]
  const boardEvents: Event[] = boardRows.map((r) => {
    const { event_date, start_time } = toDateAndTimeInTZ(r.starts_at)
    return {
      type: "board",
      id: `board_${r.id}`,
      name: `📌 Vorstand: ${r.title}`,
      event_date,
      event_type: "Vorstand",
      start_time,
      description: r.description || undefined,
    } as Event
  })

  enrichedEvents = [...enrichedEvents, ...boardEvents]
}
      setEvents(enrichedEvents as Event[])

      
      let fetchedBirthdayPlayers: BirthdayPlayer[] = []
      try {
        const playersResponse = await supabase
          .from("club_players")
          .select("id, name, birthdate")
          .not("birthdate", "is", null)

        if (playersResponse.error) {
          console.error("Error fetching player birthdays:", playersResponse.error)
        } else {
          const rows = (playersResponse.data || []) as any[]
          fetchedBirthdayPlayers = rows
            .filter((r) => r?.birthdate)
            .map((r) => ({
              id: r.id,
              name: r.name || `Spieler ${String(r.id).slice(0, 6)}`,
              birthdate: r.birthdate,
            }))
        }
      } catch (birthdayError) {
        console.error("club_players table might not exist or no permissions:", birthdayError)
      }

      setBirthdayPlayers(fetchedBirthdayPlayers)

      
      let fetchedVacations: Vacation[] = []
      try {
        const vacationResponse = await supabase
          .from("vacations")
          .select("id, user_id, user_name, start_date, end_date, note, created_at")
          .order("start_date", { ascending: true })

        if (vacationResponse.error) {
          console.error("Error fetching vacations:", vacationResponse.error)
        } else {
          fetchedVacations = (vacationResponse.data || []) as Vacation[]

          // Enrich with player name via user_profiles -> club_players
          const userIds = Array.from(
            new Set(
              fetchedVacations
                .map((v) => v.user_id)
                .filter((x): x is string => typeof x === "string" && x.length > 0),
            ),
          )

          if (userIds.length) {
            const { data: profiles, error: profErr } = await supabase
              .from("user_profiles")
              .select("user_id, player_id")
              .in("user_id", userIds)

            if (!profErr && profiles?.length) {
              const playerIds = Array.from(
                new Set(
                  (profiles as any[])
                    .map((p) => p.player_id)
                    .filter((x): x is string => typeof x === "string" && x.length > 0),
                ),
              )

              let playerNameById = new Map<string, string>()
              if (playerIds.length) {
                const { data: playersRows, error: playersErr } = await supabase
                  .from("club_players")
                  .select("id, name")
                  .in("id", playerIds)

                if (!playersErr && playersRows?.length) {
                  playerNameById = new Map((playersRows as any[]).map((r) => [r.id, r.name]))
                }
              }

              const playerIdByUserId = new Map((profiles as any[]).map((p) => [p.user_id, p.player_id]))
              fetchedVacations = fetchedVacations.map((v) => {
                const pid = v.user_id ? playerIdByUserId.get(v.user_id) : null
                const pname = pid ? playerNameById.get(pid) : null
                return { ...v, player_name: pname ?? null }
              })
            }
          }
        }
      } catch (vacErr) {
        console.error("vacations table might not exist or no permissions:", vacErr)
      }

      setVacations(fetchedVacations)
	  
	        let fetchedPrivateEntries: PrivateCalendarEntry[] = []
      try {
        if (uid) {
          const privateResponse = await supabase
            .from("calendar_private_entries")
            .select("id, user_id, title, start_date, end_date, start_time, note, created_at")
            .order("start_date", { ascending: true })

          if (privateResponse.error) {
            console.error("Error fetching private calendar entries:", privateResponse.error)
          } else {
            fetchedPrivateEntries = (privateResponse.data || []) as PrivateCalendarEntry[]
          }
        }
      } catch (privateErr) {
        console.error("calendar_private_entries fetch failed:", privateErr)
      }

      setPrivateEntries(fetchedPrivateEntries)


      const uniqueLeagues = new Set<string>(["Alle Ligen"])
      enrichedMatches.forEach((match) => {
        if (match.season?.name) {
          uniqueLeagues.add(match.season.name)
        }
      })

      setLeagues(Array.from(uniqueLeagues))
    } catch (err) {
      console.error("Error fetching data:", err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchData()
  }, [])
  
  useEffect(() => {
  const y = currentDate.getFullYear()
  fetchAustrianHolidays(y).then(setHolidayEvents)
}, [currentDate])

    useEffect(() => {
    const prefillVacationName = async () => {
      try {
        const { data } = await supabase.auth.getUser()
        const authUserId = data?.user?.id
        if (!authUserId) return

        // auth user -> user_profiles.user_id -> player_id -> club_players.id -> name
        const { data: profileRow, error: profileErr } = await supabase
          .from("user_profiles")
          .select("player_id")
          .eq("user_id", authUserId)
          .maybeSingle()

        if (profileErr) return
        const playerId = profileRow?.player_id
        if (!playerId) return

        const { data: playerRow, error: playerErr } = await supabase
          .from("club_players")
          .select("name")
          .eq("id", playerId)
          .maybeSingle()

        if (playerErr) return
        if (playerRow?.name) {
          setVacationName(playerRow.name)
        }
      } catch (e) {
        // ignore
      }
    }

    prefillVacationName()
  }, [])

  const filteredMatches = matches.filter((match) => {
    if (selectedItemType === "Geburtstage" || selectedItemType === "Urlaube") return false

    const leagueMatch = selectedLeague === "Alle Ligen" || match.season?.name === selectedLeague
    const teamMatch =
      selectedTeam === "Alle Teams" ||
      match.home_team?.name === selectedTeam ||
      match.away_team?.name === selectedTeam ||
      match.home_opponent_team?.name === selectedTeam ||
      match.away_opponent_team?.name === selectedTeam

   
    let resultTypeMatch = true
    const shouldFilterByResultType =
      selectedResultType !== "Alle" &&
      selectedItemType !== "Events" &&
      selectedItemType !== "Turniere" &&
      selectedItemType !== "Geburtstage" &&
      selectedItemType !== "Urlaube"

    if (shouldFilterByResultType) {
      if (selectedResultType === "Gespielt") {
        resultTypeMatch = match.status === "completed" || match.status === "finished"
      } else if (selectedResultType === "Geplant") {
        resultTypeMatch = match.status === "scheduled"
      }
    }

    return leagueMatch && teamMatch && resultTypeMatch
  })

 const allEvents = [...events, ...holidayEvents]

const filteredEvents = allEvents.filter((event) => {
    // ✅ Team-Filter gilt nur für Spiele
    if (selectedTeam !== "Alle Teams") return false
    if (selectedItemType === "Geburtstage" || selectedItemType === "Urlaube") return false
    if (selectedItemType === "Spiele") return false

    
    if (selectedItemType === "Events") return event.type === "event" || event.type === "board"
    if (selectedItemType === "Turniere") return event.type === "dko"
	if (selectedItemType === "Feiertage") return event.type === "holiday"

   
    return true
  })

  
  const isBirthdayOnDate = (birthdate: string, date: Date) => {
    const parts = (birthdate || "").split("-")
    const m = Number(parts[1]) // 1-12
    const d = Number(parts[2]) // 1-31
    return m === date.getMonth() + 1 && d === date.getDate()
  }

  const isDateInRange = (dateStr: string, startStr: string, endStr: string) => {
    return dateStr >= startStr && dateStr <= endStr
  }

  const getItemsForDate = (date: Date) => {
    const year = date.getFullYear()
    const month = String(date.getMonth() + 1).padStart(2, "0")
    const day = String(date.getDate()).padStart(2, "0")
    const dateStr = `${year}-${month}-${day}`

    
    if (selectedTeam !== "Alle Teams") {
      return filteredMatches.filter((match) => match.match_date === dateStr)
    }

    const matchesForDate =
      selectedItemType !== "Events" && selectedItemType !== "Turniere" && selectedItemType !== "Geburtstage" && selectedItemType !== "Urlaube"
        ? filteredMatches.filter((match) => match.match_date === dateStr)
        : []

    const eventsForDate =
  selectedItemType !== "Spiele" && selectedItemType !== "Geburtstage" && selectedItemType !== "Urlaube"
    ? filteredEvents.filter((event) => {
        const start = event.start_date || event.event_date
        const end = event.end_date || event.event_date
        return isDateInRange(dateStr, start, end)
      })
    : []

    const birthdaysForDate =
      selectedItemType !== "Spiele" && selectedItemType !== "Turniere" && selectedItemType !== "Events" && selectedItemType !== "Urlaube"
        ? birthdayPlayers
            .filter((p) => isBirthdayOnDate(p.birthdate, date))
            .map((p) => {
              return {
                id: `birthday-${p.id}-${dateStr}`,
                name: `🎂 Geburtstag: ${p.name}`,
                event_date: dateStr,
                event_type: "Geburtstag",
                description: `${p.name} hat Geburtstag.`,
                start_time: "00:00:00",
                type: "birthday",
              } as Event
            })
        : []

    const vacationsForDate =
      selectedItemType !== "Spiele" && selectedItemType !== "Turniere" && selectedItemType !== "Geburtstage"
        ? vacations
            .filter((v) => isDateInRange(dateStr, v.start_date, v.end_date))
            .map((v) => {
              const cleanedNote = sanitizeVacationNote(v.note)
              return {
                id: `vacation-${v.id}-${dateStr}`,
                vacation_id: v.id,
                start_date: v.start_date,
                end_date: v.end_date,
                note: cleanedNote || null,
                name: `🏖️ Urlaub: ${v.player_name || v.user_name}`,
                event_date: dateStr,
                event_type: "Urlaub",
                description: cleanedNote || undefined,
                start_time: "00:00:00",
                type: "vacation",
              } as Event
            })
        : []
		
		
		    const privateEntriesForDate =
      selectedItemType !== "Spiele" && selectedItemType !== "Turniere" && selectedItemType !== "Geburtstage"
        ? privateEntries
            .filter((p) => isDateInRange(dateStr, p.start_date, p.end_date))
            .map((p) => {
              return {
                id: `private-${p.id}-${dateStr}`,
                vacation_id: p.id,
                vacation_user_id: p.user_id,
                start_date: p.start_date,
                end_date: p.end_date,
                note: p.note || null,
                name: `🔒 Privat: ${p.title}`,
                event_date: dateStr,
                event_type: "Privat",
                description: p.note || undefined,
                start_time: p.start_time || undefined,
                type: "private",
              } as Event
            })
        : []
		
		

       return [...matchesForDate, ...eventsForDate, ...birthdaysForDate, ...vacationsForDate, ...privateEntriesForDate]
  }

  const getDaysInMonth = (date: Date) => {
  const year = date.getFullYear()
  const month = date.getMonth()
  const firstDay = new Date(year, month, 1)
  const lastDay = new Date(year, month + 1, 0)
  const daysInMonth = lastDay.getDate()

  // Sonntag=0, Montag=1, ...
  // Wir wollen Montag als ersten Tag.
  const jsDay = firstDay.getDay()
  const startingDayOfWeek = jsDay === 0 ? 6 : jsDay - 1

  const days = []

  for (let i = 0; i < startingDayOfWeek; i++) {
    days.push(null)
  }

  for (let day = 1; day <= daysInMonth; day++) {
    days.push(new Date(year, month, day))
  }

  return days
}

  const navigateMonth = (direction: "prev" | "next") => {
    setCurrentDate((prev) => {
      const newDate = new Date(prev)
      if (direction === "prev") {
        newDate.setMonth(prev.getMonth() - 1)
      } else {
        newDate.setMonth(prev.getMonth() + 1)
      }
      return newDate
    })
  }

  const openMatchDialog = (match: Match) => {
  setSelectedMatch(match)
  setLineupPlayers([])
  setIsMatchDialogOpen(true)
}

  
const loadLineup = async (matchId: string) => {
  setLoadingLineup(true)
  setLineupPlayers([])

  const { data, error } = await supabase
    .from("match_lineups")
    .select(`
      id,
      position,
      is_substitute,
      team_id,
      player_id,
      club_players:player_id (
        id,
        name
      )
    `)
    .eq("match_id", matchId)
    .order("team_id", { ascending: true })
    .order("position", { ascending: true })

  if (error) {
    console.error("Error loading lineup:", error)
    setLoadingLineup(false)
    return
  }

  setLineupPlayers(data || [])
  setLoadingLineup(false)
}



  const openEventDialog = async (event: Event) => {
  setSelectedEvent(event)
  setIsEventDialogOpen(true)
  
    if (event.type === "private") {
    setIsEventDialogOpen(false)

    const entry = privateEntries.find((p) => event.id.includes(p.id))
    if (!entry) return

setEditingPrivateEntryId(entry.id)
setPrivateTitle(entry.title)
setPrivateStart(entry.start_date)
setPrivateEnd(entry.end_date)
setPrivateTime(normalizeTimeHHMM(entry.start_time || ""))
setPrivateNote(entry.note || "")
setIsPrivateDialogOpen(true)
    return
  }
  
  boardAttachments.forEach((a) => {
  if (a.url?.startsWith("blob:")) URL.revokeObjectURL(a.url)
})

  
  setBoardAttachments([])
  setLoadingBoardAttachments(false)


  if (event.type !== "board") return

 
  const boardId = (event.id || "").replace("board_", "").trim()
  if (!boardId) return

  setLoadingBoardAttachments(true)

  const { data: files, error } = await supabase
    .from("board_event_files")
    .select("id, file_name, file_path, mime_type")
    .eq("event_id", boardId)
    .order("created_at", { ascending: true })

  if (error) {
    console.error("load board_event_files error:", error)
    setLoadingBoardAttachments(false)
    return
  }

  const rows = (files || []) as any[]

  const withUrls = await Promise.all(
  rows.map(async (f) => {
    
    const { data: blob, error: dlErr } = await supabase.storage
      .from("vorstand-uploads")
      .download(f.file_path)

    if (dlErr || !blob) {
      console.log("DOWNLOAD ERR:", dlErr, "PATH:", f.file_path)
      return {
        id: f.id,
        file_name: f.file_name,
        file_path: f.file_path,
        mime_type: f.mime_type ?? null,
        url: null,
      }
    }

    const objectUrl = URL.createObjectURL(blob)
    console.log("BLOB URL:", objectUrl, "FILE:", f.file_name)

    return {
      id: f.id,
      file_name: f.file_name,
      file_path: f.file_path,
      mime_type: f.mime_type ?? null,
      url: objectUrl,
    }
  })
)

  setBoardAttachments(withUrls)
  setLoadingBoardAttachments(false)
}

  const createVacation = async () => {
    if (!vacationName.trim() || !vacationStart || !vacationEnd) return
    setSavingVacation(true)
    try {
      if (editingVacationId) {
        const { error } = await supabase
          .from("vacations")
          .update({
            user_name: vacationName.trim(),
            start_date: vacationStart,
            end_date: vacationEnd,
            note: vacationNote.trim() ? vacationNote.trim() : null,
          })
          .eq("id", editingVacationId)

        if (error) {
          console.error("Error updating vacation:", error)
          return
        }
      } else {
        const { data: authData } = await supabase.auth.getUser()
        const uid = authData?.user?.id
        const { error } = await supabase.from("vacations").insert({
          user_id: uid ?? null,
          user_name: vacationName.trim(),
          start_date: vacationStart,
          end_date: vacationEnd,
          note: vacationNote.trim() ? vacationNote.trim() : null,
        })

        if (error) {
          console.error("Error creating vacation:", error)
          return
        }
      }

      setIsVacationDialogOpen(false)
      setEditingVacationId(null)
      await fetchData()
    } catch (e) {
      console.error("createVacation failed:", e)
    } finally {
      setSavingVacation(false)
    }
  }
  
  
    const createPrivateEntry = async () => {
    if (!privateTitle.trim() || !privateStart || !privateEnd) return

    setSavingPrivateEntry(true)

    try {
      const { data: authData } = await supabase.auth.getUser()
      const uid = authData?.user?.id

      if (!uid) {
        console.error("No authenticated user found")
        return
      }

      if (editingPrivateEntryId) {
        const { error } = await supabase
          .from("calendar_private_entries")
         .update({
  title: privateTitle.trim(),
  start_date: privateStart,
  end_date: privateEnd,
  start_time: privateTime ? `${privateTime}:00` : null,
  note: privateNote.trim() ? privateNote.trim() : null,
})
          .eq("id", editingPrivateEntryId)

        if (error) {
          console.error("Error updating private entry:", error)
          return
        }
      } else {
        const { error } = await supabase
          .from("calendar_private_entries")
          .insert({
  user_id: uid,
  title: privateTitle.trim(),
  start_date: privateStart,
  end_date: privateEnd,
  start_time: privateTime ? `${privateTime}:00` : null,
  note: privateNote.trim() ? privateNote.trim() : null,
})

        if (error) {
          console.error("Error creating private entry:", error)
          return
        }
      }

   setIsPrivateDialogOpen(false)
setEditingPrivateEntryId(null)
setPrivateTitle("")
setPrivateStart("")
setPrivateEnd("")
setPrivateTime("")
setPrivateNote("")
await fetchData()
      await fetchData()
    } catch (e) {
      console.error("createPrivateEntry failed:", e)
    } finally {
      setSavingPrivateEntry(false)
    }
  }
  


const createBoardEvent = async () => {
  if (!boardTitle.trim() || !boardDate || !boardTime) return
  setSavingBoard(true)

  try {
    const startsAtIso = new Date(`${boardDate}T${boardTime}:00`).toISOString()

    // ✅ eventId 
    let eventId: string | null = editingBoardId

    // ✅ UPDATE (bearbeiten)
    if (editingBoardId) {
      const { error: updateErr } = await supabase
        .from("board_events")
        .update({
          title: boardTitle.trim(),
          description: boardDesc.trim() ? boardDesc.trim() : null,
          starts_at: startsAtIso,
        })
        .eq("id", editingBoardId)

      if (updateErr) {
        console.error("board_events update error:", updateErr)
        return
      }
    }

    // ✅ INSERT 
    if (!editingBoardId) {
      const { data: ev, error: evErr } = await supabase
        .from("board_events")
        .insert({
          title: boardTitle.trim(),
          description: boardDesc.trim() ? boardDesc.trim() : null,
          starts_at: startsAtIso,
        })
        .select("id")
        .single()

      if (evErr || !ev?.id) {
        console.error("board_events insert error:", evErr)
        return
      }

      
      eventId = ev.id
    }

    // ✅ wenn eventId aus irgendeinem Grund fehlt -> stop
    if (!eventId) return
	
	
	
	// ✅ Push an alle eingeladenen senden
try {
  const { data: sessionData } = await supabase.auth.getSession()
  const accessToken = sessionData?.session?.access_token

  if (accessToken) {
    await fetch("/api/push/board-invite", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({ event_id: eventId }),
    })
  }
} catch (e) {
  console.error("board invite push failed:", e)
}
	
	
	

    // ✅ Einladungen speichern 
    if (invitePlayerIds.length > 0) {
      const { data: authData } = await supabase.auth.getUser()
      const inviter = authData?.user?.id ?? null

      const rows = invitePlayerIds.map((pid) => ({
        event_id: eventId!,
        player_id: pid,
        invited_by: inviter,
      }))

      const ins = await supabase
        .from("board_event_invites")
        .upsert(rows, { onConflict: "event_id,player_id" })

      if (ins.error) console.error("Error saving invites:", ins.error)
    }

    // ✅ Dialog reset + reload
    setIsBoardDialogOpen(false)
    setEditingBoardId(null)
    setBoardTitle("")
    setBoardDesc("")
    setBoardDate("")
    setBoardTime("")
    setBoardFiles(null)
    setInvitePlayerIds([])
    setInviteSearch("")

    await fetchData()
  } finally {
    setSavingBoard(false)
  }
}








  

  const deleteVacation = async (vacationId: string) => {
    if (!vacationId) return
    setSavingVacation(true)
    try {
      const { error } = await supabase.from("vacations").delete().eq("id", vacationId)
      if (error) {
        console.error("Error deleting vacation:", error)
        return
      }
      setIsEventDialogOpen(false)
      setIsVacationDialogOpen(false)
      setEditingVacationId(null)
      await fetchData()
    } catch (e) {
      console.error("deleteVacation failed:", e)
    } finally {
      setSavingVacation(false)
    }
  }
  
  
    const deletePrivateEntry = async (entryId: string) => {
    if (!entryId) return

    setSavingPrivateEntry(true)

    try {
      const { error } = await supabase
        .from("calendar_private_entries")
        .delete()
        .eq("id", entryId)

      if (error) {
        console.error("Error deleting private entry:", error)
        return
      }

      setIsEventDialogOpen(false)
      setIsPrivateDialogOpen(false)
      setEditingPrivateEntryId(null)
      setConfirmDeletePrivateEntryId(null)
      await fetchData()
    } catch (e) {
      console.error("deletePrivateEntry failed:", e)
    } finally {
      setSavingPrivateEntry(false)
    }
  }
  
  

  const handleItemClick = (item: CalendarItem) => {
    if ("match_date" in item) {
      openMatchDialog(item as Match)
    } else {
      openEventDialog(item as Event)
    }
  }

  const openMultiItemDialogDialog = (date: Date, items: CalendarItem[]) => {
    setSelectedDate(date)
    setIsMultiItemDialogOpen(true)
  }

  const getStatusBadge = (status: string) => {
    if (status === "completed" || status === "finished") {
      return <Badge className="bg-emerald-500/[0.10] text-emerald-200 border-emerald-300/[0.16] text-xs">Beendet</Badge>
    } else if (status === "live" || status === "in_progress") {
      return <Badge className="bg-red-500/[0.10] text-red-200 border-red-300/[0.16] animate-pulse text-xs">Live</Badge>
    } else {
      return <Badge className="bg-sky-500/[0.10] text-sky-200 border-sky-300/[0.16] text-xs">Anstehend</Badge>
    }
  }

  const isHomeGame = (match: Match, teamName?: string) => {
    return match.home_team_type === "own"
  }

  const monthNames = [
    "Januar",
    "Februar",
    "März",
    "April",
    "Mai",
    "Juni",
    "Juli",
    "August",
    "September",
    "Oktober",
    "November",
    "Dezember",
  ]

  const dayNames = ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"]

  const todayBirthdays = (() => {
    const today = new Date()
    return birthdayPlayers.filter((p) => isBirthdayOnDate(p.birthdate, today))
  })()

  const today = new Date()
  const todayStr = (() => {
    const y = today.getFullYear()
    const m = String(today.getMonth() + 1).padStart(2, "0")
    const d = String(today.getDate()).padStart(2, "0")
    return `${y}-${m}-${d}`
  })()

  const todayMatches = matches.filter((match) => match.match_date === todayStr)
const todayEvents = events.filter((event) => {
  const start = event.start_date || event.event_date
  const end = event.end_date || event.event_date
  return isDateInRange(todayStr, start, end)
})
  const todayBirthdayEvents: Event[] = birthdayPlayers
    .filter((p) => isBirthdayOnDate(p.birthdate, today))
    .map((p) => ({
      id: `today-birthday-${p.id}-${todayStr}`,
      name: `🎂 Geburtstag: ${p.name}`,
      event_date: todayStr,
      event_type: "Geburtstag",
      description: `${p.name} hat Geburtstag.`,
      start_time: "00:00:00",
      type: "birthday",
    }))

  const todayVacations: Event[] = vacations
    .filter((v) => isDateInRange(todayStr, v.start_date, v.end_date))
    .map((v) => ({
      id: `today-vacation-${v.id}-${todayStr}`,
      vacation_id: v.id,
      vacation_user_id: (v as any).user_id ?? null,
      start_date: v.start_date,
      end_date: v.end_date,
      note: v.note,
      name: `🏖️ Urlaub: ${v.player_name || v.user_name}`,
      event_date: todayStr,
      event_type: "Urlaub",
      description: v.note || undefined,
      start_time: "00:00:00",
      type: "vacation",
    }))
	
	
	
	  const todayPrivateEntries: Event[] = privateEntries
    .filter((p) => isDateInRange(todayStr, p.start_date, p.end_date))
    .map((p) => ({
      id: `today-private-${p.id}-${todayStr}`,
      vacation_id: p.id,
      vacation_user_id: p.user_id,
      start_date: p.start_date,
      end_date: p.end_date,
      note: p.note,
      name: `🔒 Privat: ${p.title}`,
      event_date: todayStr,
      event_type: "Privat",
      description: p.note || undefined,
     start_time: p.start_time || undefined,
      type: "private",
    }))
	
	

    const todayHighlights: CalendarItem[] = [...todayMatches, ...todayEvents, ...todayBirthdayEvents, ...todayVacations, ...todayPrivateEntries]
  
  
  

  const getTeamDisplayName = (match: Match, isHome: boolean) => {
    if (isHome) {
      if (match.home_team_type === "own") {
        return match.home_team?.name || "Heimteam"
      } else {
        return match.home_opponent_team?.name || "Heimteam"
      }
    } else {
      if (match.away_team_type === "own") {
        return match.away_team?.name || "Auswärtsteam"
      } else {
        return match.away_opponent_team?.name || "Auswärtsteam"
      }
    }
  }

  const getTeamLogo = (match: Match, isHome: boolean) => {
    if (isHome) {
      return match.home_team_type === "own" ? match.home_team?.logo_url : null
    } else {
      return match.away_team_type === "own" ? match.away_team?.logo_url : null
    }
  }

  const isEvent = (item: CalendarItem): item is Event => {
    return "event_date" in item
  }



function getEventTypeBadge(eventType: string) {
  if (eventType === "Vorstand") {
    return <Badge className="bg-black text-white border-black text-xs">📌 Vorstand</Badge>
  } else if (eventType === "Geburtstag") {
    return <Badge className="bg-pink-500/[0.10] text-pink-200 border-pink-300/[0.16] text-xs">🎂 Geburtstag</Badge>
  } else if (eventType === "Turnier") {
    return <Badge className="bg-violet-500/[0.10] text-violet-200 border-violet-300/[0.16] text-xs">Turnier</Badge>
  } else if (eventType === "Versammlung") {
    return <Badge className="bg-emerald-500/[0.10] text-emerald-200 border-emerald-300/[0.16] text-xs">Event</Badge>
  } else if (eventType === "Urlaub") {
    } else if (eventType === "Privat") {
    return <Badge className="bg-white/[0.05] text-white/65 border-white/[0.08] text-xs">🔒 Privat</Badge>
    return <Badge className="bg-sky-100 text-sky-800 border-sky-200 text-xs">🏖️ Urlaub</Badge>
  } else if (eventType === "Feiertag") {
    return <Badge className="bg-red-500/[0.10] text-red-200 border-red-300/[0.16] text-xs">🇦🇹 Feiertag</Badge>
  } else if (eventType === "Spielfrei") {
    return <Badge className="bg-amber-500/[0.10] text-amber-200 border-amber-300/[0.16] text-xs">Spielfrei</Badge>
  } else {
    return <Badge className="bg-white/[0.04] text-white/75 border-white/[0.08] text-xs">Event</Badge>
  }
}





const safeString = (value: any): string => {
  if (!value) return ""

  if (typeof value === "object") {
    if (value?.type === "Buffer" && Array.isArray(value?.data)) {
      try {
        return new TextDecoder().decode(new Uint8Array(value.data))
      } catch {
        return ""
      }
    }
  }

  return String(value)
}




  const formatTimeWithoutSeconds = (value: any): string => {
  if (!value) return ""

 
  if (typeof value === "object") {
    // { type: "Buffer", data: [...] }
    if (value?.type === "Buffer" && Array.isArray(value?.data)) {
      try {
        value = new TextDecoder().decode(new Uint8Array(value.data))
      } catch {
        // ignore
      }
    } else if (value instanceof Uint8Array) {
      try {
        value = new TextDecoder().decode(value)
      } catch {
        // ignore
      }
    }
  }

  const s = String(value)


  const m = s.match(/(\d{2}:\d{2})/)
  if (m) return m[1]

  // Fallback
  return s.substring(0, 5)
}




const normalizeTimeHHMM = (value: any): string => {
  if (!value) return ""


  if (typeof value === "object") {
    if (value?.type === "Buffer" && Array.isArray(value?.data)) {
      try {
        value = new TextDecoder().decode(new Uint8Array(value.data))
      } catch {
        return ""
      }
    } else if (value instanceof Uint8Array) {
      try {
        value = new TextDecoder().decode(value)
      } catch {
        return ""
      }
    }
  }

  const s = String(value)
  const m = s.match(/(\d{1,2}):(\d{2})/)
  if (!m) return ""

  const hh = m[1].padStart(2, "0")
  const mm = m[2]
  return `${hh}:${mm}`
}


const toggleInvitePlayer = (playerId: string) => {
  setInvitePlayerIds((prev) =>
    prev.includes(playerId) ? prev.filter((id) => id !== playerId) : [...prev, playerId],
  )
}



  const handleMobileTileClick = (date: Date, items: CalendarItem[]) => {
    if (items.length === 0) return

    setMobileSelectedDate(date)
    setIsMobileBottomSheetOpen(true)
  }

  
  const birthdayEventsForList: Event[] =
    selectedItemType !== "Spiele" && selectedItemType !== "Turniere" && selectedItemType !== "Events"
      ? birthdayPlayers.map((p) => {
          const parts = (p.birthdate || "").split("-")
          const m = String(parts[1] || "01").padStart(2, "0")
          const d = String(parts[2] || "01").padStart(2, "0")
          const year = currentDate.getFullYear()
          const event_date = `${year}-${m}-${d}`

          return {
            id: `birthday-list-${p.id}-${event_date}`,
            name: `🎂 Geburtstag: ${p.name}`,
            event_date,
            event_type: "Geburtstag",
            description: `${p.name} hat Geburtstag.`,
            start_time: "00:00:00",
            type: "birthday",
          }
        })
      : []


  const vacationEventsForList: Event[] =
    selectedItemType !== "Spiele" && selectedItemType !== "Turniere"
      ? vacations.map((v) => ({
          id: `vacation-list-${v.id}-${v.start_date}`,
          vacation_id: v.id,
            vacation_user_id: (v as any).user_id ?? null,
          start_date: v.start_date,
          end_date: v.end_date,
          note: sanitizeVacationNote(v.note),
          name: `🏖️ Urlaub: ${v.player_name || v.user_name}`,
          event_date: v.start_date,
          event_type: "Urlaub",
          description: `${v.start_date} bis ${v.end_date}${sanitizeVacationNote(v.note) ? ` • ${sanitizeVacationNote(v.note)}` : ""}`,
          start_time: "00:00:00",
          type: "vacation",
        }))
      : []

  if (loading) {
    return (
      <div className="relative min-h-screen overflow-x-hidden bg-[#050608] pb-20 text-white">
        <main className="flex-grow pt-14 sm:pt-16">
          <div className="mx-auto w-full max-w-[var(--emd-content-max)] overflow-x-hidden px-3 py-4 sm:px-5 lg:px-7 xl:px-8">

            <div className="flex items-center justify-center h-64">
              <div className="text-center">
                <div className="mx-auto mb-4 h-10 w-10 animate-spin rounded-full border-4 border-orange-500 border-t-transparent"></div>
                <p className="font-medium text-white/40">Vereinskalender wird geladen…</p>
              </div>
            </div>
          </div>
        </main>
        <MobileBottomNav />
      </div>
    )
  }

  return (
      <div className="calendar-premium relative min-h-screen overflow-x-hidden bg-[#050608] text-white font-sans flex flex-col pb-20">

      <Header variant="app" title="Vereinskalender" subtitle="Mein EMD" backHref="/member-profile-app" />

      <div className="pointer-events-none fixed inset-0 z-0">
        <div
          className="absolute inset-0 bg-cover bg-[66%_50%] bg-no-repeat opacity-[0.32]"
          style={{ backgroundImage: "url('/terminal/hero-startscreen.png')" }}
        />
        <div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(3,5,8,.69),rgba(3,5,9,.94)_45%,rgba(2,4,7,.985))]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_8%_18%,rgba(249,115,22,.17),transparent_25%),radial-gradient(circle_at_90%_25%,rgba(14,165,233,.11),transparent_27%),radial-gradient(circle_at_52%_82%,rgba(168,85,247,.06),transparent_24%)]" />
      </div>

     <main className="w-full pt-14 sm:pt-16">
      <div className="w-full max-w-none overflow-x-hidden px-2 py-3 pb-24 sm:px-4 sm:py-5 sm:pb-10 lg:px-5 xl:px-6 2xl:px-8">



         

          <section className="relative mb-5 overflow-hidden rounded-[30px] border border-white/[0.08] bg-black/35 shadow-[0_28px_80px_-48px_rgba(0,0,0,.95)] backdrop-blur-xl">
            <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-orange-500/[0.14] blur-3xl" />
            <div className="pointer-events-none absolute bottom-0 left-1/3 h-40 w-72 rounded-full bg-sky-500/[0.07] blur-3xl" />
            <div className="relative p-4 sm:p-6 lg:p-8 xl:p-9">
              <div className="flex items-center gap-4">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border border-orange-300/[0.14] bg-orange-500/[0.08]">
                  <CalendarDays className="h-6 w-6 text-orange-400" />
                </div>
                <div className="min-w-0">
                  <h1 className="text-3xl font-black tracking-[-0.04em] text-white sm:text-4xl lg:text-5xl">Vereinskalender</h1>
                  <p className="mt-2 text-sm font-medium text-white/55 sm:text-base">Alle Liga-Spiele und Termine von Emoj!'s Dartverein</p>
                </div>
              </div>
            </div>
          </section>

          {todayHighlights.length > 0 && (
            <div className="mb-4 sm:mb-5">
              <Card className="overflow-hidden rounded-[28px] border border-white/[0.08] bg-black/30 shadow-none backdrop-blur-xl transition duration-300 hover:border-orange-300/[0.14]">
                <CardContent className="p-4 sm:p-5">
                  <div className="flex items-start gap-3">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl border border-orange-300/[0.14] bg-orange-500/[0.08]">
                      <Star className="h-5 w-5 text-orange-200" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-black text-white">Heute im Verein</div>

                      <div className="mt-3 space-y-2">
                        {todayHighlights.slice(0, 5).map((item) => {
                          const isMatch = "match_date" in item
                          if (isMatch) {
                            const match = item as Match
                            return (
                              <button
                                key={match.id}
                                onClick={() => openMatchDialog(match)}
                                className="w-full text-left"
                              >
                                <div className="flex min-w-0 items-center justify-between gap-3 rounded-[18px] border border-white/[0.08] bg-black/30 p-3 transition hover:border-orange-300/[0.16] hover:bg-orange-500/[0.08]/30">
                                  <div className="min-w-0">
                                    <div className="truncate text-sm font-black text-white">
                                      🎯 {getTeamDisplayName(match, true)} vs {getTeamDisplayName(match, false)}
                                    </div>
                                    <div className="mt-1 text-xs font-medium text-white/35">
  <span>{formatTimeWithoutSeconds(match.match_time)} Uhr</span>

  {match.season?.name ? ` • ${match.season.name}` : ""}
</div>

                                  </div>

                                  <div className="shrink-0">
                                    {match.status === "completed" || match.status === "finished" ? (
                                      <Badge className="bg-emerald-500/[0.10] text-emerald-200 border-emerald-300/[0.16] text-xs whitespace-nowrap">
                                        {match.home_score} : {match.away_score}
                                      </Badge>
                                    ) : (
                                      getStatusBadge(match.status)
                                    )}
                                  </div>
                                </div>
                              </button>
                            )
                          } else {
                            const ev = item as Event
                            return (
                              <button
                                key={ev.id}
                                onClick={() => openEventDialog(ev)}
                                className="w-full text-left"
                              >
                                <div className="flex min-w-0 items-center justify-between gap-3 rounded-[18px] border border-white/[0.08] bg-black/30 p-3 transition hover:border-orange-300/[0.16] hover:bg-orange-500/[0.08]/30">
                                  <div className="min-w-0">
                                    <div className="truncate text-sm font-black text-white">
                                      {ev.event_type === "Geburtstag" ? "🎂" : ev.event_type === "Turnier" ? "🏆" : "📅"}{" "}
                                      {ev.name}
                                    </div>
                                    <div className="mt-1 text-xs font-medium text-white/35">
                                      {ev.event_type === "Urlaub"
                                        ? `Urlaub • ${ev.start_date} bis ${ev.end_date}`
                                        : ev.event_type === "Geburtstag"
                                          ? "Geburtstag"
                                          : `${ev.event_type}${ev.start_time ? ` • ${normalizeTimeHHMM(ev.start_time)} Uhr` : ""}`}

                                    </div>
                                  </div>

                                  <div className="shrink-0">{getEventTypeBadge(ev.event_type)}</div>
                                </div>
                              </button>
                            )
                          }
                        })}

                        {todayHighlights.length > 5 && (
                          <div className="text-xs text-white/35 pt-1">+ {todayHighlights.length - 5} weitere</div>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {todayBirthdays.length > 0 && (
            <div className="mb-4 sm:mb-5">
              <Card className="overflow-hidden rounded-[28px] border border-white/[0.08] bg-black/30 shadow-none backdrop-blur-xl transition duration-300 hover:border-orange-300/[0.14]">
                <CardContent className="p-4 sm:p-5">
                  <div className="flex items-start gap-3">
                    <div className="p-2 bg-pink-500/[0.10] rounded-lg">
                      <Cake className="h-5 w-5 text-pink-200" />
                    </div>
                    <div className="flex-1">
                      <div className="font-black text-white">Heute hat jemand Geburtstag 🎉</div>
                      <div className="text-sm text-white/60 mt-1">{todayBirthdays.map((p) => p.name).join(", ")}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          <div className="mb-4 sm:mb-5">
            <Card className="overflow-hidden rounded-[28px] border border-white/[0.08] bg-black/30 shadow-none backdrop-blur-xl transition duration-300 hover:border-orange-300/[0.14]">
              <CardContent className="p-3">
                <div className="flex flex-col gap-3">
                  <div className="flex justify-center">
                    <div className="flex rounded-2xl border border-white/[0.08] bg-black/35 p-1">
                      <Button
                        variant={viewMode === "month" ? "default" : "outline"}
                        size="sm"
                        onClick={() => setViewMode("month")}
                        className="flex items-center gap-2 rounded-xl border-0 text-xs font-black"
                      >
                        <Calendar className="h-4 w-4" />
                        Monat
                      </Button>
                      <Button
                        variant={viewMode === "list" ? "default" : "outline"}
                        size="sm"
                        onClick={() => setViewMode("list")}
                        className="flex items-center gap-2 rounded-xl border-0 text-xs font-black"
                      >
                        <Filter className="h-4 w-4" />
                        Liste
                      </Button>
                      <Button
                        variant={viewMode === "browse" ? "default" : "outline"}
                        size="sm"
                        onClick={() => setViewMode("browse")}
                        className="flex items-center gap-2 rounded-xl border-0 text-xs font-black"
                      >
                        <Users className="h-4 w-4" />
                        Übersicht
                      </Button>
                    </div>
                  </div>

                  <div className="flex flex-col gap-2">
                    <Select value={selectedItemType} onValueChange={setSelectedItemType}>
                      <SelectTrigger className="h-11 w-full rounded-xl border-white/[0.09] bg-[#080c12]/95 text-sm text-white shadow-none">
                        <SelectValue placeholder="Typ auswählen" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Alle" className="text-sm">
                          Alle Termine
                        </SelectItem>
                        <SelectItem value="Spiele" className="text-sm">
                          <div className="flex items-center gap-2">
                            <Target className="h-4 w-4 text-orange-200" />
                            Nur Spiele
                          </div>
                        </SelectItem>
                        <SelectItem value="Turniere" className="text-sm">
                          <div className="flex items-center gap-2">
                            <Trophy className="h-4 w-4 text-violet-200" />
                            Nur Turniere
                          </div>
                        </SelectItem>
                        <SelectItem value="Events" className="text-sm">
                          <div className="flex items-center gap-2">
                            <CalendarDays className="h-4 w-4 text-green-600" />
                            Nur Events
                          </div>
                        </SelectItem>
						
						<SelectItem value="Feiertage" className="text-sm">
  <div className="flex items-center gap-2">
    <CalendarDays className="h-4 w-4 text-red-200" />
    Nur Feiertage
  </div>
</SelectItem>

                        <SelectItem value="Urlaube" className="text-sm">
                          <div className="flex items-center gap-2">
                            <Sun className="h-4 w-4 text-sky-200" />
                            Nur Urlaube
                          </div>
                        </SelectItem>

                        {}
                        <SelectItem value="Geburtstage" className="text-sm">
                          <div className="flex items-center gap-2">
                            <Cake className="h-4 w-4 text-pink-200" />
                            Nur Geburtstage
                          </div>
                        </SelectItem>
                      </SelectContent>
                    </Select>

                    <Select value={selectedLeague} onValueChange={setSelectedLeague}>
                      <SelectTrigger className="h-11 w-full rounded-xl border-white/[0.09] bg-[#080c12]/95 text-sm text-white shadow-none">
                        <SelectValue placeholder="Liga auswählen" />
                      </SelectTrigger>
                      <SelectContent>
                        {leagues.map((league) => (
                          <SelectItem key={league} value={league} className="text-sm">
                            {league}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>

                    <Select value={selectedTeam} onValueChange={setSelectedTeam}>
                      <SelectTrigger className="h-11 w-full rounded-xl border-white/[0.09] bg-[#080c12]/95 text-sm text-white shadow-none">
                        <SelectValue placeholder="Team auswählen" />
                      </SelectTrigger>
                      <SelectContent>
                        {teams.map((team) => (
                          <SelectItem key={team} value={team} className="text-sm">
                            {team}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>

                    <Select value={selectedResultType} onValueChange={setSelectedResultType}>
                      <SelectTrigger className="h-11 w-full rounded-xl border-white/[0.09] bg-[#080c12]/95 text-sm text-white shadow-none">
                        <SelectValue placeholder="Ergebnis-Typ auswählen" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Alle" className="text-sm">
                          Alle Ergebnisse
                        </SelectItem>
                        <SelectItem value="Gespielt" className="text-sm">
                          <div className="flex items-center gap-2">
                            <Badge className="bg-emerald-500/[0.10] text-emerald-200 border-emerald-300/[0.16] text-xs">Gespielt</Badge>
                          </div>
                        </SelectItem>
                        <SelectItem value="Geplant" className="text-sm">
                          <div className="flex items-center gap-2">
                            <Badge className="bg-sky-500/[0.10] text-sky-200 border-sky-300/[0.16] text-xs">Geplant</Badge>
                          </div>
                        </SelectItem>
                      </SelectContent>
                    </Select>

                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setSelectedItemType("Alle")
                        setSelectedLeague("Alle Ligen")
                        setSelectedTeam("Alle Teams")
                        setSelectedResultType("Alle")
                      }}
                      className="w-full bg-black/30 hover:bg-white/[0.035] border-white/[0.08] text-xs"
                    >
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Zurücksetzen
                    </Button>
					
					
					
					{isVorstand && (
  <Button
    variant="default"
    size="sm"
    onClick={() => {
  setBoardTitle("")
  setBoardDesc("")
  setBoardDate("")
  setBoardTime("")
  setBoardFiles(null)
  setInvitePlayerIds([])
  setInviteSearch("")
  setIsBoardDialogOpen(true)
}}
    className="w-full h-11 rounded-2xl text-sm font-semibold shadow-sm bg-black hover:bg-black/90"
  >
    <Plus className="h-4 w-4 mr-2" />
    Vorstand Termin
  </Button>
)}
					

<div className="flex flex-col gap-2">
  <Button
    variant="default"
    size="sm"
    onClick={() => {
      setEditingVacationId(null)
      setVacationStart("")
      setVacationEnd("")
      setVacationNote("")
      setIsVacationDialogOpen(true)
    }}
    className="w-full h-11 rounded-2xl text-sm font-semibold shadow-sm"
  >
    <Plus className="h-4 w-4 mr-2" />
    Urlaub eintragen
  </Button>

  <Button
    variant="outline"
    size="sm"
    onClick={() => {
  setEditingPrivateEntryId(null)
  setPrivateTitle("")
  setPrivateStart("")
  setPrivateEnd("")
  setPrivateTime("")
  setPrivateNote("")
  setIsPrivateDialogOpen(true)
}}
    className="w-full h-11 rounded-2xl text-sm font-semibold shadow-sm"
  >
    🔒 Privaten Termin
  </Button>
</div>
					
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>


          {viewMode === "browse" && (
            <div className="space-y-4">
              <Card className="overflow-hidden rounded-[28px] border border-white/[0.08] bg-black/30 shadow-none backdrop-blur-xl transition duration-300 hover:border-orange-300/[0.14]">
                <CardHeader className="pb-2 px-2 sm:px-6">

                  <CardTitle className="text-base text-white">Kachelübersicht</CardTitle>
                </CardHeader>
                <CardContent className="space-y-5">
                  <div>
                    <div className="text-sm font-semibold text-white mb-2">Typen</div>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => {
                          setSelectedItemType("Alle")
                          setSelectedLeague("Alle Ligen")
                          setSelectedTeam("Alle Teams")
                          setViewMode("list")
                        }}
                        className="p-3 rounded-xl border bg-black/30 hover:bg-white/[0.035] text-left transition-colors"
                      >
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-white/60" />
                          <div className="text-sm font-medium text-white">Alle Termine</div>
                        </div>
                      </button>

                      <button
                        onClick={() => {
                          setSelectedItemType("Spiele")
                          setSelectedLeague("Alle Ligen")
                          setSelectedTeam("Alle Teams")
                          setViewMode("list")
                        }}
                        className="p-3 rounded-xl border bg-black/30 hover:bg-white/[0.035] text-left transition-colors"
                      >
                        <div className="flex items-center gap-2">
                          <Target className="h-4 w-4 text-orange-200" />
                          <div className="text-sm font-medium text-white">Spiele</div>
                        </div>
                      </button>

                      <button
                        onClick={() => {
                          setSelectedItemType("Turniere")
                          setSelectedLeague("Alle Ligen")
                          setSelectedTeam("Alle Teams")
                          setViewMode("list")
                        }}
                        className="p-3 rounded-xl border bg-black/30 hover:bg-white/[0.035] text-left transition-colors"
                      >
                        <div className="flex items-center gap-2">
                          <Trophy className="h-4 w-4 text-violet-200" />
                          <div className="text-sm font-medium text-white">Turniere</div>
                        </div>
                      </button>

                      <button
                        onClick={() => {
                          setSelectedItemType("Events")
                          setSelectedLeague("Alle Ligen")
                          setSelectedTeam("Alle Teams")
                          setViewMode("list")
                        }}
                        className="p-3 rounded-xl border bg-black/30 hover:bg-white/[0.035] text-left transition-colors"
                      >
                        <div className="flex items-center gap-2">
                          <CalendarDays className="h-4 w-4 text-green-600" />
                          <div className="text-sm font-medium text-white">Events</div>
                        </div>
                      </button>

                      <button
                        onClick={() => {
                          setSelectedItemType("Urlaube")
                          setSelectedLeague("Alle Ligen")
                          setSelectedTeam("Alle Teams")
                          setViewMode("list")
                        }}
                        className="p-3 rounded-xl border bg-black/30 hover:bg-white/[0.035] text-left transition-colors"
                      >
                        <div className="flex items-center gap-2">
                          <Sun className="h-4 w-4 text-sky-200" />
                          <div className="text-sm font-medium text-white">Urlaube</div>
                        </div>
                      </button>

                      <button
                        onClick={() => {
                          setSelectedItemType("Geburtstage")
                          setSelectedLeague("Alle Ligen")
                          setSelectedTeam("Alle Teams")
                          setViewMode("list")
                        }}
                        className="p-3 rounded-xl border bg-black/30 hover:bg-white/[0.035] text-left transition-colors"
                      >
                        <div className="flex items-center gap-2">
                          <Cake className="h-4 w-4 text-pink-200" />
                          <div className="text-sm font-medium text-white">Geburtstage</div>
                        </div>
                      </button>
                    </div>
                  </div>

                  <div>
                    <div className="text-sm font-semibold text-white mb-2">Ligen</div>
                    <div className="grid grid-cols-2 gap-2">
                      {leagues
                        .filter((l) => l !== "Alle Ligen")
                        .map((league) => (
                          <button
                            key={league}
                            onClick={() => {
                              setSelectedLeague(league)
                              setSelectedTeam("Alle Teams")
                              setSelectedItemType("Spiele")
                              setViewMode("list")
                            }}
                            className="p-3 rounded-xl border bg-black/30 hover:bg-white/[0.035] text-left transition-colors"
                          >
                            <div className="flex items-center gap-2 min-w-0">
                              <Trophy className="h-4 w-4 text-white/60 shrink-0" />
                              <div className="truncate text-sm font-black text-white">{league}</div>
                            </div>
                          </button>
                        ))}
                    </div>
                    {leagues.filter((l) => l !== "Alle Ligen").length === 0 && (
                      <div className="text-xs text-white/35">Keine Ligen gefunden.</div>
                    )}
                  </div>

                  <div>
                    <div className="text-sm font-semibold text-white mb-2">Teams</div>
                    <div className="mb-2">
                      <Input
                        value={browseTeamQuery}
                        onChange={(e) => setBrowseTeamQuery(e.target.value)}
                        placeholder="Team suchen…"
                        className="h-11 rounded-xl border-white/[0.09] bg-[#080c12]/95 text-sm text-white placeholder:text-white/25 shadow-none"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      {clubTeams
                        .filter((t) => t.name.toLowerCase().includes(browseTeamQuery.toLowerCase().trim()))
                        .map((team) => (
                          <button
                            key={team.id}
                            onClick={() => {
                              setSelectedTeam(team.name)
                              setSelectedItemType("Spiele")
                              setViewMode("list")
                            }}
                            className="p-3 rounded-xl border bg-black/30 hover:bg-white/[0.035] text-left transition-colors"
                          >
                            <div className="flex items-center gap-2 min-w-0">
                              <Avatar className="h-6 w-6 shrink-0">
                                <AvatarImage src={team.logo_url ?? undefined} alt={team.name} />
                                <AvatarFallback>{team.name?.slice(0, 1)?.toUpperCase()}</AvatarFallback>
                              </Avatar>
                              <div className="truncate text-sm font-black text-white">{team.name}</div>
                            </div>
                          </button>
                        ))}</div>
                    {clubTeams.length === 0 && (
                      <div className="text-xs text-white/35">Keine Teams gefunden.</div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {viewMode === "month" && (
  <Card className="w-full overflow-hidden rounded-[28px] border border-white/[0.08] bg-black/30 shadow-none backdrop-blur-xl">


              <CardHeader className="pb-3 px-2 sm:px-6">

                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl lg:text-3xl font-bold">

                    {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
                  </CardTitle>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={() => navigateMonth("prev")} className="rounded-xl border-white/[0.09] bg-white/[0.035] text-white hover:bg-white/[0.07] hover:text-white">
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => setCurrentDate(new Date())} className="rounded-xl border-orange-300/[0.15] bg-orange-500/[0.08] font-black text-orange-100 hover:bg-orange-500/[0.14] hover:text-white">
                      Heute
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => navigateMonth("next")} className="rounded-xl border-white/[0.09] bg-white/[0.035] text-white hover:bg-white/[0.07] hover:text-white">
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-2 sm:p-6">

                <div className="grid grid-cols-7 gap-1 mb-2">
                  {dayNames.map((day) => (
                    <div key={day} className="text-center text-xs font-medium text-white/35 p-2">
                      {day}
                    </div>
                  ))}
                </div>
                <div className="grid grid-cols-7 gap-1">
                  {Array.from({ length: 42 }, (_, index) => {
                    const day = getDaysInMonth(currentDate)[index]
                    const isToday = day?.toDateString() === new Date().toDateString()
                    const itemsForDay = day ? getItemsForDate(day) : []

                    return (
                      <div
                        key={index}
                        className={`p-1 border border-white/[0.08] rounded-lg transition-colors overflow-hidden ${
                          isToday ? "bg-orange-500/[0.08] border-orange-300" : "bg-black/30 hover:bg-white/[0.035]"
                        } 
                        h-24 sm:h-28 lg:h-40
 cursor-pointer`}
                        onClick={() => {
                          if (day && itemsForDay.length > 0) {
                            if (window.innerWidth < 768) {
                              handleMobileTileClick(day, itemsForDay)
                            } else {
                              if (itemsForDay.length === 1) {
                                handleItemClick(itemsForDay[0])
                              } else {
                                openMultiItemDialogDialog(day, itemsForDay)
                              }
                            }
                          }
                        }}
                      >
                        {day && (
                          <div className={`text-sm font-medium mb-1 ${isToday ? "text-orange-200" : "text-white"}`}>
                            {day.getDate()}
                          </div>
                        )}

                        <div className="space-y-1 overflow-hidden">
                          <div className="block">
                      <div className="block">
  <div className="space-y-1 mt-1">
    {itemsForDay.slice(0, 3).map((item, idx) => {
      const isMatch = "match_date" in item

      let bg = "bg-gray-400"
      let text = ""

      if (isMatch) {
        bg = "bg-orange-500"
        const time = formatTimeWithoutSeconds((item as any).match_time)

const shortenTeam = (name: string, max = 14) => {
  const cleaned = (name || "").replace(/\s+/g, " ").trim()
  if (!cleaned) return "Team"
  return cleaned.length > max ? cleaned.slice(0, max - 1) + "…" : cleaned
}

const homeName = getTeamDisplayName(item, true) || "Team"
const awayName = getTeamDisplayName(item, false) || "Team"

const homeShort = shortenTeam(homeName, 14)
const awayShort = shortenTeam(awayName, 14)


text = `${normalizeTimeHHMM((item as any).match_time)} Uhr ${homeShort} vs ${awayShort}`



      } else {
        const ev: any = item
        if (ev.event_type === "Feiertag") bg = "bg-red-500/85"
else if (ev.event_type === "Urlaub") bg = "bg-sky-500/85"
else if (ev.event_type === "Turnier") bg = "bg-violet-500/85"
else if (ev.event_type === "Geburtstag") bg = "bg-pink-500/85"
else bg = "bg-emerald-500/85"

        text = ev.name || "Termin"
      }

     return (
  <div
    key={idx}
    className={`${bg} text-white text-[11px] font-medium px-1 py-0.5 rounded-sm`}
    title={text}
  >
   
  <span
  className="block leading-tight overflow-hidden"
  style={{ display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical" }}
>
  {isMatch
    ? `${normalizeTimeHHMM((item as any).match_time)} ${getTeamDisplayName(item, true)} vs ${getTeamDisplayName(item, false)}`
    : text}
</span>
 
   
   
   
  </div>
)

    })}

    {itemsForDay.length > 3 && (
      <div className="text-[11px] font-medium text-white/35 px-0.5">
        +{itemsForDay.length - 3} mehr
      </div>
    )}
  </div>
</div>

                            
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          )}

          {viewMode === "list" && (
            <div className="space-y-3">
              {(() => {
                const listItems: CalendarItem[] =
                  selectedItemType === "Spiele"
                    ? [...filteredMatches]
                    : selectedItemType === "Turniere" || selectedItemType === "Events"
                      ? [...filteredEvents]
                      : selectedItemType === "Geburtstage"
                        ? [...birthdayEventsForList]
                        : selectedItemType === "Urlaube"
                          ? [...vacationEventsForList]
                          : [...filteredMatches, ...filteredEvents, ...birthdayEventsForList, ...vacationEventsForList]

                if (listItems.length === 0) {
                  return (
                    <Card className="border bg-black/30 w-full shadow-none rounded-none sm:rounded-xl">

                      <CardContent className="p-6 text-center">
                        <Target className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                        <h3 className="text-lg font-semibold text-white mb-2">Keine Termine gefunden</h3>
                        <p className="mt-2 text-sm font-medium text-white/35 sm:text-base">Mit den aktuellen Filtern wurden keine Termine gefunden.</p>
                      </CardContent>
                    </Card>
                  )
                }

                return listItems
                  .sort((a, b) => {
                    const todayStr = format(new Date(), "yyyy-MM-dd")

                    const dateA =
  "match_date" in a ? a.match_date : (a.start_date || a.event_date)

const dateB =
  "match_date" in b ? b.match_date : (b.start_date || b.event_date)

                    const timeA =
                      "match_time" in a
                        ? normalizeTimeHHMM(a.match_time) || "00:00"

                       : normalizeTimeHHMM((a as any).start_time) || "00:00"

                    const timeB =
                      "match_time" in b
                        ? normalizeTimeHHMM(b.match_time) || "00:00"

                       : normalizeTimeHHMM((b as any).start_time) || "00:00"


                    const keyA = `${dateA}T${timeA}`
                    const keyB = `${dateB}T${timeB}`

                    const isUpcomingA = dateA >= todayStr
                    const isUpcomingB = dateB >= todayStr

                 
                    if (isUpcomingA && !isUpcomingB) return -1
                    if (!isUpcomingA && isUpcomingB) return 1

                    if (isUpcomingA && isUpcomingB) {
                      return keyA.localeCompare(keyB) // soonest first
                    }
                    return keyB.localeCompare(keyA) // past: newest first
                  })
                  .map((item) => {
                    if (isEvent(item)) {
                      return (
                        <Card key={item.id} className="shadow-[0_14px_42px_-34px_rgba(15,23,42,0.5)] border-0 bg-black/30 hover:shadow-none backdrop-blur-xl transition-shadow">
                          <CardContent className="p-4 sm:p-5">
                            <div className="flex flex-col gap-3">
                              <div className="flex-1 min-w-0">
                                <div className="flex flex-col gap-2 mb-2">
                                  <div className="flex items-center gap-2">{getEventTypeBadge(item.event_type)}</div>
                                {item.photo_url && (
                                  <div className="mt-3">
                                    <img
                                      src={item.photo_url}
                                      alt={item.name}
                                      className="w-full h-36 object-cover rounded-xl border"
                                    />
                                  </div>
                                )}

                                </div>

                                <div className="mb-2 min-w-0">
                                  <h3 className="text-base font-semibold text-white mb-1">{item.name}</h3>
                                  {item.description && <p className="mt-2 text-sm font-medium text-white/35 sm:text-base">{item.description}</p>}
                                </div>

                                <div className="flex flex-col gap-2 text-sm text-white/50">
                                  <div className="flex items-center gap-2 min-w-0">
  <Calendar className="h-4 w-4 shrink-0" />
  <span>
    {new Date(item.start_date || item.event_date).toLocaleDateString("de-DE", {
      weekday: "short",
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    })}
    {(item.end_date || item.event_date) !== (item.start_date || item.event_date)
      ? ` – ${new Date(item.end_date || item.event_date).toLocaleDateString("de-DE", {
          weekday: "short",
          day: "2-digit",
          month: "2-digit",
          year: "numeric",
        })}`
      : ""}
  </span>
</div>
                                  {item?.start_time && (
  <div className="flex items-center gap-2 min-w-0">
    <Clock className="h-4 w-4 shrink-0" />
    <span>{formatTimeWithoutSeconds(item.start_time)} Uhr</span>
  </div>
)}

                                  <div className="flex items-center gap-2 min-w-0">
                                    {item.event_type === "Turnier" ? (
                                      <>
                                        <Trophy className="h-4 w-4 text-violet-200 shrink-0" />
                                        <span className="text-violet-200 font-medium">Turnier</span>
                                      </>
                                    ) : item.event_type === "Geburtstag" ? (
                                      <>
                                        <Cake className="h-4 w-4 text-pink-200 shrink-0" />
                                        <span className="text-pink-200 font-medium">Geburtstag</span>
                                      </>
                                    ) : item.event_type === "Urlaub" ? (
                                      <>
                                        <Sun className="h-4 w-4 text-sky-200 shrink-0" />
                                        <span className="text-sky-200 font-medium">Urlaub</span>
                                      </>
                                    ) : (
                                      <>
                                        <Star className="h-4 w-4 text-green-600 shrink-0" />
                                        <span className="text-green-600 font-medium">Vereinsevent</span>
                                      </>
                                    )}
                                  </div>
                                </div>
                              </div>

                              <div className="flex justify-end">
                                <Button
                                  onClick={() => openEventDialog(item)}
                                  variant="outline"
                                  size="sm"
                                  className="w-full"
                                >
                                  Details
                                </Button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      )
                    } else {
                      const match = item as Match
                      return (
                        <Card key={match.id} className="shadow-[0_14px_42px_-34px_rgba(15,23,42,0.5)] border-0 bg-black/30 hover:shadow-none backdrop-blur-xl transition-shadow">
                          <CardContent className="p-4 sm:p-5">
                            <div className="flex flex-col gap-3">
                              <div className="flex-1 min-w-0">
                                <div className="flex flex-col gap-2 mb-2">
                                  <div className="flex items-center gap-2">
                                    {getStatusBadge(match.status)}
                                    <Badge variant="outline" className="text-xs">
                                      {match.season?.name || "Liga"}
                                    </Badge>
                                  </div>
                                  <div className="text-sm text-white/50">Spieltag {match.week_number}</div>
                                </div>

                                <div className="flex items-center gap-4 mb-2 min-w-0">
                                  <div className="flex items-center gap-3 flex-1 min-w-0">
                                    <Avatar className="h-8 w-8 shrink-0">
                                      <AvatarImage
                                        src={getTeamLogo(match, true) || "/placeholder.svg?height=40&width=40"}
                                      />
                                      <AvatarFallback className="bg-orange-100 text-orange-200 font-bold text-xs">
                                        {getTeamDisplayName(match, true).charAt(0)}
                                      </AvatarFallback>
                                    </Avatar>
                                    <span className="font-semibold text-sm truncate min-w-0">
                                      {getTeamDisplayName(match, true)}
                                    </span>
                                  </div>

                                  <div className="text-center px-2 shrink-0 whitespace-nowrap">
                                    {match.status === "completed" || match.status === "finished" ? (
                                      <div className="text-lg font-bold whitespace-nowrap">
                                        {match.home_score} : {match.away_score}
                                      </div>
                                    ) : (
                                      <div className="text-gray-400 font-bold">vs</div>
                                    )}
                                  </div>

                                  <div className="flex items-center gap-3 flex-1 justify-end min-w-0">
                                    <span className="font-semibold text-sm truncate min-w-0 text-right">
                                      {getTeamDisplayName(match, false)}
                                    </span>
                                    <Avatar className="h-8 w-8 shrink-0">
                                      <AvatarImage
                                        src={getTeamLogo(match, false) || "/placeholder.svg?height=40&width=40"}
                                      />
                                      <AvatarFallback className="bg-sky-500/[0.10] text-blue-700 font-bold text-xs">
                                        {getTeamDisplayName(match, false).charAt(0)}
                                      </AvatarFallback>
                                    </Avatar>
                                  </div>
                                </div>

                                <div className="flex flex-col gap-2 text-sm text-white/50">
                                  <div className="flex items-center gap-2 min-w-0">
                                    <Calendar className="h-4 w-4 shrink-0" />
                                    {new Date(match.match_date).toLocaleDateString("de-DE", {
                                      weekday: "short",
                                      day: "2-digit",
                                      month: "2-digit",
                                      year: "numeric",
                                    })}
                                  </div>
                                  <div className="flex items-center gap-2 min-w-0">
                                    <Clock className="h-4 w-4 shrink-0" />
<span>{formatTimeWithoutSeconds(match.match_time)} Uhr</span>

                                  </div>
                                  <div className="flex items-center gap-2 min-w-0">
                                    <MapPin className="h-4 w-4 shrink-0" />
                                    <span className="truncate">{match.venue}</span>
                                  </div>
                                  <div className="flex items-center gap-2 min-w-0">
                                    {isHomeGame(match) ? (
                                      <>
                                        <Home className="h-4 w-4 text-orange-200 shrink-0" />
                                        <span className="text-orange-200 font-medium">Heimspiel</span>
                                      </>
                                    ) : (
                                      <>
                                        <Plane className="h-4 w-4 text-blue-600 shrink-0" />
                                        <span className="text-blue-600 font-medium">Auswärtsspiel</span>
                                      </>
                                    )}
                                  </div>
                                </div>
                              </div>

                              <div className="flex justify-end">
                                <Button onClick={() => openMatchDialog(match)} variant="outline" size="sm" className="w-full">
                                  Details
                                </Button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      )
                    }
                  })
              })()}
            </div>
          )}

          <Dialog open={isMatchDialogOpen} onOpenChange={setIsMatchDialogOpen}>
            <DialogContent className="w-[calc(100vw-1.5rem)] sm:w-auto sm:max-w-md max-h-[80dvh] overflow-y-auto calendar-dialog">
              <DialogHeader>
                <DialogTitle className="text-lg">Spiel Details</DialogTitle>
                <DialogDescription className="text-sm">Detaillierte Informationen zum Spiel</DialogDescription>
              </DialogHeader>

              {selectedMatch && (
                <div className="space-y-4">
                  <div className="flex justify-center">{getStatusBadge(selectedMatch.status)}</div>

                  <div className="text-center">
                    <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-4 mb-4">
                      <div className="text-center min-w-0">
                        <Avatar className="h-16 w-16 mx-auto mb-2">
                          <AvatarImage src={getTeamLogo(selectedMatch, true) || "/placeholder.svg?height=64&width=64"} />
                          <AvatarFallback className="bg-orange-100 text-orange-200 font-bold">
                            {getTeamDisplayName(selectedMatch, true).charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <div className="font-semibold text-sm leading-tight break-words">
                          {getTeamDisplayName(selectedMatch, true)}
                        </div>
                      </div>

                      <div className="text-center px-4 whitespace-nowrap">
                        {selectedMatch.status === "completed" || selectedMatch.status === "finished" ? (
                          <div className="text-3xl font-bold whitespace-nowrap">
                            {selectedMatch.home_score} : {selectedMatch.away_score}
                          </div>
                        ) : (
                          <div className="text-2xl text-gray-400 font-bold">vs</div>
                        )}
                      </div>

                      <div className="text-center min-w-0">
                        <Avatar className="h-16 w-16 mx-auto mb-2">
                          <AvatarImage src={getTeamLogo(selectedMatch, false) || "/placeholder.svg?height=64&width=64"} />
                          <AvatarFallback className="bg-sky-500/[0.10] text-blue-700 font-bold">
                            {getTeamDisplayName(selectedMatch, false).charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <div className="font-semibold text-sm leading-tight break-words">
                          {getTeamDisplayName(selectedMatch, false)}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2 bg-black/30 p-3 rounded-lg border">
                    <div className="flex items-center gap-3 text-sm">
                      <Calendar className="h-5 w-5 text-white/50 shrink-0" />
                      <span>
                        {new Date(selectedMatch.match_date).toLocaleDateString("de-DE", {
                          weekday: "long",
                          day: "2-digit",
                          month: "long",
                          year: "numeric",
                        })}
                      </span>
                    </div>
                    {selectedEvent?.start_time && (
  <div className="flex items-center gap-3 text-sm">
    <Clock className="h-5 w-5 text-white/50 shrink-0" />
    <span>{formatTimeWithoutSeconds(selectedEvent.start_time)}</span>
  </div>
)}

                    {selectedEvent?.location && (
                      <div className="flex items-center gap-3 text-sm">
                        <MapPin className="h-5 w-5 text-white/50 shrink-0" />
                        <span>{selectedEvent?.location}</span>
                      </div>
                    )}
                    {(selectedEvent?.entry_fee != null || selectedEvent?.max_participants != null) && (
                      <div className="flex items-center gap-3 text-sm">
                        <Users className="h-5 w-5 text-white/50 shrink-0" />
                        <span>
                          {selectedEvent?.entry_fee != null ? `${selectedEvent?.entry_fee} €` : ""}
                          {selectedEvent?.entry_fee != null && selectedEvent?.max_participants != null ? " • " : ""}
                          {selectedEvent?.max_participants != null ? `Max. ${selectedEvent?.max_participants}` : ""}
                        </span>
                      </div>
                    )}

                    <div className="flex items-center gap-3 text-sm">
                      <Clock className="h-5 w-5 text-white/50 shrink-0" />
                      <span>{formatTimeWithoutSeconds(selectedMatch.match_time)} Uhr</span>
                    </div>
                    <div className="flex items-center gap-3 text-sm min-w-0">
                      <MapPin className="h-5 w-5 text-white/50 shrink-0" />
                      <span className="truncate">{selectedMatch.venue}</span>
                    </div>
                    <div className="flex items-center gap-3 text-sm">
                      <Trophy className="h-5 w-5 text-white/50 shrink-0" />
                      <span>
                        {selectedMatch.season?.name || "Liga"} - Spieltag {selectedMatch.week_number}
                      </span>
                    </div>
                    <div className="flex items-center gap-3 text-sm">
                      {isHomeGame(selectedMatch) ? (
                        <>
                          <Home className="h-5 w-5 text-orange-200 shrink-0" />
                          <span className="text-orange-200 font-medium">Heimspiel</span>
                        </>
                      ) : (
                        <>
                          <Plane className="h-5 w-5 text-blue-600 shrink-0" />
                          <span className="text-blue-600 font-medium">Auswärtsspiel</span>
                        </>
                      )}
                    </div>
                  </div>

                  <div className="flex justify-center">
  <Button
    variant="outline"
    size="sm"
    className="bg-transparent"
    onClick={async () => {
      if (!selectedMatch?.id) return
      await loadLineup(selectedMatch.id)
      setIsLineupDialogOpen(true)
    }}
  >
    <Users className="h-4 w-4 mr-2" />
    Aufstellung
  </Button>
                  </div>
                </div>
              )}
            </DialogContent>
          </Dialog>


          <Dialog open={isEventDialogOpen} onOpenChange={setIsEventDialogOpen}>
            <DialogContent className="w-[calc(100vw-1.5rem)] sm:w-full sm:max-w-md max-h-[80dvh] overflow-y-auto calendar-dialog">

              <DialogHeader>
                <DialogTitle className="text-lg">Event Details</DialogTitle>
                <DialogDescription className="text-sm">Detaillierte Informationen zum Event</DialogDescription>
              </DialogHeader>

              {selectedEvent && (
                <div className="space-y-4">
                  <div className="flex justify-center">{getEventTypeBadge(selectedEvent.event_type)}</div>

                  <div className="text-center">
                    {selectedEvent.photo_url && (
                      <div className="mb-4 sm:mb-5">
                        <img
                          src={selectedEvent.photo_url}
                          alt={selectedEvent.name}
                          className="w-full h-44 object-cover rounded-xl border"
                        />
                      </div>
                    )}
                    <div className="mb-4 sm:mb-5">
                      <div className="h-16 w-16 mx-auto mb-4 bg-gradient-to-br from-orange-100 to-orange-200 rounded-full flex items-center justify-center">
                        {selectedEvent.event_type === "Turnier" ? (
                          <Trophy className="h-8 w-8 text-orange-200" />
                        ) : selectedEvent.event_type === "Geburtstag" ? (
                          <Cake className="h-8 w-8 text-orange-200" />
                        ) : selectedEvent.event_type === "Urlaub" ? (
                          <Sun className="h-8 w-8 text-orange-200" />
                        ) : (
                          <CalendarDays className="h-8 w-8 text-orange-200" />
                        )}
                      </div>
                      <h3 className="text-xl font-bold text-white">{selectedEvent.name}</h3>
                      {selectedEvent.description && <p className="text-white/50 mt-2">{selectedEvent.description}</p>}
                    </div>
                  </div>

                  <div className="space-y-2 bg-black/30 p-3 rounded-lg border">
                    <div className="flex items-center gap-3 text-sm">
  <Calendar className="h-5 w-5 text-white/50 shrink-0" />
  <span>
    {new Date(selectedEvent.start_date || selectedEvent.event_date).toLocaleDateString("de-DE", {
      weekday: "long",
      day: "2-digit",
      month: "long",
      year: "numeric",
    })}
    {(selectedEvent.end_date || selectedEvent.event_date) !== (selectedEvent.start_date || selectedEvent.event_date)
      ? ` bis ${new Date(selectedEvent.end_date || selectedEvent.event_date).toLocaleDateString("de-DE", {
          weekday: "long",
          day: "2-digit",
          month: "long",
          year: "numeric",
        })}`
      : ""}
  </span>
</div>
                    <div className="flex items-center gap-3 text-sm">
                      {selectedEvent.event_type === "Turnier" ? (
                        <>
                          <Trophy className="h-5 w-5 text-violet-200 shrink-0" />
                          <span className="text-violet-200 font-medium">Turnier</span>
                        </>
                      ) : selectedEvent.event_type === "Geburtstag" ? (
                        <>
                          <Cake className="h-5 w-5 text-pink-200 shrink-0" />
                          <span className="text-pink-200 font-medium">Geburtstag</span>
                        </>
                      ) : selectedEvent.event_type === "Urlaub" ? (
                        <>
                          <Sun className="h-5 w-5 text-sky-200 shrink-0" />
                          <span className="text-sky-200 font-medium">Urlaub</span>
                        </>
                      ) : (
                        <>
                          <Star className="h-5 w-5 text-green-600 shrink-0" />
                          <span className="text-green-600 font-medium">Vereinsevent</span>
                        </>
                      )}
                    </div>
</div>

{isVorstand && selectedEvent?.type === "board" && (
  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">

    <Button
      variant="outline"
      onClick={() => {
        const boardId = selectedEvent.id.replace("board_", "")

        setEditingBoardId(boardId)
        setBoardTitle(selectedEvent.name.replace("📌 Vorstand: ", ""))
        setBoardDesc(selectedEvent.description || "")
        setBoardDate(selectedEvent.event_date)
        setBoardTime(selectedEvent.start_time || "")

        setIsEventDialogOpen(false)
        setIsBoardDialogOpen(true)
      }}
    >
      Bearbeiten
    </Button>

 <Button
  variant="destructive"
  onClick={() => {
    const boardId = selectedEvent.id.replace("board_", "")
    setConfirmDeleteBoardId(boardId)
    setIsConfirmDeleteBoardOpen(true)
  }}
>
  Löschen
</Button>
	
	
	
	
	

  </div>
)}
				  
				  
				  
				  
				  
				  
				  {selectedEvent?.type === "board" && (
  <div className="space-y-2 bg-black/30 p-3 rounded-lg border">
    <div className="font-semibold text-sm">Anhänge</div>

    {loadingBoardAttachments ? (
      <div className="text-sm text-white/50">Lade Dateien...</div>
    ) : boardAttachments.length === 0 ? (
      <div className="text-sm text-white/50">Keine Dateien hochgeladen.</div>
    ) : (
      <div className="space-y-3">
        {boardAttachments.map((a) => {
          const url = a.url || ""
          const isImage =
            (a.mime_type || "").startsWith("image/") ||
            a.file_name.toLowerCase().match(/\.(png|jpg|jpeg|webp|gif)$/)

          return (
            <div key={a.id} className="border rounded-lg p-2">
              <div className="text-sm font-medium break-words">{a.file_name}</div>

              {a.url ? (
                isImage ? (
                  <img
                    src={url}
                    alt={a.file_name}
                    className="mt-2 w-full h-44 object-cover rounded-xl border"
                  />
                ) : (
                  <a
                    href={url}
                    target="_blank"
                    rel="noreferrer"
                    className="mt-2 inline-block text-sm underline"
                  >
                    Dokument öffnen
                  </a>
                )
              ) : (
                <div className="text-sm text-red-600 mt-2">Link konnte nicht erstellt werden.</div>
              )}
            </div>
          )
        })}
      </div>
    )}
  </div>
)}
				  
				  
				  
				  
				  
				  

                  {selectedEvent?.event_type === "Urlaub" &&
  selectedEvent.vacation_id &&
  currentUserId &&
  selectedEvent.vacation_user_id === currentUserId && (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
      <Button
        variant="outline"
        onClick={() => {
          setIsEventDialogOpen(false)
          setEditingVacationId(selectedEvent.vacation_id || null)
          setVacationStart(selectedEvent.start_date || "")
          setVacationEnd(selectedEvent.end_date || "")
          setVacationNote((selectedEvent.note || selectedEvent.description || "") as string)
          
          if (!vacationName.trim()) {
            const inferred = (selectedEvent.name || "").replace("🏖️ Urlaub:", "").trim()
            if (inferred) setVacationName(inferred)
          }
          setIsVacationDialogOpen(true)
        }}
        className="w-full"
      >
        Bearbeiten
      </Button>

      <Button
        variant="destructive"
        onClick={() => {
          setConfirmDeleteVacationId(selectedEvent.vacation_id!)
          setIsConfirmDeleteOpen(true)
        }}
        disabled={savingVacation}
        className="w-full"
      >
        Löschen
      </Button>
    </div>
)}
                </div>
              )}
            </DialogContent>
          </Dialog>

          <Dialog open={isMultiItemDialogOpen} onOpenChange={setIsMultiItemDialogOpen}>
            <DialogContent className="w-[calc(100vw-1.5rem)] sm:w-auto sm:max-w-md max-h-[80dvh] overflow-y-auto calendar-dialog">
              <DialogHeader>
                <DialogTitle className="text-lg">
                  Termine am{" "}
                  {selectedDate?.toLocaleDateString("de-DE", {
                    weekday: "long",
                    day: "2-digit",
                    month: "long",
                    year: "numeric",
                  })}
                </DialogTitle>
                <DialogDescription className="text-sm">Alle Termine an diesem Tag</DialogDescription>
              </DialogHeader>

              {selectedDate && (
                <div className="space-y-3">
                  {getItemsForDate(selectedDate).map((item) => (
                    <Card
                      key={item.id}
                      className="cursor-pointer hover:bg-white/[0.035]"
                      onClick={() => {
                        setIsMultiItemDialogOpen(false)
                        handleItemClick(item)
                      }}
                    >
                      <CardContent className="p-3 overflow-hidden">
                        {isEvent(item) ? (
                            <div className="flex items-center justify-between gap-2 min-w-0">
                            <div className="flex items-center gap-3 min-w-0">
                              <div className="text-sm font-medium truncate">{item.name}</div>
                            </div>
                            <div className="flex items-center gap-2 shrink-0">
                              {item.event_type === "Turnier" ? (
                                <Trophy className="h-4 w-4 text-violet-200" />
                              ) : item.event_type === "Geburtstag" ? (
                                <Cake className="h-4 w-4 text-pink-200" />
                              ) : (
                                <CalendarDays className="h-4 w-4 text-green-600" />
                              )}
                              {getEventTypeBadge(item.event_type)}
                            </div>
                          </div>
                        ) : (
                          <div className="flex items-center justify-between gap-2 min-w-0">
                            <div className="flex items-center gap-3 min-w-0">
                              <div className="text-sm font-medium shrink-0 whitespace-nowrap">
  {formatTimeWithoutSeconds(item.match_time)}
</div>

                             <div className="text-sm break-words min-w-0">

                                {getTeamDisplayName(item, true)} vs {getTeamDisplayName(item, false)}
                              </div>
                            </div>
                            <div className="flex items-center gap-2 shrink-0">
                              {isHomeGame(item) ? (
                                <Home className="h-4 w-4 text-orange-200" />
                              ) : (
                                <Plane className="h-4 w-4 text-blue-600" />
                              )}
                              {getStatusBadge(item.status)}
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </DialogContent>
          </Dialog>

          <Dialog open={isConfirmDeleteBoardOpen} onOpenChange={setIsConfirmDeleteBoardOpen}>
  <DialogContent className="w-[calc(100vw-1.5rem)] sm:w-auto sm:max-w-md calendar-dialog">
    <DialogHeader>
      <DialogTitle className="text-lg">Vorstand-Termin wirklich löschen?</DialogTitle>
      <DialogDescription className="text-sm">
        Dieser Termin wird dauerhaft entfernt (inkl. Einladungen & Dateien).
      </DialogDescription>
    </DialogHeader>

    <div className="flex flex-col sm:flex-row gap-2">
      <Button
        variant="outline"
        onClick={() => {
          setIsConfirmDeleteBoardOpen(false)
          setConfirmDeleteBoardId(null)
        }}
        className="w-full"
      >
        Abbrechen
      </Button>

      <Button
        variant="destructive"
        onClick={async () => {
          if (!confirmDeleteBoardId) return

          const id = confirmDeleteBoardId
          setIsConfirmDeleteBoardOpen(false)
          setConfirmDeleteBoardId(null)

          const { error } = await supabase
            .from("board_events")
            .delete()
            .eq("id", id)

          if (error) {
            console.error("board delete error:", error)
            return
          }

          setIsEventDialogOpen(false)
          await fetchData()
        }}
        className="w-full"
        disabled={!confirmDeleteBoardId}
      >
        Ja, löschen
      </Button>
    </div>
  </DialogContent>
</Dialog>

          <Dialog open={isVacationDialogOpen} onOpenChange={setIsVacationDialogOpen}>
            <DialogContent className="w-[calc(100vw-1.5rem)] sm:w-auto sm:max-w-md max-h-[80dvh] overflow-y-auto calendar-dialog">
              <DialogHeader>
                <DialogTitle className="text-lg">{editingVacationId ? "Urlaub bearbeiten" : "Urlaub eintragen"}</DialogTitle>
                <DialogDescription className="text-sm">Für alle sichtbar im Vereins-Kalender</DialogDescription>
              </DialogHeader>

              <div className="space-y-4">
                <div className="space-y-2">
                  <Label></Label>
                 
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label>Von</Label>
                    <Input type="date" value={vacationStart} onChange={(e) => setVacationStart(e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label>Bis</Label>
                    <Input type="date" value={vacationEnd} onChange={(e) => setVacationEnd(e.target.value)} />
                  </div>
                </div>
				
	

                <div className="space-y-2">
                  <Label>Notiz (optional)</Label>
                  <Textarea
                    value={vacationNote}
                    onChange={(e) => setVacationNote(e.target.value)}
                    placeholder="z.B. nicht erreichbar / Vertretung ..."
                  />
                </div>

                <Button
                  onClick={createVacation}
                  disabled={savingVacation || !vacationName.trim() || !vacationStart || !vacationEnd}
                  className="w-full"
                >
                  <Sun className="h-4 w-4 mr-2" />
                  {savingVacation ? "Speichern..." : editingVacationId ? "Änderungen speichern" : "Urlaub speichern"}
                </Button>

                {editingVacationId && (
                  <Button
                    variant="destructive"
                    onClick={() => {
                      setConfirmDeleteVacationId(editingVacationId)
                      setIsConfirmDeleteOpen(true)
                    }}
                    disabled={savingVacation}
                    className="w-full"
                  >
                    Urlaub löschen
                  </Button>
                )}
              </div>
            </DialogContent>
          </Dialog>
		  
		  
		  
		<Dialog open={isPrivateDialogOpen} onOpenChange={setIsPrivateDialogOpen}>
  <DialogContent className="w-[calc(100vw-1.5rem)] sm:w-auto sm:max-w-md max-h-[80dvh] overflow-y-auto calendar-dialog">
    <DialogHeader>
      <DialogTitle className="text-lg">
        {editingPrivateEntryId ? "Privaten Termin bearbeiten" : "Privaten Termin eintragen"}
      </DialogTitle>
      <DialogDescription className="text-sm">
        Nur für dich sichtbar
      </DialogDescription>
    </DialogHeader>

    <div className="space-y-4">
      <div className="space-y-2">
        <Label>Titel</Label>
        <Input
          value={privateTitle}
          onChange={(e) => setPrivateTitle(e.target.value)}
          placeholder="z.B. Arzt, Privat, Frei, Termin"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="space-y-2">
          <Label>Von</Label>
          <Input type="date" value={privateStart} onChange={(e) => setPrivateStart(e.target.value)} />
        </div>
        <div className="space-y-2">
          <Label>Bis</Label>
          <Input type="date" value={privateEnd} onChange={(e) => setPrivateEnd(e.target.value)} />
        </div>
      </div>
	  
	  <div className="space-y-2">
  <Label>Uhrzeit (optional)</Label>
  <Input
    type="time"
    value={privateTime}
    onChange={(e) => setPrivateTime(e.target.value)}
  />
</div>

      <div className="space-y-2">
        <Label>Notiz (optional)</Label>
        <Textarea
          value={privateNote}
          onChange={(e) => setPrivateNote(e.target.value)}
          placeholder="z.B. nur intern / privat / nicht verfügbar ..."
        />
      </div>

      <Button
        onClick={createPrivateEntry}
        disabled={savingPrivateEntry || !privateTitle.trim() || !privateStart || !privateEnd}
        className="w-full"
      >
        {savingPrivateEntry
          ? "Speichern..."
          : editingPrivateEntryId
          ? "Änderungen speichern"
          : "Privaten Termin speichern"}
      </Button>

      {editingPrivateEntryId && (
        <Button
          variant="destructive"
          onClick={() => {
            setConfirmDeletePrivateEntryId(editingPrivateEntryId)
            setIsConfirmDeletePrivateOpen(true)
          }}
          disabled={savingPrivateEntry}
          className="w-full"
        >
          Privaten Termin löschen
        </Button>
      )}
    </div>
  </DialogContent>
</Dialog>  
		  
		  
		  <Dialog open={isConfirmDeletePrivateOpen} onOpenChange={setIsConfirmDeletePrivateOpen}>
  <DialogContent className="w-[calc(100vw-1.5rem)] sm:w-auto sm:max-w-md calendar-dialog">
    <DialogHeader>
      <DialogTitle className="text-lg">Privaten Termin wirklich löschen?</DialogTitle>
      <DialogDescription className="text-sm">
        Dieser private Termin wird dauerhaft entfernt.
      </DialogDescription>
    </DialogHeader>

    <div className="flex flex-col sm:flex-row gap-2">
      <Button
        variant="outline"
        onClick={() => {
          setIsConfirmDeletePrivateOpen(false)
          setConfirmDeletePrivateEntryId(null)
        }}
        className="w-full"
      >
        Abbrechen
      </Button>

      <Button
        variant="destructive"
        onClick={async () => {
          if (!confirmDeletePrivateEntryId) return

          const id = confirmDeletePrivateEntryId
          setIsConfirmDeletePrivateOpen(false)
          setConfirmDeletePrivateEntryId(null)

          await deletePrivateEntry(id)
        }}
        className="w-full"
        disabled={!confirmDeletePrivateEntryId}
      >
        Ja, löschen
      </Button>
    </div>
  </DialogContent>
</Dialog>
		  
		  
		  <Dialog open={isBoardDialogOpen} onOpenChange={setIsBoardDialogOpen}>
  <DialogContent className="w-[calc(100vw-1.5rem)] sm:w-auto sm:max-w-md max-h-[80dvh] overflow-y-auto calendar-dialog">
    <DialogHeader>
      <DialogTitle className="text-lg">Vorstand Termin eintragen</DialogTitle>
      <DialogDescription className="text-sm">Nur für Vorstand sichtbar</DialogDescription>
    </DialogHeader>

    <div className="space-y-4">
      <div className="space-y-2">
        <Label>Titel</Label>
        <Input value={boardTitle} onChange={(e) => setBoardTitle(e.target.value)} />
      </div>

      <div className="space-y-2">
        <Label>Beschreibung (optional)</Label>
        <Textarea value={boardDesc} onChange={(e) => setBoardDesc(e.target.value)} />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="space-y-2">
          <Label>Datum</Label>
          <Input type="date" value={boardDate} onChange={(e) => setBoardDate(e.target.value)} />
        </div>
        <div className="space-y-2">
          <Label>Uhrzeit</Label>
          <Input type="time" value={boardTime} onChange={(e) => setBoardTime(e.target.value)} />
        </div>
      </div>

      <div className="space-y-2">
        <Label>Dateien / Bilder</Label>
        <Input type="file" multiple onChange={(e) => setBoardFiles(e.target.files)} />
      </div>
	  
	  
	  <div className="space-y-2">
  <Label>Spieler einladen</Label>

  <Input
    value={inviteSearch}
    onChange={(e) => setInviteSearch(e.target.value)}
    placeholder="Spieler suchen…"
    className="text-sm"
  />

  <div className="border rounded-lg p-2 max-h-48 overflow-y-auto space-y-1">
    {allClubPlayers
      .filter((p) => (p.name || "").toLowerCase().includes(inviteSearch.toLowerCase().trim()))
      .map((p) => {
        const checked = invitePlayerIds.includes(p.id)
        return (
          <label
            key={p.id}
            className="flex items-center gap-2 text-sm p-1 rounded-sm hover:bg-white/[0.035] cursor-pointer"
          >
            <input
              type="checkbox"
              checked={checked}
              onChange={() => toggleInvitePlayer(p.id)}
            />
            <span className="truncate">{p.name}</span>
          </label>
        )
      })}

    {allClubPlayers.length === 0 && (
      <div className="text-sm text-white/50">Keine Spieler gefunden.</div>
    )}
  </div>

  <div className="text-xs text-white/50">
    Ausgewählt: {invitePlayerIds.length}
  </div>
</div>
	  
	  
	  
	  
	  
	  

      <Button
        onClick={createBoardEvent}
        disabled={savingBoard || !boardTitle.trim() || !boardDate || !boardTime}
        className="w-full bg-black hover:bg-black/90"
      >
        {savingBoard ? "Speichern..." : "Termin speichern"}
      </Button>
    </div>
  </DialogContent>
</Dialog>
		  
		  
		  

          {isMobileBottomSheetOpen && mobileSelectedDate && (
            <div className="fixed inset-0 z-[999]">
              <div className="absolute inset-0 bg-black/50" onClick={() => setIsMobileBottomSheetOpen(false)} />

              <div className="absolute bottom-0 left-0 right-0 bg-black/30 rounded-t-xl max-h-[70dvh] overflow-hidden pb-[calc(env(safe-area-inset-bottom)+5rem)]">
                <div className="flex justify-center py-3">
                  <div className="w-10 h-1 bg-gray-300 rounded-full" />
                </div>

                <div className="px-4 pb-4 border-b">
                  <h3 className="text-lg font-semibold">
                    {mobileSelectedDate.toLocaleDateString("de-DE", {
                      weekday: "long",
                      day: "numeric",
                      month: "long",
                    })}
                  </h3>
                  <p className="text-sm text-white/50">
                    {getItemsForDate(mobileSelectedDate).length}{" "}
                    {getItemsForDate(mobileSelectedDate).length === 1 ? "Termin" : "Termine"}
                  </p>
                </div>

                <div className="overflow-y-auto max-h-[50dvh]">
                  <div className="p-4 space-y-3">
                    {getItemsForDate(mobileSelectedDate).map((item) => (
                      <Card
                        key={item.id}
                        className="cursor-pointer hover:bg-white/[0.035] transition-colors"
                        onClick={() => {
                          setIsMobileBottomSheetOpen(false)
                          handleItemClick(item)
                        }}
                      >
                        <CardContent className="p-4 sm:p-5">
                          {isEvent(item) ? (
                            <div className="flex items-center justify-between gap-2 min-w-0">
                              <div className="flex items-center gap-3 min-w-0">
                                <div
                                  className={`p-2 rounded-lg ${
                                    item.event_type === "Turnier"
                                      ? "bg-violet-500/[0.10]"
                                      : item.event_type === "Geburtstag"
                                        ? "bg-pink-500/[0.10]"
                                        : item.event_type === "Urlaub"
                                          ? "bg-sky-100"
                                          : "bg-emerald-500/[0.10]"
                                  }`}
                                >
                                  {item.event_type === "Turnier" ? (
                                    <Trophy className="h-5 w-5 text-violet-200" />
                                  ) : item.event_type === "Geburtstag" ? (
                                    <Cake className="h-5 w-5 text-pink-200" />
                                  ) : item.event_type === "Urlaub" ? (
                                    <Sun className="h-5 w-5 text-sky-200" />
                                  ) : (
                                    <CalendarDays className="h-5 w-5 text-green-600" />
                                  )}
                                </div>
                                <div className="min-w-0">
                                  <div className="font-medium text-base truncate">{item.name}</div>
                                  <div className="text-sm text-white/50">
                                    {item.event_type === "Urlaub"
                                      ? `${item.start_date} bis ${item.end_date}`
                                      : item.event_type === "Geburtstag"
                                        ? ""
                                        : item?.start_time
                                          ? `${normalizeTimeHHMM(item?.start_time)} Uhr`

                                          : ""}
                                  </div>
                                </div>
                              </div>
                              <div className="flex items-center gap-2 shrink-0">{getEventTypeBadge(item.event_type)}</div>
                            </div>
                          ) : (
                            <div className="flex items-center justify-between gap-2 min-w-0">
                              <div className="flex items-center gap-3 min-w-0">
                                <div className={`p-2 rounded-lg ${isHomeGame(item) ? "bg-orange-100" : "bg-sky-500/[0.10]"}`}>
                                  {isHomeGame(item) ? (
                                    <Home className="h-5 w-5 text-orange-200" />
                                  ) : (
                                    <Plane className="h-5 w-5 text-blue-600" />
                                  )}
                                </div>
                                <div className="min-w-0">
                                  <div className="font-medium text-base truncate">
                                    {getTeamDisplayName(item, true)} vs {getTeamDisplayName(item, false)}
                                  </div>
                                  <div className="text-sm text-white/50">
                                    {formatTimeWithoutSeconds((item as any).match_time)} Uhr

                                    {item.season?.name && ` • ${item.season.name}`}
                                  </div>
                                </div>
                              </div>
                              <div className="flex items-center gap-2 shrink-0">{getStatusBadge(item.status)}</div>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
		
			  <Dialog open={isLineupDialogOpen} onOpenChange={setIsLineupDialogOpen}>
  <DialogContent className="w-[calc(100vw-1.5rem)] sm:w-auto sm:max-w-md max-h-[80dvh] overflow-y-auto calendar-dialog">
    <DialogHeader>
      <DialogTitle className="text-lg">Aufstellung</DialogTitle>
      <DialogDescription className="text-sm">
        {selectedMatch ? `${getTeamDisplayName(selectedMatch, true)} vs ${getTeamDisplayName(selectedMatch, false)}` : ""}
      </DialogDescription>
    </DialogHeader>

    {loadingLineup ? (
      <div className="text-sm text-white/50">Lade Aufstellung...</div>
    ) : lineupPlayers.length === 0 ? (
      <div className="text-sm text-white/50">Noch keine Aufstellung hinterlegt.</div>
    ) : (
      <div className="space-y-2">
        {lineupPlayers.map((p) => (
          <div key={p.id} className="flex items-center justify-between border rounded-lg p-2">
            <div className="text-sm font-medium">
              {p.position}. {p.club_players?.name || "Unbekannter Spieler"}
            </div>

            {p.is_substitute ? (
              <Badge className="bg-white/[0.04] text-white/60 border-white/[0.08] text-xs">Ersatz</Badge>
            ) : (
              <Badge className="bg-orange-100 text-orange-800 border-orange-300/[0.16] text-xs">Stamm</Badge>
            )}
          </div>
        ))}
      </div>
    )}
  </DialogContent>
</Dialog>

		
      </main>
	  


      <style jsx global>{`
        .calendar-premium input,
        .calendar-premium textarea,
        .calendar-dialog input,
        .calendar-dialog textarea {
          border-color: rgba(255,255,255,.09) !important;
          background: rgba(8,12,18,.96) !important;
          color: white !important;
          box-shadow: none !important;
        }
        .calendar-premium input::placeholder,
        .calendar-premium textarea::placeholder,
        .calendar-dialog input::placeholder,
        .calendar-dialog textarea::placeholder {
          color: rgba(255,255,255,.25) !important;
        }
        .calendar-dialog {
          border: 1px solid rgba(255,255,255,.09) !important;
          background:
            radial-gradient(circle at 10% 0%, rgba(249,115,22,.10), transparent 30%),
            radial-gradient(circle at 100% 20%, rgba(14,165,233,.08), transparent 32%),
            rgba(5,8,12,.985) !important;
          color: white !important;
          box-shadow: 0 30px 90px -45px rgba(0,0,0,.98) !important;
          border-radius: 1.5rem !important;
        }
        .calendar-dialog h2,
        .calendar-dialog h3 { color: white !important; }
        .calendar-dialog label { color: rgba(255,255,255,.55) !important; }
      `}</style>

      <MobileBottomNav />
    </div>
  )
}