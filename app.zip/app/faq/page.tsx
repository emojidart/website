"use client"

import { useRef, useState } from "react"
import { supabase } from "@/lib/supabase"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Header } from "@/components/header"
import { TypingIndicator } from "@/components/typing-indicator"
import { Send, Sparkles, MessageCircle } from "lucide-react"
import { MobileBottomNav } from "@/components/mobile-bottom-nav"
import { motion } from "framer-motion"

type FAQ = {
  id: number
  question: string
  answer: string
  keywords: string[] | null
}

type Message = {
  from: "bot" | "user"
  text: string
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.08, delayChildren: 0.05 },
  },
}

const itemVariants = {
  hidden: { opacity: 0, y: 16 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { type: "spring", stiffness: 110, damping: 14 },
  },
}

export default function ProFAQChat() {
  const [messages, setMessages] = useState<Message[]>([
    {
      from: "bot",
      text: "Hallo! 👋 Ich bin dein EMD Chat-Assistent. Wie kann ich dir helfen?",
    },
  ])
  const [input, setInput] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const chatRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    setTimeout(() => {
      chatRef.current?.scrollTo({
        top: chatRef.current.scrollHeight,
        behavior: "smooth",
      })
    }, 100)
  }

  const normalize = (text: string) =>
    String(text ?? "")
      .toLowerCase()
      .trim()
      .replace(/[^\p{L}\p{N}\s]/gu, "")
      .replace(/\s+/g, " ")

  const getKeywords = (keywords: string[] | null | undefined) => {
    if (!Array.isArray(keywords)) return []
    return keywords.map((k) => normalize(String(k))).filter(Boolean)
  }

  const simulateTyping = async (answer: string) => {
    const baseDelay = 500
    const typingSpeed = 20
    const delay = baseDelay + Math.min(answer.length * typingSpeed, 1200)
    await new Promise((resolve) => setTimeout(resolve, delay))
  }

  const findBestMatch = (query: string, faqs: FAQ[]) => {
    const exactMatch = faqs.find((faq) => {
      const normalizedQuestion = normalize(faq.question)
      const normalizedKeywords = getKeywords(faq.keywords)

      return normalizedQuestion === query || normalizedKeywords.includes(query)
    })

    if (exactMatch) return exactMatch

    const fallbackMatch = faqs.find((faq) => {
      const normalizedQuestion = normalize(faq.question)
      const normalizedKeywords = getKeywords(faq.keywords)

      const questionContains =
        normalizedQuestion.length > 0 &&
        (normalizedQuestion.includes(query) || query.includes(normalizedQuestion))

      const keywordContains = normalizedKeywords.some(
        (keyword) =>
          keyword.length > 0 &&
          (keyword.includes(query) || query.includes(keyword))
      )

      return questionContains || keywordContains
    })

    return fallbackMatch
  }

  const handleAsk = async (q: string) => {
    if (!q.trim() || isTyping) return

    const query = normalize(q)

    setMessages((prev) => [...prev, { from: "user", text: q }])
    setInput("")
    scrollToBottom()

    setIsTyping(true)
    scrollToBottom()

    const { data, error } = await supabase
      .from("faqs")
      .select("id, question, answer, keywords")

    let answer = "Das kann ich dir nicht beantworten. 🧐 Versuche es mit einer anderen Frage!"

    if (!error && data) {
      const matched = findBestMatch(query, data as FAQ[])

      if (matched) {
        answer = matched.answer
      }
    }

    await simulateTyping(answer)

    setIsTyping(false)
    setMessages((prev) => [...prev, { from: "bot", text: answer }])
    scrollToBottom()
  }

  return (
    <div className="min-h-screen overflow-x-hidden bg-[#f5f6f8] text-slate-950 pb-24 md:pb-0">
      <Header />

      <main className="pt-12 sm:pt-14">
        <motion.div
          className="mx-auto w-full max-w-[1800px] px-2 py-4 sm:px-4 sm:py-5 lg:px-5 xl:px-6 2xl:px-8"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          <motion.div variants={itemVariants} className="mb-4 sm:mb-5">
            <div className="overflow-hidden rounded-[22px] border border-slate-200 bg-white shadow-[0_18px_50px_-42px_rgba(15,23,42,0.55)]">
              <div className="h-1.5 bg-gradient-to-r from-orange-500 to-orange-600" />
              <div className="flex items-start gap-3 p-4 sm:p-5">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl border border-orange-200 bg-orange-50">
                  <Sparkles className="h-5 w-5 text-orange-600" />
                </div>
                <div className="min-w-0">
                  <h1 className="text-lg font-black text-slate-950 sm:text-xl">FAQ Assistent</h1>
                  <p className="mt-1 text-sm font-medium text-slate-600">Stelle mir deine Fragen – ich helfe dir gerne weiter!</p>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            variants={itemVariants}
            className="rounded-[22px] border border-slate-200 bg-white shadow-[0_18px_50px_-42px_rgba(15,23,42,0.55)] overflow-hidden"
          >
            <div className="px-4 sm:px-5 py-3 border-b border-gray-200 flex items-center gap-2">
              <div className="w-9 h-9 rounded-2xl bg-orange-50 border border-orange-200 flex items-center justify-center">
                <MessageCircle className="w-4 h-4 text-orange-600" />
              </div>

              <div className="min-w-0">
                <p className="text-sm font-black text-gray-900">Chat</p>
                <p className="text-xs text-gray-500">Tippe eine Frage und sende sie ab</p>
              </div>
            </div>

            <div ref={chatRef} className="h-[60vh] sm:h-[62vh] overflow-y-auto p-4 pb-28">
              <div className="flex flex-col gap-3">
                {messages.map((msg, idx) => (
                  <div
                    key={idx}
                    className={`flex ${
                      msg.from === "user" ? "justify-end" : "justify-start"
                    } animate-in fade-in slide-in-from-bottom-2 duration-300`}
                  >
                    <div
                      className={`px-4 py-3 rounded-2xl max-w-[85%] shadow-sm border ${
                        msg.from === "user"
                          ? "bg-gray-100 text-gray-900 border-gray-200 rounded-br-sm"
                          : "bg-orange-600 text-white border-orange-600 rounded-bl-sm"
                      }`}
                    >
                      <p className="text-sm leading-relaxed whitespace-pre-line">
                        {msg.text}
                      </p>
                    </div>
                  </div>
                ))}

                {isTyping && <TypingIndicator />}
              </div>
            </div>
          </motion.div>

          <div className="fixed bottom-20 left-0 right-0 px-4">
            <div className="mx-auto w-full max-w-2xl">
              <div className="rounded-2xl border border-gray-200 bg-white shadow-lg p-2">
                <div className="flex gap-2">
                  <Input
                    placeholder="Deine Frage eingeben..."
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleAsk(input)}
                    disabled={isTyping}
                    className="h-11 rounded-2xl border-0 focus-visible:ring-0 focus-visible:ring-offset-0 bg-transparent"
                  />

                  <Button
                    onClick={() => handleAsk(input)}
                    disabled={isTyping || !input.trim()}
                    size="icon"
                    className="h-11 w-11 rounded-2xl bg-orange-600 hover:bg-orange-700 shrink-0"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <div className="mt-2 text-[11px] text-gray-500 px-1">
                {isTyping ? "Assistent tippt…" : ""}
              </div>
            </div>
          </div>
        </motion.div>
      </main>

      <MobileBottomNav />
    </div>
  )
}